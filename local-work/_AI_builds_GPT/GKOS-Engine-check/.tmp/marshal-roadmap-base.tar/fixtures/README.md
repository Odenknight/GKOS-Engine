# Shared fixture corpus

Fixtures must be language-neutral and consumed unchanged by Python and Rust.
Each fixture will bind raw input, injected nondeterminism, expected verdict,
canonical-byte hex, digest, diagnostic, chain state, and applicable requirement
IDs. Placeholder or self-derived expectations cannot qualify cutover.

The executable v1 corpus uses tab-separated UTF-8 records so another language
can consume the files unchanged without a Rust-specific serializer:

- `cbor/v1/cases.tsv`: 29 normative, mutation, limit, depth, and digest cases.
- `evd/v1/typed-metadata.tsv`: 7 symbolic class/schema pairing and refusal cases.
- `evd/v1/typed-record-positive.tsv`: 8 exact encoded typed EVD records with
  literal expected canonical bytes and EVD entry digests.
- `evd/v1/typed-record-mutations.tsv`: 94 language-neutral mutation twins,
  including exhaustive closed-map missing-key and wrong-type classes.
- `evd/v1/lifecycle-registry-candidate.tsv`: explicit unratified lifecycle
  state/result registry consumed only through its exact SHA-256 binding.

Digest expectations are literal external values, not values written by the
runner. Boundary constructors are named in the operation column to avoid
committing megabyte-scale repeated data while preserving exact lengths.

Typed EVD vectors bind owner-selected u16 codes `1` and `2` and the closed
genesis and lifecycle payload maps. The lifecycle vector runner requires an
explicit candidate registry version and digest; absence is `SPEC_AMBIGUOUS`.
These fixtures grant no writer, persistence, activation, or cutover authority.
