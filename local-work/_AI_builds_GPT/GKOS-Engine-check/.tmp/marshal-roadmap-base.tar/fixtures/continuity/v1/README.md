# Durable continuity v1 fixtures

`guard-cases.tsv` is a language-neutral decision fixture consumed independently
by the Rust runtime test and Python binding test. It covers the compatibility
default, external read-only verification, missing-root and mapping precedence,
external mutation and rebuild refusal, explicit application-managed projection
ownership, outside-root disposition, and malformed normalized paths.

The fixture is UTF-8 with LF line endings. `SHA256SUMS` hashes the exact checked
bytes and is not a substitute for either independent parser or assertion set.
