# Third-party notices

No third-party source code is incorporated in this bootstrap.

Rust dependencies are referenced by package metadata only and retain their own
copyrights and licenses. A generated dependency-license inventory is required
before distribution of a compiled release.

