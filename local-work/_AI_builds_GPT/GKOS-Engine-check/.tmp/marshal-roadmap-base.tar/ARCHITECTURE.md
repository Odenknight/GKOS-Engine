# Architecture

## Governing rule

Rust is intended to become the sole authority for governance decisions,
evidence construction, capability enforcement, and execution admission. That
status is prospective: no crate in this bootstrap has activation authority.

This repository is the canonical upstream source for shared Core semantics.
Product repositories consume exact qualified revisions through bounded
adapters. Their product-specific runtime and orchestration remain downstream;
copied competing implementations are not an admitted integration model.

## Crates

| Crate | Responsibility |
|---|---|
| `marshal-core-contracts` | Stable identifiers, lifecycle types, diagnostics, qualification policy |
| `marshal-core-canonical` | Versioned canonical-byte and digest boundary |
| `marshal-core-authority` | Grants, refusal, revocation, escalation, kill-switch checks |
| `marshal-core-evidence` | EVD-002 entries, predecessor linkage, append and verification |
| `marshal-core-runtime` | Admission and lifecycle orchestration |
| `marshal-core-policy` | PHI/PII, egress, provider, budget, shell and action gates |
| `marshal-core-secrets` | Opaque references and outbound-only secret materialization contracts |
| `marshal-core-sdk` | Governed module boundary and G-M1..G-M12 conformance surface |
| `marshal-core-verify` | Read-only current and historical verification |

## EVD-002 greenfield appointment

1. Existing Python/JCS evidence remains non-production reference material.
2. Python and Rust consume identical logical and CBOR fixtures for comparison.
3. Rust runs offline conformance and PostgreSQL failure qualification.
4. Rust runs in non-authoritative shadow mode against representative operations.
5. The owner adjudicates every `SPEC_AMBIGUOUS` result.
6. The owner alone signs an exact-head sole-writer appointment.
7. The appointed Rust writer creates the first production genesis under
   `rust-authority-gen-1`; no Python production chain is migrated.

Historical JCS artifacts remain immutable and separately labeled. The permanent
Python verifier is read-only and provides regression evidence, not authority.

## Prospective PostgreSQL write boundary

The WP-01 candidate uses PostgreSQL 15+ as the only production persistence
authority. Canonical CBOR bytes are produced and validated before persistence;
PostgreSQL stores them unchanged. A per-chain transaction locks the chain head,
re-checks authority and kill epochs, resolves idempotency, inserts the immutable
entry, advances the head, and records its receipt atomically. JSON, extracted
columns, telemetry, outbox delivery, and checkpoints are projections or
supporting records, never canonical authority.

This boundary remains unratified and unactivated until its contract, fixtures,
failure matrices, shadow evidence, independent review, and exact build receive
the required owner authorization.
