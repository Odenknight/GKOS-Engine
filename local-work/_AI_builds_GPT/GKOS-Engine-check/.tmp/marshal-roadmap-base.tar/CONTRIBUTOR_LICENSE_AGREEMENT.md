# Contributor License Agreement — review draft

This document is intentionally marked **DRAFT — NOT READY FOR SIGNATURE**. It
must be reviewed by qualified intellectual-property counsel before contributors
are accepted.

The intended agreement must, at minimum:

1. identify the contributor and the copyright owner;
2. confirm the contributor has authority to submit the contribution;
3. let the contributor retain copyright in original contributions;
4. grant Shaun Allan Marshall a worldwide, perpetual, irrevocable, transferable,
   sublicensable license to use, reproduce, modify, create derivative works,
   distribute, publicly perform/display, commercialize, and relicense the work;
5. include an appropriate patent license for patentable contributions;
6. permit proprietary, source-available, royalty-bearing, and open-source release;
7. require disclosure of third-party or employer rights;
8. preserve attribution subject to practical notice aggregation;
9. state warranty and disclaimer terms; and
10. record signature, date, and contribution identity.

Until an approved agreement is executed, contributions must not be merged.

