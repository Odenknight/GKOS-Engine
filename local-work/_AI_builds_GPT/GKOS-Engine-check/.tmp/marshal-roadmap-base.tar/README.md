# theMarshal-Core-Rust

`theMarshal-Core-Rust` is the reusable, product-independent authority core for
The Marshal family. EVD-002 is the first implementation lane of the broader
Marshal Core Rust rebuild.

## Current status

**Foundation only — not activated and not an authoritative writer.** This
bootstrap defines crate boundaries, typed contracts, qualification policy, and
governance documents. This is a greenfield authority build: existing Python/JCS
evidence is non-production reference material and is not imported. Rust remains
unappointed until an owner-signed record names an exact commit, binary digest,
contract digest, fixture digest, and greenfield genesis manifest.

## Ownership boundaries

- **Marshal Core:** authority, lifecycle, evidence, policy, secrets, execution
  admission, and module contracts.
- **TheMarshal-008:** Python reference, product integration, differential
  harness, shadow evidence, and compatibility operations.
- **GKOS-Engine:** governed knowledge and GKX operations. It is replaceable and
  is not Marshal's lifecycle authority.

Dependency direction: `TheMarshal-008 -> Marshal Core -> GKOS-Engine`.

See [ARCHITECTURE.md](ARCHITECTURE.md), [CODEBASE_MAP.md](CODEBASE_MAP.md), and
[the upstream consumer model](docs/UPSTREAM-CONSUMER-MODEL.md). Product
repositories pin qualified Core revisions and integrate through adapters; they
must not silently fork shared Core semantics.

The registered private Alpha consumer is
[Marshal-008 OS](https://github.com/Odenknight/Marshal-008-OS). Its consumer
repository owns the exact revision pin, product adapter, deployment profiles,
and activation decision; this upstream repository remains the semantic source.
See [downstream consumers](docs/DOWNSTREAM-CONSUMERS.md).

## License

Copyright © 2026 Shaun Allan Marshall. All rights reserved. This repository is
not open source. Evaluation, production use, redistribution, derivative works,
and commercial use require written permission except where an executed license
expressly permits them. Commercial and royalty-bearing licenses may be offered
by the copyright owner. See [LICENSE](LICENSE) and [COMMERCIAL-LICENSING.md](COMMERCIAL-LICENSING.md).
