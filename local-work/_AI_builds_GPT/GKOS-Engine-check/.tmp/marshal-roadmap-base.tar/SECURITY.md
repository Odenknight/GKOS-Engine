# Security policy

This repository is pre-release and must not be used as an authoritative writer
or with production PHI/PII. Report vulnerabilities privately to the repository
owner rather than opening a public issue.

Security-sensitive changes require negative tests. No profile may disable audit,
evidence, or kill-switch enforcement after those capabilities are activated.

