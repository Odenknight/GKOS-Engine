from __future__ import annotations

import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import marshal_core_rs as core


ROOT = Path(__file__).resolve().parents[2]


APP_ROOT = (
    "primary",
    "/opt/marshal/usr",
    "application_managed",
    False,
    "managed",
    "permitted",
    "permitted",
    "permitted",
    "forbidden",
)
EXTERNAL_ROOT = (
    "primary",
    "/opt/marshal/usr",
    "human_operator_external",
    True,
    "verify_only",
    "forbidden",
    "forbidden",
    "forbidden",
    "forbidden",
)
OBSERVED = [("primary", True, True)]


class ContinuityBindingTests(unittest.TestCase):
    def test_shared_guard_fixture_matches_native_decisions(self) -> None:
        cases = (ROOT / "fixtures/continuity/v1/guard-cases.tsv").read_text(
            encoding="utf-8"
        )
        seen = 0
        for line in cases.splitlines():
            if not line or line.startswith("#"):
                continue
            seen += 1
            (
                case_id,
                scenario,
                target,
                present,
                mapping_matches,
                operation,
                expected,
            ) = line.split("\t")
            scenario_roots = {
                "application": [APP_ROOT],
                "external": [EXTERNAL_ROOT],
                "overlap": [
                    EXTERNAL_ROOT,
                    (
                        "projection",
                        "/opt/marshal/usr/projection",
                        "application_managed",
                        False,
                        "managed",
                        "permitted",
                        "permitted",
                        "permitted",
                        "permitted",
                    ),
                ],
            }[scenario]
            root_observations = [
                (root[0], present == "true", mapping_matches == "true")
                for root in scenario_roots
            ]
            try:
                result = core.continuity_decide_v1(
                    core.CONTINUITY_SCHEMA,
                    "deployment",
                    scenario_roots,
                    root_observations,
                    target,
                    operation,
                )
                actual = (
                    "outside_declared_roots"
                    if result[0] == "outside_declared_roots"
                    else f"allowed:{result[1]}:{result[2]}"
                )
            except ValueError as error:
                actual = str(error)
            self.assertEqual(actual, expected, case_id)
        self.assertEqual(seen, 9)

    def test_schema_and_contract_id_are_deliberately_distinct(self) -> None:
        self.assertEqual(core.abi_info()[3], "DURABLE-CONTINUITY-v1")
        self.assertEqual(
            core.CONTINUITY_SCHEMA,
            "harness/durable-continuity-envelope/v1",
        )
        self.assertEqual(
            core.GENERATED_ARTIFACT_RECEIPT_SCHEMA,
            "harness/generated-artifact-receipt/v1",
        )
        with self.assertRaisesRegex(
            ValueError, "8101:CONTINUITY_SCHEMA_UNSUPPORTED"
        ):
            core.continuity_decide_v1(
                core.CONTINUITY_CONTRACT_ID,
                "deployment",
                [APP_ROOT],
                OBSERVED,
                "/opt/marshal/usr/data",
                "backup",
            )

    def test_application_default_allows_and_external_mutation_refuses(self) -> None:
        self.assertEqual(
            core.continuity_decide_v1(
                core.CONTINUITY_SCHEMA,
                "deployment",
                [APP_ROOT],
                OBSERVED,
                "/opt/marshal/usr/data",
                "backup",
            ),
            ("allowed", "primary", "application_managed"),
        )
        with self.assertRaisesRegex(
            ValueError, "8108:EXTERNAL_DURABILITY_AUTHORITY"
        ):
            core.continuity_decide_v1(
                core.CONTINUITY_SCHEMA,
                "deployment",
                [EXTERNAL_ROOT],
                OBSERVED,
                "/opt/marshal/usr/data",
                "backup",
            )

    def test_projection_rebuild_requires_explicit_owner_permission(self) -> None:
        with self.assertRaisesRegex(
            ValueError, "8118:CONTINUITY_OPERATION_FORBIDDEN"
        ):
            core.continuity_decide_v1(
                core.CONTINUITY_SCHEMA,
                "deployment",
                [APP_ROOT],
                OBSERVED,
                "/opt/marshal/usr/truth",
                "projection_rebuild",
            )
        projection_root = APP_ROOT[:-1] + ("permitted",)
        self.assertEqual(
            core.continuity_decide_v1(
                core.CONTINUITY_SCHEMA,
                "deployment",
                [projection_root],
                OBSERVED,
                "/opt/marshal/usr/index",
                "projection_rebuild",
            ),
            ("allowed", "primary", "application_managed"),
        )

    def test_refusal_precedence_and_unknown_enum_are_stable(self) -> None:
        with self.assertRaisesRegex(ValueError, "8106:DURABLE_MOUNT_MISSING"):
            core.continuity_decide_v1(
                core.CONTINUITY_SCHEMA,
                "deployment",
                [EXTERNAL_ROOT],
                [("primary", False, False)],
                "/opt/marshal/usr/data",
                "restore_delete",
            )
        with self.assertRaisesRegex(ValueError, "8117:CONTINUITY_ENUM_UNKNOWN"):
            core.continuity_decide_v1(
                core.CONTINUITY_SCHEMA,
                "deployment",
                [EXTERNAL_ROOT],
                OBSERVED,
                "/opt/marshal/usr/data",
                "invented_operation",
            )
        with self.assertRaises((TypeError, ValueError)):
            core.continuity_decide_v1(
                core.CONTINUITY_SCHEMA,
                "deployment",
                [("truncated", "/durable")],
                [],
                "/durable",
                "verify_preflight",
            )

    def test_facade_rejects_an_incompatible_native_abi(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            package = Path(temporary) / "marshal_core_rs"
            package.mkdir()
            package.joinpath("__init__.py").write_bytes(
                (ROOT / "python/marshal_core_rs/__init__.py").read_bytes()
            )
            package.joinpath("_marshal_core_rs.py").write_text(
                "def abi_info():\n"
                "    return ('marshal-core-python/1', 'MARSHAL-CBOR-1', "
                "'EVD-002', 'DURABLE-CONTINUITY-v1', False, False)\n",
                encoding="utf-8",
            )
            result = subprocess.run(
                [sys.executable, "-c", "import marshal_core_rs"],
                cwd=temporary,
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("MARSHAL_CORE_RUST_ABI_MISMATCH", result.stderr)

    def test_generated_receipt_validation_is_exact(self) -> None:
        digest = "sha256:" + "a" * 64
        self.assertTrue(
            core.validate_generated_artifact_receipt_v1(
                core.GENERATED_ARTIFACT_RECEIPT_SCHEMA,
                "artifact/example",
                None,
                "task/example",
                "package/example",
                digest,
                digest,
                0,
                "application/octet-stream",
                "2026-08-29T00:00:00.000000Z",
                "generated_derivative",
                None,
            )
        )
        with self.assertRaisesRegex(
            ValueError, "8120:ARTIFACT_RECEIPT_SCHEMA_INVALID"
        ):
            core.validate_generated_artifact_receipt_v1(
                core.CONTINUITY_CONTRACT_ID,
                "artifact/example",
                None,
                "task/example",
                "package/example",
                digest,
                digest,
                0,
                "application/octet-stream",
                "2026-08-29T00:00:00.000000Z",
                "generated_derivative",
                None,
            )

    def test_read_only_verifier_reports_exact_findings(self) -> None:
        wrong_hash = "sha256:" + hashlib.sha256(b"other").hexdigest()
        passed, findings = core.verify_continuity_v1(
            core.CONTINUITY_SCHEMA,
            "deployment",
            [EXTERNAL_ROOT],
            OBSERVED,
            [
                (
                    "artifact/report",
                    "project_artifact",
                    b"report",
                    wrong_hash,
                    False,
                    False,
                    "not_applicable",
                ),
                (
                    "ephemeral/pid",
                    "ephemeral",
                    b"123",
                    None,
                    False,
                    False,
                    "not_applicable",
                ),
            ],
            True,
            True,
        )
        self.assertFalse(passed)
        self.assertEqual(
            findings,
            [
                (8110, "EPHEMERAL_RESTORE_REFUSED", "ephemeral/pid"),
                (8115, "ARTIFACT_HASH_MISMATCH", "artifact/report"),
            ],
        )
        with self.assertRaisesRegex(ValueError, "8117:CONTINUITY_ENUM_UNKNOWN"):
            core.verify_continuity_v1(
                core.CONTINUITY_SCHEMA,
                "deployment",
                [EXTERNAL_ROOT],
                OBSERVED,
                [("record", "source", b"", None, False, False, "current")],
                True,
                True,
            )


if __name__ == "__main__":
    unittest.main()
