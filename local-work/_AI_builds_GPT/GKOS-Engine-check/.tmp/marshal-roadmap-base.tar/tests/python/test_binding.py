from __future__ import annotations

import hashlib
from pathlib import Path
import unittest

import marshal_core_rs as core


ROOT = Path(__file__).resolve().parents[2]
DOMAIN = b"marshal-core\0evd-002\0entry\0v1\0"


class BindingTests(unittest.TestCase):
    def test_binding_is_exact_and_non_authoritative(self) -> None:
        self.assertEqual(core.abi_info(), core.EXPECTED_ABI)
        self.assertEqual(core.abi_info()[3], core.CONTINUITY_CONTRACT_ID)
        self.assertEqual(core.abi_info()[4:], (False, False))
        self.assertFalse(
            any(name in core.__all__ for name in ("append", "write", "migrate", "activate"))
        )

    def test_canonical_vectors_and_digests_match_python(self) -> None:
        rows = (ROOT / "fixtures/cbor/v1/cases.tsv").read_text(
            encoding="utf-8"
        ).splitlines()
        for row in rows:
            if not row or row.startswith("#"):
                continue
            case_id, operation, argument, expected = row.split("\t")
            if operation != "verify_hex":
                continue
            raw = bytes.fromhex(argument)
            if expected == "OK":
                core.verify_canonical(raw)
                expected_digest = hashlib.sha256(
                    DOMAIN + len(raw).to_bytes(8, "big") + raw
                ).hexdigest()
                self.assertEqual(core.evd_entry_digest(raw), expected_digest, case_id)
            else:
                with self.assertRaisesRegex(ValueError, expected):
                    core.verify_canonical(raw)

    def test_lifecycle_decisions_are_closed_and_stable(self) -> None:
        self.assertTrue(core.component_edge_allowed("READY", "ACTIVE"))
        self.assertFalse(core.component_edge_allowed("SUSPENDED", "ACTIVE"))
        self.assertEqual(
            core.evaluate_runtime("CREATED", 0, 0, "ADMISSION_PENDING"),
            ("ADMISSION_PENDING", 1),
        )
        with self.assertRaisesRegex(ValueError, "3003"):
            core.evaluate_runtime("CREATED", 0, 1, "ADMISSION_PENDING")
        with self.assertRaisesRegex(ValueError, "RUNTIME_STATE_UNKNOWN"):
            core.evaluate_runtime("UNKNOWN", 0, 0, "RUNNING")

    def test_read_only_chain_verifier_detects_tampering(self) -> None:
        chain_id = bytes([7]) * 32
        first = b"\xf6"
        second = b"\xf4"
        first_digest = bytes.fromhex(core.evd_entry_digest(first))
        second_digest = bytes.fromhex(core.evd_entry_digest(second))
        entries = [
            (chain_id, 1, None, first, first_digest),
            (chain_id, 2, first_digest, second, second_digest),
        ]
        self.assertEqual(core.verify_chain(entries), second_digest.hex())
        entries[1] = (chain_id, 2, first_digest, b"\xf5", second_digest)
        with self.assertRaisesRegex(ValueError, "EVD_DIGEST_MISMATCH"):
            core.verify_chain(entries)
