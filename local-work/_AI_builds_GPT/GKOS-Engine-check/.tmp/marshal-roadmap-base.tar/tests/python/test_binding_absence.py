from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[2]


class BindingAbsenceTests(unittest.TestCase):
    def test_native_absence_fails_closed_without_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            package = root / "marshal_core_rs"
            package.mkdir()
            package.joinpath("__init__.py").write_bytes(
                (ROOT / "python/marshal_core_rs/__init__.py").read_bytes()
            )
            result = subprocess.run(
                [sys.executable, "-c", "import marshal_core_rs"],
                cwd=root,
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("MARSHAL_CORE_RUST_BINDING_UNAVAILABLE", result.stderr)
