# WP-01 state and authority candidate handoff

**Status:** non-authoritative candidate; no activation, cutover, persistence, or writer  
**Rebase baseline:** current `main` merge commit `474c62e1ab61605f019df4196cce32d26a0e9ae6`

## Source pins

- Component lifecycle source: `Odenknight/TheMarshal-008@11ebf5635869122a6252f4999f59e82edadcedb8`,
  `core/harness/marshal_harness/core/lifecycle.py` and
  `governance/directives/CLC-001-component-lifecycle-contract-v0.3-review-candidate.md`.
- Runtime/work lifecycle source: this repository's
  `specifications/MARSHAL-STATE-MACHINE-CANDIDATE.md` at the PR head.
- Diagnostic identities: this repository's merged
  `specifications/DIAGNOSTIC-REGISTRY-CANDIDATE.md`. PR #4 was merged to `main`
  as `474c62e1ab61605f019df4196cce32d26a0e9ae6` from owner-authorized exact head
  `93d51755944d58f64e5a02d4d335139d4cea73eb`. The contract remains candidate,
  unratified, and non-authoritative.
- Lifecycle domain/edge ordering: merged PR #4 candidate
  `MCR-EVD-LIFECYCLE-REGISTRY-CANDIDATE-2` at `474c62e1ab61605f019df4196cce32d26a0e9ae6`. This PR's
  state arrays and transition predicates match that candidate's five component
  states, 13 component edges, nine runtime states, 11 runtime edges, and four
  runtime terminals. PR #3 does not pin or generate PR #4's future TSV digest.
- Owner decisions recorded 2026-08-25: separate five-state component and nine-state
  runtime/work types; numeric EVD event codes 1 and 2; approved closed payloads;
  existing diagnostics only.

## Separate candidate domains

The component domain is `INACTIVE`, `BLOCKED`, `READY`, `ACTIVE`, `SUSPENDED`.
It has exactly 13 direct edges, no terminal predicate, a separate desired state,
structured reason classes, activation-context invariants, checked revisions, and
mandatory context/authority/preflight checks for `SUSPENDED -> READY`.
Those checks are represented by an opaque recovery proof with private fields and
no public constructor or deserializer. Callers cannot assert authority or
preflight success with booleans. Recovery remains fail closed until a future
authority-boundary adapter supplies the proof.

The runtime/work domain is `CREATED`, `ADMISSION_PENDING`, `ADMITTED`, `RUNNING`,
`COMPLETING`, `COMPLETED`, `REFUSED`, `FAILED`, `CANCELLED`. It has exactly 11
direct edges. `COMPLETED`, `REFUSED`, `FAILED`, and `CANCELLED` are terminal.

Tests classify all 25 component state pairs and all 81 runtime state pairs.
The former unsupported seven-state model and its 42 state/action matrix are removed.

## Authority boundary

Shadow comparison posture is a separate operational value and never represents
an authority grant. The authority gate remains opaque and unappointed. This slice
does not publish or serialize authority/grant enums, provide a sole-writer
constructor, or add diagnostic identities.

## Explicit non-goals

No writer, database, file operation, clock, network operation, evidence append,
runtime activation, appointment verification, merge, or production cutover is
implemented. Canonical encoding and typed EVD payload vectors remain in their
own lanes. Python `ModuleService` remains the sole lifecycle authority.
