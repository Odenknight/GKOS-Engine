# WP-01 canonical/EVD primitives — coding-agent handoff

## Governed baseline

This candidate implementation is transplanted onto merged `main` containing:

- contract/specification authority from PR #4 merge commit `474c62e1ab61605f019df4196cce32d26a0e9ae6`;
- non-authoritative lifecycle/authority implementation from PR #3 merge commit `a6eb4e4123067980e16b7d137b5612c8c1b5385c`.

Those commits do not appoint Rust authority. Python `ModuleService` remains the sole
authoritative lifecycle writer, and this slice remains candidate-only.

## Scope delivered

This lane adds a dedicated `MARSHAL-CBOR-1` value model, strict encoder and
decoder, the candidate EVD-002 entry digest, fail-closed sealing of candidate
bytes, deterministic read-only chain verification, and initial normative and
mutation tests. It deliberately adds no database writer, service endpoint,
appointment loader, authority transition, or production activation.

## Security and authority properties

- Owned crates retain `unsafe_code = "forbid"`.
- Generic Rust struct serialization is not the protocol boundary.
- Raw noncanonical input is rejected, never repaired.
- Definite lengths and shortest encodings are mandatory.
- Maps are ordered by canonical key-byte length and then lexicographically.
- Duplicate keys, floats, tags, undefined/unrecognized simple values, invalid
  UTF-8, and non-NFC text are refused.
- Null, empty bytes, empty text, empty arrays, and empty maps remain distinct.
- `unicode-normalization` is pinned to `0.1.25` and its compiled Unicode tables
  must report `17.0.0`.
- V1 ceilings are 1 MiB per admitted request, 256 KiB per canonical payload,
  512 KiB per complete EVD record, depth 32 including map keys, and 255 UTF-8
  bytes for identity/action/schema text.
- Candidate chain verification is read-only and stops on the first diagnostic
  according to a fixed precedence.

## Exact digest formula

`SHA-256("marshal-core\\0evd-002\\0entry\\0v1\\0" || u64_be(len) || bytes)`

The length is an unsigned eight-byte big-endian integer. Only the dedicated
`digest_evd_entry` function owns this domain. Additional artifact domains must
receive separate functions and fixtures.

## Fixture status

Unit tests currently provide executable fixture scaffolding for canonical map
ordering, null/empty distinctions, shortest integer mutation, indefinite
length, float, tag, map reorder, duplicate key, non-NFC text, chain linkage,
digest mutation, structural seal refusal, and diagnostic precedence.

These tests are not the ratified fixture corpus. Follow-up work must create
versioned fixture files with IDs, expected bytes/digests/diagnostics, a corpus
manifest digest, integer and collection width boundaries, file-backed boundary
vectors for the pinned maximum sizes, complete event-envelope schemas, Python
differential vectors, mutation twins,
and independently generated golden values.

## Open decisions requiring contract/owner review

1. Ratify the EVD-002 logical entry envelope and event/payload registries.
2. Pin schema-specific integer ranges and collection-count bounds beyond the
   approved global byte, text, and nesting ceilings.
3. Decide whether negative integers remain allowed in the base profile or only
   in explicitly versioned artifact schemas.
4. Ratify numeric diagnostic codes and full within-stage precedence.
5. Ratify the entry digest domain and length-prefix formula.
6. Define separate domains for genesis, checkpoints, appointments, fixtures,
   shadow records, and qualification reports.
7. Ratify representative shadow per-class minimums.

## Required continuation

- Add an EVD logical-envelope builder that emits the dedicated value model.
- Add file-backed normative/mutation fixture runners shared with Python.
- Add the deterministic 100,000-entry generator and independently verified
  checkpoint heads.
- Add PostgreSQL transaction, crash, and concurrency lanes only after the
  logical entry and diagnostic contracts are approved.
- Keep Rust in unappointed/shadow state throughout qualification.

No result in this branch satisfies appointment eligibility by itself.

