# Upstream consumer model

## Decision

`theMarshal-Core-Rust` is the canonical upstream source for reusable,
product-independent Marshal Core semantics. Product repositories consume an
exact qualified revision or signed release; they do not maintain copied or
independently modified implementations of the same contract.

This is a private Alpha source model. It does not publish a crate, release,
binary, license grant, deployment, activation or authority appointment.

## Consumer requirements

A consumer integration must:

1. pin the repository, full commit identity, contract identities, license and
   qualification status;
2. refuse floating branches, moving tags and unverified artifacts;
3. keep the integration disabled until the exact revision is qualified for the
   consumer's platform and approved role;
4. preserve the upstream license and notices as a separate component;
5. use adapters at the product boundary instead of copying or redefining Core
   semantics;
6. fail closed on ABI, contract, fixture, digest or authority mismatch;
7. keep runtime and writer authority false unless a later owner-signed record
   appoints an exact build.

Consumers may add product-specific orchestration, schemas and adapters. Those
surfaces must not silently fork canonicalization, lifecycle, evidence,
diagnostic or verification behavior owned here.

## Private licensing posture

The current repository license remains in force and grants no general right to
use, copy, modify, distribute or deploy the Core. A consumer repository's
license does not relicense this component. Any future noncommercial or public
grant requires a separate owner-reviewed license decision attached to an exact
release.

No public dual-license grant is made by this document.

## Release gate

Before a release is admitted by a consumer, upstream must provide:

- an immutable version and source commit;
- clean Linux and Windows checks from fresh checkouts;
- fixture and contract digests;
- exact dependency lock data;
- ABI identity and authority flags;
- retained license and third-party notices;
- artifact digests for every published platform;
- an owner-reviewed consumer and licensing decision.

Until then, consumers may pin this repository for traceability and perform
shadow qualification, but must not ship or activate it as runtime authority.

Registered downstream relationships are documented in
[DOWNSTREAM-CONSUMERS.md](DOWNSTREAM-CONSUMERS.md). Registration does not
replace an exact consumer-side revision pin or any release gate.
