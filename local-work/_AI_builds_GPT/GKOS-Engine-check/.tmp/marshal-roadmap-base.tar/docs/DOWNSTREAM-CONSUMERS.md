# Downstream consumers

## Registered private Alpha consumer

| Consumer | Repository | Integration role | Authority |
| --- | --- | --- | --- |
| Marshal-008 OS | [Odenknight/Marshal-008-OS](https://github.com/Odenknight/Marshal-008-OS) | Exact-revision shadow adapter | None while disabled |

Marshal-008 OS records the accepted source commit, crate inventory, contract
identities, qualification evidence, license boundary, and refusal policy in
`integrations/marshal-core-rust/pin.toml`. Its CI rejects revision drift,
floating coordinates, copied semantics, altered authority metadata, or
activation inferred from source availability.

The relationship is deliberately asymmetric:

- this repository owns reusable Marshal Core semantics and publishes qualified
  source coordinates;
- the consumer owns product orchestration, adapters, profiles and deployment;
- a consumer pin does not appoint runtime or writer authority;
- a downstream commit is not pinned here, avoiding a circular source
  dependency;
- public release, distribution and licensing remain separate owner decisions.

Consumer registration is informational. Admission still requires the gates in
[UPSTREAM-CONSUMER-MODEL.md](UPSTREAM-CONSUMER-MODEL.md).
