# EVD-002 logical record candidate

**Status:** candidate only; non-authoritative; unratified; unactivated  
**Canonical profile:** `MARSHAL-CBOR-1`  
**Writer generation:** prospective `rust-authority-gen-1`

This document defines the logical record presented to the canonical encoder. PostgreSQL, JSON renderers, and language-specific object layouts MUST NOT alter these semantics. Python `ModuleService` remains the sole authoritative lifecycle writer. This candidate adds no Rust writer, appointment, activation, or cutover.

## Record

An EVD-002 record is a CBOR map with exactly these integer keys:

| Key | Name | Type | Rule |
|---:|---|---|---|
| 1 | `contract_version` | text | exactly `EVD-002` for this candidate |
| 2 | `canonical_profile` | text | exactly `MARSHAL-CBOR-1` |
| 3 | `chain_id` | 16-byte bytestring | stable UUID bytes; textual UUID is a projection |
| 4 | `sequence` | unsigned integer | `1..=9_223_372_036_854_775_807` |
| 5 | `predecessor_digest` | null or 32-byte bytestring | null only for sequence 1 |
| 6 | `event_id` | 16-byte bytestring | unique within the chain |
| 7 | `event_class` | unsigned integer | one of the v1 registry codes below |
| 8 | `occurred_at` | text | sole-writer-minted UTC `YYYY-MM-DDTHH:MM:SS.ffffffZ` |
| 9 | `principal_id` | text | NFC, 1..255 UTF-8 bytes |
| 10 | `subject_id` | text | NFC, 1..255 UTF-8 bytes |
| 11 | `action` | text | NFC, 1..255 UTF-8 bytes |
| 12 | `outcome` | unsigned integer | registered outcome code |
| 13 | `diagnostic_code` | unsigned integer | zero for success; otherwise registered refusal/error |
| 14 | `payload_schema` | text | one of the v1 schema identifiers below; at most 255 UTF-8 bytes |
| 15 | `payload` | map | schema-validated; no extension keys unless payload schema permits |
| 16 | `authority_ref` | null or 32-byte bytestring | digest of appointment/grant governing the event |
| 17 | `correlation_id` | 16-byte bytestring | traces a logical operation, not an authority identity |

Unknown top-level keys, missing keys, alternate key types, duplicate keys, floats, tags, and indefinite lengths MUST be refused before semantic processing. Null, absent, empty text, empty bytes, empty array, and empty map remain distinct.

## V1 event-class and payload-schema registry

V1 admits exactly these event classes:

| Code (u16) | Symbol | Required payload schema |
|---:|---|---|
| `1` | `GENESIS` | `marshal/evd/genesis/v1` |
| `2` | `LIFECYCLE_TRANSITION` | `marshal/evd/lifecycle-transition/v1` |

Event-class code `0` is prohibited. Every code other than `1` and `2` is rejected and reserved in v1. Implementations MUST NOT allocate codes locally. A code, once assigned, is never reused for another meaning. Adding or changing a code requires a separately reviewed new registry/contract version and new fixtures; it MUST NOT silently expand v1.

### `marshal/evd/genesis/v1`

The payload is a CBOR map containing exactly nine required integer-keyed pairs:

| Key | Name | Type and rule |
|---:|---|---|
| 1 | `inventory_digest` | exactly 32-byte bytestring |
| 2 | `backup_digest` | exactly 32-byte bytestring |
| 3 | `plan_digest` | exactly 32-byte bytestring |
| 4 | `appointed_build_digest` | exactly 32-byte bytestring |
| 5 | `contract_digest` | exactly 32-byte bytestring |
| 6 | `fixture_set_digest` | exactly 32-byte bytestring |
| 7 | `canonical_profile_digest` | exactly 32-byte bytestring |
| 8 | `writer_generation` | NFC text, 1..255 UTF-8 bytes; v1 exactly `rust-authority-gen-1` |
| 9 | `chain_domain` | NFC text, 1..255 UTF-8 bytes |

There are no optional or unknown keys. Arrays and nested maps are prohibited.

### `marshal/evd/lifecycle-transition/v1`

The payload is a CBOR map containing keys 1 through 6 exactly once and optional key 7:

| Key | Name | Presence | Type and rule |
|---:|---|---|---|
| 1 | `prior_state` | required | NFC text, 1..255 UTF-8 bytes; resolves uniquely in the digest-bound lifecycle registry |
| 2 | `resulting_state` | required | NFC text, 1..255 UTF-8 bytes; resolves uniquely in the same registry domain as `prior_state` |
| 3 | `expected_revision` | required | unsigned 64-bit integer |
| 4 | `committed_revision` | required | unsigned 64-bit integer; exactly `expected_revision + 1` without overflow |
| 5 | `receipt_id` | required | NFC text, 1..255 UTF-8 bytes |
| 6 | `transition_result` | required | NFC text, 1..255 UTF-8 bytes; member of the digest-bound lifecycle-result registry |
| 7 | `source_observed_at` | optional | UTC text exactly `YYYY-MM-DDTHH:MM:SS.ffffffZ`; absent rather than null when unavailable |

The map contains exactly six or seven pairs. Unknown keys, arrays, and nested maps are prohibited. Both states must resolve unambiguously to the same component or runtime/work domain, and the ordered pair must be one of that domain's registered direct edges. Unknown, ambiguous, cross-domain, or illegal-edge pairs are refused with existing diagnostics according to precedence. The registry artifact/version/digest are derived exactly as specified in `MARSHAL-STATE-MACHINE-CANDIDATE.md`; a stale digest is never copied forward when that artifact changes. Both payload schemas remain subject to the 256 KiB canonical-payload ceiling and depth-32 complete-record ceiling.

## Outcomes

- `0` — success
- `1` — refused
- `2` — failed
- `3` — cancelled

An event whose outcome is not success MUST carry a nonzero diagnostic. A success MUST carry diagnostic zero. Diagnostics are stable facts; prose is a non-authoritative projection.

Python free-form `reason` text is excluded from canonical authority bytes. Reviewed adapters map only exact known Python outcomes to existing approved diagnostics in envelope key 13. `owner_authorization_digest`, when present in the reviewed source contract, maps to envelope `authority_ref`; it is not duplicated in either payload. An input or comparison that cannot be mapped exactly is refused/classified as `COMPARISON_INVALID` or escalated as `SPEC_AMBIGUOUS`; adapters MUST NOT invent a diagnostic or serialize free-form reason text.

## Time authorship

The sole authoritative writer mints `occurred_at` at commit preparation from its approved clock source. A caller-supplied or source-system time, when schema-permitted, is separate admitted-request metadata. It MUST NOT populate or override `occurred_at`, define ordering, or acquire authority merely by being recorded. Its field name, format, and bounds belong to the applicable payload schema.

## Genesis and linkage

Sequence 1 MUST have a null predecessor and the registered `GENESIS` event class. Every later record MUST name the digest of sequence `n-1`. A `LIFECYCLE_TRANSITION` entry cannot substitute for genesis.

## Canonical bytes and identity

1. Validate the admitted encoded request at no more than 1 MiB before parsing.
2. Validate the logical record, its registered payload schema, 256 KiB canonical-payload ceiling, 512 KiB complete-record ceiling, depth 32 including map keys, and 255-byte identity/action/schema text ceilings.
3. Encode it once under `MARSHAL-CBOR-1`, pinned to `unicode-normalization` `0.1.25` and Unicode data `17.0.0`.
4. Compute `SHA-256("marshal-core\\0evd-002\\0entry\\0v1\\0" || u64_be(canonical_byte_length) || canonical_bytes)`.
5. Store the canonical bytes and digest unchanged.

The eight-byte unsigned big-endian length is always present. Profile and Unicode changes require a new versioned canonical profile and new cross-language fixtures; they MUST NOT silently alter `MARSHAL-CBOR-1`.

Re-encoding database projections is prohibited for identity. A decoder accepting bytes that are semantically equivalent but noncanonical MUST return a canonicality diagnostic, not silently normalize them.

## Retention and content boundary

Canonical EVD entries and chain metadata, genesis records, authority appointment records, committed receipts, and checkpoint anchors are retained permanently for the lifetime of the authority domain. They are append-only or immutable according to their governing table and MUST NOT be deleted by ordinary projection-retention jobs.

External payloads, raw source material, logs, and human-readable projections follow a separate data-classification and retention policy. Secrets, PHI, PII requiring erasure, transcripts, and bulky or opaque content MUST NOT enter canonical chain bytes. Where a registered schema permits, the chain stores only a schema-approved immutable digest or reference with no embedded sensitive content. Permanent authority retention is not authorization to retain external content indefinitely.

## PostgreSQL serialization and invariants

A prospective PostgreSQL writer uses a per-chain `SELECT ... FOR UPDATE` lock as the normative minimum; global locking is prohibited. Database constraints, uniqueness, foreign keys, immutable-entry privileges/triggers, byte-length checks, sequence/head/count consistency, and idempotency receipt invariants are part of the correctness proof. `SERIALIZABLE` may be used defensively but is not required to replace the per-chain lock and invariants.

## Required fixture classes

Normative fixtures MUST cover both event classes, both payload schemas, each outcome, minimum/maximum integers, Unicode 17.0.0 normalization, exact size/depth boundaries, empty-versus-null distinctions, and multi-key payloads. Mutation twins MUST cover every missing key, unknown key, wrong type, duplicate key, reordered/non-shortest encoding, indefinite length, tags, floats, invalid UTF-8/NFC, bad or caller-overridden authoritative timestamps, sequence/link errors, unregistered codes/schemas, schema mismatch, and payload-schema violations.

## Remaining qualification work

The owner choices above are recorded but remain candidate contract text. Qualification still requires the regenerated candidate-2 lifecycle registry artifact/digest, independent file-backed golden vectors and mutation twins for both domains and every edge, cross-language equality, exact reviewed adapter mappings, contract/fixture digests, independent review, and exact-head owner ratification. No implementation may claim writer authority, activation, or cutover from this document.
