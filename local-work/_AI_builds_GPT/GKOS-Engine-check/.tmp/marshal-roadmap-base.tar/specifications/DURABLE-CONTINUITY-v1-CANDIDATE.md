# Durable Continuity v1 candidate

**Status:** candidate only; non-authoritative; unratified; unactivated.

`DURABLE-CONTINUITY-v1` is a pure contract for classifying durable state,
checking caller-supplied deployment facts, and reporting structural restore
findings. It grants no runtime, writer, filesystem, backup, restore, encryption,
installation, migration, or projection-rebuild authority.

## Identities and binding

- Contract identity: `DURABLE-CONTINUITY-v1`.
- Envelope schema: `harness/durable-continuity-envelope/v1`.
- Generated artifact receipt schema:
  `harness/generated-artifact-receipt/v1`.
- Python ABI identity: `marshal-core-python/2`.
- Full ABI tuple: `("marshal-core-python/2", "MARSHAL-CBOR-1", "EVD-002",
  "DURABLE-CONTINUITY-v1", false, false)`.

The contract identity is never accepted where an envelope or receipt schema is
required. Binding absence, tuple mismatch, malformed input, unsupported schema,
and unknown enum values fail closed. The Python facade has no semantic fallback.

The Python root tuple has exactly nine fields, in order:

`(root_id, normalized_runtime_path, authority, must_preexist, install_policy,
application_backup, application_restore, application_encryption,
application_projection_rebuild)`.

## Authority and root ownership

`application_managed` is the compatibility default. Its backup, restore, and
encryption permissions default to `permitted`. Projection rebuild defaults to
`forbidden`; it becomes eligible only on the separately declared,
application-managed root that owns the target path and explicitly sets
`application_projection_rebuild=permitted`.

`human_operator_external` is represented so the pure upstream contract can
validate and refuse it, but remains disabled and nonselectable downstream. Such
a root must preexist, must use `verify_only`, and must forbid all four
application permissions. An external root can be inspected by the two
read-only verification operations. Every mutation is refused before any
operation permission can authorize it.

Path ownership is lexical. Paths must be normalized absolute POSIX-style facts
supplied by the caller. A path implies neither authority nor existence. The
longest declared root boundary owns an overlapping path. Duplicate roots or
observations, missing observations, absent required mounts, and mapping
mismatches fail closed.

## State classes

The exhaustive v1 classes are `truth`, `operator_config`, `candidate`,
`project_artifact`, `projection`, `resumable`, `episodic`, `ephemeral`, and
`secret`. `source` is not a state class.

- Truth, configuration, candidate, resumable, episodic, and secret records are
  verified as supplied; this candidate never writes or promotes them.
- Project artifacts require a lowercase `sha256:` digest over supplied bytes.
- Missing or stale projections yield `PROJECTION_REBUILD_REQUIRED`; verification
  never rebuilds them.
- Resume requires a caller-supplied compatibility result.
- Restored ephemeral state or a request to resume it is refused.

The generated-artifact receipt records a generated derivative only. It carries
input and output SHA-256 references, exact byte count, media type, producer,
task reference, optional project and truth references, and a caller-supplied UTC
timestamp with exactly six fractional digits. It does not upgrade an artifact
to truth or prove that bytes were written.

## Deterministic precedence

The guard evaluates: contract and root validity at construction; target lexical
form; owning root; duplicate observation; missing observation; required-root
presence; mapping match; external-authority mutation; operation permission.
No mutator is called at any point.

The verifier validates the envelope before reporting other findings, then
reports quiescence, root preflight, duplicate record IDs, ephemeral restore,
artifact digest, resumable compatibility, and projection status findings. Its
findings are sorted by numeric diagnostic and subject ID. `passed=true` implies
an empty finding list.

## Stable diagnostics

Codes `8101` through `8118` cover continuity schema/envelope/path/root,
authority, restore, record, hash, compatibility, enum, and permission
refusals. In particular, `8115` is `ARTIFACT_HASH_MISMATCH`, `8117` is
`CONTINUITY_ENUM_UNKNOWN`, and `8118` is
`CONTINUITY_OPERATION_FORBIDDEN`. Receipt codes are `8120` and `8121`.
Rendered refusal identity is exactly `NNNN:SYMBOL`.

## Effect boundary

All root presence, mapping, path, quiescence, compatibility, timestamp, record,
and byte facts are supplied by a caller. The Rust implementation performs no
filesystem or path discovery, file or directory access, canonicalization,
metadata lookup, process spawn, shell, network, environment, credential, clock,
randomness, SQL, lock, queue, timer, watcher, service, or deployment work. It
exposes no callback or repair API. Python remains the sole Platform/effect and
lifecycle/evidence write owner.

Neither this candidate nor its tests authorize activation, downstream profile
selection, deployment, provider execution, publication, or release.
