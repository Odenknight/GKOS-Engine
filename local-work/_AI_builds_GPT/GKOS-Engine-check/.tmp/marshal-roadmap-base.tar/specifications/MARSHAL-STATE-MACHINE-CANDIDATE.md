# Marshal lifecycle and authority state-machine candidate

**Status:** candidate only; non-authoritative; unratified; unactivated.

## Separate domains

Component lifecycle, runtime/work lifecycle, authority, kill state, and evidence persistence are separate state domains. Implementations MUST NOT substitute one domain for another or validate a transition against a union of state names.

## Component lifecycle

States, in registry order: `INACTIVE`, `BLOCKED`, `READY`, `ACTIVE`, `SUSPENDED`.

Exactly these 13 direct transitions are allowed:

- `INACTIVE -> BLOCKED`
- `READY -> BLOCKED`
- `ACTIVE -> BLOCKED`
- `SUSPENDED -> BLOCKED`
- `INACTIVE -> READY`
- `BLOCKED -> READY`
- `SUSPENDED -> READY`
- `BLOCKED -> INACTIVE`
- `READY -> INACTIVE`
- `ACTIVE -> INACTIVE`
- `SUSPENDED -> INACTIVE`
- `READY -> ACTIVE`
- `ACTIVE -> SUSPENDED`

The component domain has no terminal-state predicate. Desired component state is separate from observed lifecycle truth. `SUSPENDED -> READY` additionally requires the persisted and current activation-context fingerprints to match, live authority, and successful preflight. Component revision advancement is checked and must equal expected revision plus one.

## Runtime/work lifecycle

States, in registry order: `CREATED`, `ADMISSION_PENDING`, `ADMITTED`, `RUNNING`, `COMPLETING`, `COMPLETED`, `REFUSED`, `FAILED`, `CANCELLED`.

Exactly these 11 direct transitions are allowed:

- `CREATED -> ADMISSION_PENDING`
- `ADMISSION_PENDING -> ADMITTED`
- `ADMISSION_PENDING -> REFUSED`
- `ADMISSION_PENDING -> CANCELLED`
- `ADMITTED -> RUNNING`
- `ADMITTED -> CANCELLED`
- `RUNNING -> COMPLETING`
- `RUNNING -> FAILED`
- `RUNNING -> CANCELLED`
- `COMPLETING -> COMPLETED`
- `COMPLETING -> FAILED`

`COMPLETED`, `REFUSED`, `FAILED`, and `CANCELLED` are the four terminal states and have no outgoing transitions. Every attempted transition, including refusal of an invalid transition, produces an evidence candidate before a successful external result is returned.

## Lifecycle registry and digest derivation

The candidate registry version is `MCR-EVD-LIFECYCLE-REGISTRY-CANDIDATE-2`. Its normative artifact is a UTF-8 TSV file with no BOM, LF line endings, and one final LF. The exact header is `# kind<TAB>domain<TAB>source<TAB>target`. Rows are emitted in this order:

1. one `meta<TAB>version<TAB>MCR-EVD-LIFECYCLE-REGISTRY-CANDIDATE-2<TAB>` row;
2. the five component `state` rows in the order above;
3. the 13 component `transition` rows in the order above;
4. the nine runtime `state` rows in the order above;
5. the 11 runtime `transition` rows in the order above;
6. four runtime `terminal` rows in the order `COMPLETED`, `REFUSED`, `FAILED`, `CANCELLED`;
7. four `result<TAB>v1` rows in the order `SUCCESS`, `REFUSED`, `FAILED`, `CANCELLED`.

For state, terminal, and result rows, the value occupies `source` and `target` is empty. The registry digest is lowercase hexadecimal SHA-256 of the complete raw TSV bytes. The generated artifact, its version, and its digest are recorded together in the fixture manifest. This specification defines the derivation and deliberately does not pin a digest from a prior or independently changing PR. Any byte, row, state, edge, terminal, result, order, or version change produces a new digest and requires review and regenerated fixtures.

For each lifecycle payload, `prior_state` and `resulting_state` must each resolve to exactly one state domain in the digest-bound registry, must resolve to the same domain, and must name one of that domain's registered direct edges. A missing, unknown, multiply resolved, cross-domain, or illegal-edge pair is refused. A validator MUST NOT guess the domain or accept an edge merely because both names exist somewhere in the registry.

## Authority

States: `ABSENT`, `PROPOSED`, `GRANTED`, `SUSPENDED`, `REVOKED`, `EXPIRED`.

Only a valid owner-appointed authority path may produce `GRANTED`. Production self-minting or self-approval is prohibited. Revocation and expiry are terminal for a grant identifier; restoration requires a new grant. Authority MUST be checked at admission, before every consequential boundary, and immediately before commit.

## Kill state

States: `CLEAR`, `HOLD`, `KILLED`. `CLEAR -> HOLD -> KILLED` and `CLEAR -> KILLED` are permitted. Clearing HOLD or KILLED requires a separately governed owner action and creates a new epoch; historical state is immutable. Work admitted under an older epoch cannot commit after the effective kill boundary.

## Append state

States: `VALIDATING`, `READY`, `LOCKED`, `STAGED`, `COMMITTED`, `REFUSED`, `INDETERMINATE`.

- Before database commit, a crash yields no authoritative append.
- After database commit, loss of acknowledgement is `INDETERMINATE` to the caller until idempotent lookup proves `COMMITTED`.
- Recovery MUST NOT invent a result.

## Transition algorithm

For every consequential action:

1. Validate input and canonical contract.
2. Read the current authority and kill epochs.
3. Evaluate policy and capability.
4. Lock the affected durable state.
5. Re-read authority, kill, lifecycle, and expected predecessor under the lock/transaction.
6. Apply exactly one permitted transition and append its EVD record atomically.
7. Return only the committed receipt.

Checks are conjunctive and fail closed. A more specific structural/canonical error takes precedence over state/policy errors only as defined by the diagnostic registry.

## Concurrency invariants

- One lifecycle version wins each compare-and-set transition.
- Duplicate idempotent requests return the original receipt.
- A reused key with different canonical request bytes is refused.
- Revocation/kill serialized before final commit prevents that commit.
- Independent chain domains do not require a global mutex.

## Idle

`IDLE` is not a persisted terminal state in this candidate. Operator-facing idle is a projection of no active runtime. If a future normative contract needs IDLE, it requires a versioned change and fixtures.

## Tests

Exhaustively classify all 25 component pairs and all 81 runtime pairs; prove exactly 13 and 11 allowed edges respectively; prove exactly four runtime terminals; and test unknown, ambiguous, cross-domain, illegal-edge, stale-version, revision-overflow, repeated-transition, revocation/kill-race, commit-ack-loss, and restart-recovery cases. Model-based tests MUST compare implementations to the digest-bound registry and these transition tables.
