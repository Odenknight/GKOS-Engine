# PostgreSQL authority persistence candidate

**Status:** candidate only; non-authoritative; unratified; unactivated.  
**Target:** PostgreSQL 15+ through SQLx.

PostgreSQL is the prospective sole production persistence authority after a separate owner-approved cutover. It preserves canonical bytes and serializes append state; it does not canonicalize authority. Python `ModuleService` remains the sole authoritative writer now. This candidate creates no Rust writer, appointment, activation, deployment, or dual-writer interval.

## Tables

`chains` stores `chain_id`, domain, generation, contract/profile identifiers, genesis-manifest digest, lifecycle, head sequence/digest, entry count, authority/kill epochs, and timestamps.

`evidence_entries` stores immutable `(chain_id, sequence)`, event and predecessor digests, exact canonical CBOR bytes, event class, idempotency key, request fingerprint, and commit timestamp. Required uniqueness: `(chain_id, sequence)`, `(chain_id, event_digest)`, `(chain_id, event_id)`, and `(chain_id, idempotency_key)`.

`append_receipts` binds each idempotency key and request fingerprint to the committed sequence, digest, diagnostic, and timestamp. `authority_appointments`, `schema_migrations`, signed `chain_checkpoints`, and a transactional notification outbox are supporting records. JSONB and extracted columns are non-authoritative projections.

Application roles MUST lack UPDATE/DELETE on evidence entries and immutable authority records. Defensive triggers reject mutation. Database constraints enforce digest and UUID byte lengths, positive sequence bounds, event class registry membership, canonical byte ceilings, valid empty/populated head combinations, `head_sequence = entry_count` for contiguous chains, genesis/null-predecessor rules, non-genesis predecessor presence, receipt-to-entry referential identity, and idempotency-key/request-fingerprint consistency. Foreign keys and uniqueness MUST make orphaned receipts, heads, appointments, or checkpoints unrepresentable.

## Normative serialization boundary

Per-chain row locking with `SELECT ... FOR UPDATE`, plus the stated database invariants, is the normative minimum. `SERIALIZABLE` may be used as a defensive or measured profile, but it does not replace the per-chain lock and invariants. Independent chains MUST NOT be globally serialized. Revocation and kill changes use the same authority-domain serialization boundary so an append cannot commit across an effective boundary.

## Append transaction

1. Enforce the 1 MiB admitted-request ceiling before parsing and validate input outside the transaction without changing state.
2. Begin transaction and lock exactly one `chains` row `FOR UPDATE`.
3. Re-check appointment, lifecycle, authority epoch, kill epoch, expected sequence and predecessor under the lock.
4. Resolve idempotency: same key/same fingerprint returns the original receipt; same key/different fingerprint refuses.
5. The sole writer mints authoritative `occurred_at`; source-system time remains separately schema-bounded metadata and cannot override ordering or authority.
6. Validate the 256 KiB payload, 512 KiB complete-record, depth-32, 255-byte text, registered event/payload schema, pinned Unicode, and canonical-byte rules.
7. Insert the immutable entry.
8. Compare-and-set chain head/count from the locked values.
9. Insert receipt and outbox record.
10. Commit; only then return success.

A crash before commit leaves no append. A lost response after commit is recovered by idempotent lookup. Retries are bounded to deadlock, serialization, and explicitly classified transient connection failures. Semantic refusals are never retried under a new key automatically.

## Startup/recovery

A future write service starts only after verifying database version/settings, migration digests, active appointment versus binary/contract/profile/fixture digests, and every active head against its last entry. A full verifier checks genesis, contiguity, predecessor links, digests, and canonical bytes. Inconsistency forces read-only forensic mode or shutdown. Recovery may rebuild disposable projections; it MUST NOT rewrite authority. Until a separate exact-head appointment and cutover, no Rust write service may start.

## Retention and content boundary

Canonical EVD entries and chain metadata, genesis records, authority appointment records, committed receipts, and checkpoint anchors are retained permanently for the lifetime of their authority domain. Ordinary retention, compaction, archival, or projection jobs MUST NOT delete or rewrite them.

External/raw payloads, logs, telemetry, outbox delivery bodies, and human-readable projections follow a separate classification and retention policy. Secrets, PHI, PII requiring erasure, transcripts, and bulky content MUST NOT enter canonical chain bytes or permanent authority tables. A registered schema may store only an approved immutable digest/reference whose target is managed under the separate policy.

## Crash matrix

Inject process kill, backend termination, connection reset, database immediate restart, WAL recovery, timeout, and disk/quota faults before/after lock, idempotency lookup, authoritative timestamp minting, entry insert, head update, receipt/outbox insert, commit, and acknowledgement. Every run proves zero-or-one append, head agreement, retry identity, no duplicate side effect, and complete verification.

## Concurrency matrix

Exercise same-chain distinct requests, identical retries, conflicting key reuse, stale heads, duplicate digests, parallel genesis, append versus seal/revoke/kill, independent chains, checkpoint races, pool exhaustion, restart under load, and randomized model-based schedules. Required: no fork/gap, exactly one winner where applicable, stable refusals, and no global serialization of independent chains.

## Observability/evidence

Structured traces exclude canonical bodies and secrets. Record correlation, chain, class, sequence, digest prefix, transaction attempt, lock wait, commit latency, retry and stable diagnostic. Qualification bundles permanently retain exact source/binary/dependency/contract/migration/PostgreSQL digests, configuration, seed, fault schedule, redacted logs, starting/final heads, database snapshot checksums, and independent verification.
