# Stable diagnostic registry candidate

**Status:** candidate only; non-authoritative; unratified; unactivated.

Diagnostics are unsigned integers. Numeric identity is stable; names and messages are projections. Once ratified, a code is never reused.

## Ranges

| Range | Class |
|---|---|
| `0` | success only |
| `1000-1999` | envelope, decoding, canonicalization |
| `2000-2999` | logical schema and contract |
| `3000-3999` | lifecycle and state transition |
| `4000-4999` | authority, appointment, capability |
| `5000-5999` | policy, egress, PHI/PII, budget |
| `6000-6999` | evidence chain and idempotency |
| `7000-7999` | persistence, concurrency, availability |
| `8000-8999` | verification and historical formats |
| `9000-9499` | protocol/version negotiation |
| `9500-9998` | internal fail-closed conditions |
| `9999` | unclassified internal refusal; forbidden in qualified normal paths |

## Initial codes

- `0 OK`
- `1001 INPUT_EMPTY`
- `1002 CBOR_MALFORMED`
- `1003 CBOR_NONCANONICAL`
- `1004 CBOR_DUPLICATE_KEY`
- `1005 CBOR_PROHIBITED_VALUE`
- `1006 TEXT_NOT_NFC`
- `2001 REQUIRED_FIELD_MISSING`
- `2002 UNKNOWN_FIELD`
- `2003 FIELD_TYPE_INVALID`
- `2004 FIELD_BOUND_INVALID`
- `2005 PAYLOAD_SCHEMA_UNKNOWN`
- `2006 PAYLOAD_SCHEMA_INVALID`
- `3001 TRANSITION_INVALID`
- `3002 STATE_TERMINAL`
- `3003 STATE_VERSION_STALE`
- `4001 APPOINTMENT_REQUIRED`
- `4002 APPOINTMENT_MISMATCH`
- `4003 AUTHORITY_ABSENT`
- `4004 AUTHORITY_EXPIRED`
- `4005 AUTHORITY_REVOKED`
- `4006 CAPABILITY_DENIED`
- `4007 KILL_SWITCH_ACTIVE`
- `5001 POLICY_DENIED`
- `5002 EGRESS_DENIED`
- `5003 SENSITIVE_DATA_DENIED`
- `5004 BUDGET_EXCEEDED`
- `6001 CHAIN_NOT_FOUND`
- `6002 CHAIN_INACTIVE`
- `6003 CHAIN_SEALED`
- `6004 SEQUENCE_MISMATCH`
- `6005 PREDECESSOR_MISMATCH`
- `6006 DIGEST_MISMATCH`
- `6007 DUPLICATE_DIGEST`
- `6008 IDEMPOTENCY_CONFLICT`
- `6009 GENESIS_INVALID`
- `7001 DATABASE_UNAVAILABLE`
- `7002 TRANSACTION_RETRY_EXHAUSTED`
- `7003 INTEGRITY_CHECK_FAILED`
- `7004 MIGRATION_MISMATCH`
- `7005 COMMIT_STATUS_INDETERMINATE`
- `8001 VERIFICATION_FAILED`
- `8002 HISTORICAL_PROFILE_UNSUPPORTED`
- `9001 PROTOCOL_VERSION_UNSUPPORTED`
- `9002 CANONICAL_PROFILE_UNSUPPORTED`
- `9501 INTERNAL_INVARIANT_BROKEN`

## Precedence

Return exactly one primary diagnostic. Collect secondary findings only in non-authoritative debug output.

1. transport/envelope bounds;
2. CBOR syntax, duplicate keys, prohibited values, canonical form and NFC;
3. logical schema and version support;
4. appointment, authority and kill state;
5. lifecycle and expected-version checks;
6. policy/capability checks;
7. chain/predecessor/idempotency semantics;
8. persistence availability and commit result;
9. internal invariant failure.

Within a level, validate fields by canonical integer-key order and return the first failing key. Security-sensitive endpoints MAY intentionally collapse outward messages, but evidence and comparator output retain the stable code.

## Adapter closure

No diagnostic codes are added by this owner decision. Adapters may emit only codes already present in the reviewed registry and only through exact, reviewed source-to-code mappings. Python free-form `reason` text is non-authoritative and MUST NOT enter canonical authority bytes. An unmapped, contradictory, or insufficiently specified case is not assigned a best-fit code: comparison setup defects become `COMPARISON_INVALID`, while genuine contract ambiguity becomes `SPEC_AMBIGUOUS` for owner adjudication. These two mismatch dispositions classify qualification results; they do not allocate new EVD diagnostic numbers.

## Change control

Adding a code requires normative positive and negative fixtures. Renaming a symbolic name does not change the numeric code. Changing precedence, meaning, or retryability is a behavioral contract change and resets the required final 1,000-clean shadow counter.
