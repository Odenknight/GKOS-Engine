# EVD-002 Rust equivalence qualification

**Status:** implementation contract candidate; no activation authority.

Rust must receive identical injected input bytes and agree with the Python
reference on acceptance/refusal, stable diagnostic, canonical bytes, digest,
predecessor linkage, and resulting chain state.

Every mismatch receives exactly one disposition:

- `PYTHON_WRONG`
- `RUST_WRONG`
- `SPEC_AMBIGUOUS`
- `COMPARISON_INVALID`

Shaun Allan Marshall adjudicates every `SPEC_AMBIGUOUS` result. Implementers
must provide the triggering input, both behaviors, ambiguity, effects, historical
compatibility, recommendation, exact proposed contract text, and affected tests.

## Appointment eligibility

Appointment eligibility requires:

1. all normative and mutation fixtures passing;
2. the 100,000-entry deterministic chain test passing;
3. PostgreSQL crash and concurrency matrices passing;
4. zero unresolved mismatches;
5. 10,000 representative shadow comparisons with required per-class coverage;
6. 1,000 consecutive clean comparisons after the final behavioral change; and
7. explicit owner authorization naming the exact Rust build, contract and
   fixture digests, and greenfield genesis manifest.

Eligibility is not activation. Only the owner-signed appointment record makes
Rust the sole writer. The Python verifier remains permanently read-only and its
historical JCS records are not imported into the production chain.
