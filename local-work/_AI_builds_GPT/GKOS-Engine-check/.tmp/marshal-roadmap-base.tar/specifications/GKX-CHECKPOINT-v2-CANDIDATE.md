# GKX Checkpoint Contract v2 — CBOR candidate

**Status:** candidate; not ratified, implemented, published, or activated

Version 2 supersedes v1 only for new greenfield Marshal Core checkpoints. It
does not reinterpret or modify any v1 artifact.

## Locked direction

- Canonical profile: `MARSHAL-CBOR-1`.
- Artifact schema: separately versioned `gkx/checkpoint/v2`.
- Hash: SHA-256 over domain-separated canonical CBOR bytes.
- Writer generation: `rust-authority-gen-1` for the greenfield chain.
- Publication: asynchronous from a committed outbox.
- Delivery: idempotent, retryable, and unable to roll back local authority.
- External publication remains disabled until separately authorized.

## Required contract work

The checkpoint engineer must carry forward or deliberately amend every v1
semantic property: range bounds, predecessor linkage, cadence, signatures,
anchor receipts, reason codes, retry classifications, and verification results.
Every difference from v1 requires a requirement ID and owner-visible rationale.

