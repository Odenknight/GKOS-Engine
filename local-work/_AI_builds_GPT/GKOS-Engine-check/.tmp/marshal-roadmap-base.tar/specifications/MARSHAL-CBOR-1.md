# MARSHAL-CBOR-1

**Status:** implementation candidate; owner-selected profile  
**Depends on:** GKOS v0.80 `GKX-CBOR-1` and R16  
**Activation authority:** none

`MARSHAL-CBOR-1` defines canonical bytes for new Marshal Core authority-bearing
artifacts. It is a strict subset of `GKX-CBOR-1`. Python `ModuleService`
remains the sole authoritative lifecycle writer; this profile grants no Rust
writer, activation, appointment, or cutover.

## Required encoding

- RFC 8949 Core Deterministic Encoding.
- Definite-length strings, arrays, and maps only.
- Shortest valid integer and length encoding.
- Map keys ordered first by the length of their canonical encoded key bytes,
  then bytewise lexicographically among keys of equal encoded length, as required
  by RFC 8949 Core Deterministic Encoding.
- Duplicate map keys rejected before semantic processing.
- UTF-8 text normalized to NFC using `unicode-normalization` `0.1.25`, whose generated tables are Unicode `17.0.0`; compiled `UNICODE_VERSION` must equal `(17, 0, 0)`.
- Absent, explicit null, empty string, empty bytes, empty array, and empty map are
  distinct values and may not be substituted for one another.
- Timestamps use UTC exactly as `YYYY-MM-DDTHH:MM:SS.ffffffZ` unless a versioned
  artifact schema defines a stricter representation.
- SHA-256 provides canonical artifact identity with an artifact-specific domain
  separator.

## Conservative v1 resource bounds

- Admitted encoded request: at most 1 MiB.
- Canonical payload map: at most 256 KiB.
- Complete canonical EVD record: at most 512 KiB.
- Arrays and maps, including values used as map keys, share one maximum nesting depth of 32 from the complete record root.
- Identity, action, and schema text fields: at most 255 UTF-8 bytes each.
- Large artifacts, transcripts, secrets, PHI, and opaque blobs are not embedded in EVD records; a schema-approved immutable digest or reference is used instead.

These are byte ceilings, not authority grants. A future writer must enforce the admitted-request bound before parsing. The canonical layer enforces the complete-record bound; schema validators enforce payload and field-specific bounds. Any change requires a versioned contract amendment and new fixtures.

## Prohibited values

- All floating-point values, including finite values.
- Negative zero, NaN, and infinities.
- Indefinite-length encoding.
- Duplicate keys.
- Unnormalized text.
- Values outside the bounded integer domain declared by the artifact schema.
- Unrecognized tags, simple values, or canonical profile versions.

## Human rendering

Human-readable JSON, Markdown, or diagnostic output is a projection. It is not
hashed as authority. A deterministic parser/render round-trip test must prove
that a supported rendering reconstructs the same logical artifact and canonical
CBOR bytes where a rendering claim is made.

## EVD-002 entry digest candidate

The exact v1 preimage is:

```text
SHA-256(
  UTF-8("marshal-core") || 0x00 ||
  UTF-8("evd-002")      || 0x00 ||
  UTF-8("entry")        || 0x00 ||
  UTF-8("v1")           || 0x00 ||
  u64_be(canonical_byte_length) ||
  canonical_entry_bytes
)
```

The eight-byte unsigned big-endian length is always present. This domain is
exclusive to EVD-002 entry identity. Genesis, checkpoints, appointments,
fixtures, shadow records, and qualification reports require their own reviewed
domains and fixtures; this candidate does not allocate them.

## Profile versioning

`MARSHAL-CBOR-1` is bound to the exact encoding rules, resource ceilings,
`unicode-normalization` `0.1.25`, and Unicode `17.0.0` data above. Any
dependency or Unicode-table change that can affect accepted text or canonical
bytes requires a new canonical-profile version and complete cross-language
regeneration; silent upgrades are prohibited.

## Open qualification work

This candidate requires normative vectors, mutation twins, cross-language
Python/Rust fixtures, schema-specific integer and collection-count bounds, and
independent verification before it may be labeled qualified.
