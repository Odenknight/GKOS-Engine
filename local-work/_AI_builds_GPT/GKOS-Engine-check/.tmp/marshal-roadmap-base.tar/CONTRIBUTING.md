# Contributing

Contributions are not accepted by default. Open an issue before submitting code.

A contributor must sign the then-current Contributor License Agreement before a
pull request can be accepted. This protects the contributor's authorship while
allowing the project owner to distribute the combined work under commercial,
royalty-bearing, source-available, or future license terms.

All commits must include a Developer Certificate of Origin sign-off (`git commit
-s`). A sign-off does not replace the Contributor License Agreement.

No contribution may contain confidential information or code incompatible with
the repository license. Third-party material must be identified with its source,
version, exact license, and copied portions in `THIRD-PARTY-NOTICES.md`.

