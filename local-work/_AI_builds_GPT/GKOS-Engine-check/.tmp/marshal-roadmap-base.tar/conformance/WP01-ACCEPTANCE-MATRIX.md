# WP-01 acceptance and qualification matrix

**Status:** candidate planning matrix; passing it does not activate Rust.

| Gate | Minimum evidence |
|---|---|
| Governing registration | TheMarshal-008 PR #55 exact authorized head `0898ee476fc857df60aae70d5f03f7fda8bc57ef` is merged and reachable at `416b4e637339c344bc5522a65cb1223cd1f8caa0`; effect is limited to candidate non-authoritative migration/parity work |
| Contract completeness | u16 event codes 1/2 frozen with 0 prohibited and all other v1 codes rejected/reserved; exact closed 9-pair genesis and 6-or-7-pair lifecycle payload maps; writer-minted time, digest formula, Unicode pin, locking/invariants, retention boundary, transitions, diagnostics and precedence frozen; no unreviewed adapter mapping |
| Normative fixtures | both v1 events and schemas, every outcome/boundary, exact canonical bytes/digest, Unicode and 1 MiB/256 KiB/512 KiB/depth-32/text-255 boundaries |
| Mutation fixtures | every missing/unknown payload key, wrong key/type/length, prohibited array/nested map/null optional time, event code 0/reserved code, schema mismatch, revision overflow/nonincrement, CLC/result nonmember, free-form reason injection, and each canonical/link/state mutation refused with the exact existing code |
| Rust canonical | all fixtures plus property tests; zero unsafe Rust |
| Python comparator | same injected CBOR bytes and logical inputs; acceptance/code/bytes/digest/state compared |
| State model | all 25 component pairs and 81 runtime pairs classified; exactly 13 component and 11 runtime direct edges; exactly four runtime terminals; same-domain resolution and edge legality enforced from the digest-bound candidate-2 registry |
| PostgreSQL append | per-chain `FOR UPDATE`; database invariants; atomic entry/head/receipt/outbox; idempotent lost-ack recovery; writer-minted `occurred_at` |
| 100,000 chain | real PostgreSQL writer; restart; genesis-to-head independent verification |
| Crash matrix | all specified injection points/fault classes; zero partial state |
| Concurrency matrix | same/different chain schedules; no fork/gap; stable winner/refusal |
| Shadow total | at least 10,000 representative comparisons with required per-class coverage |
| Final clean streak | 1,000 consecutive clean comparisons after final behavioral change |
| Mismatch ledger | zero unresolved; each mismatch has one approved disposition |
| Reproducibility | content-addressed evidence bundle with exact environment and seed |
| Retention/content | canonical authority records retained for domain lifetime; separate classified external/raw retention; no secrets, PHI, or bulky content in chain |
| Independent review | security/invariant review separate from implementing lanes |
| Appointment eligibility | exact build, contract, fixture and genesis-manifest digests named |

## Exact payload acceptance tests

- Genesis accepts exactly keys 1..9 with seven 32-byte digests, exact v1 writer generation, and bounded NFC chain domain; every missing, unknown, reordered-semantic, wrong-type, wrong-length, array, or nested-map twin is covered.
- Lifecycle transition accepts exactly required keys 1..6 and optionally key 7, verifies the candidate registry version and derived digest, requires both states to resolve uniquely within the same component or runtime/work domain, enforces the registered direct edge, requires `committed_revision = expected_revision + 1` without overflow, and distinguishes absent key 7 from prohibited null.
- Registry mutations cover unknown state, ambiguous membership, cross-domain pair, illegal same-domain edge, stale digest, row reorder, missing/extra edge, terminal change, version change, missing final LF, CRLF, and BOM.
- Event class is decoded as u16: only `1` and `2` are accepted, `0` is prohibited, and all other v1 values are rejected/reserved.
- Python free-form `reason` never changes canonical bytes or digests. Only exact reviewed source mappings may populate the existing envelope diagnostic. Unmapped adapter cases exercise `COMPARISON_INVALID` or `SPEC_AMBIGUOUS` without minting codes.
- `owner_authorization_digest` maps only to envelope `authority_ref` and is absent from both closed payload maps.

## Required shadow classes

The matrix MUST allocate nonzero minimums for: accepted genesis/append; each event class; each outcome; canonical refusal classes; schema refusal classes; component/runtime lifecycle accepted edges; lifecycle invalid/stale/terminal/cross-domain/ambiguous-registry cases; authority absent/expired/revoked; kill active; policy refusal; predecessor/sequence mismatch; identical idempotent retry; conflicting key reuse; database retry; lost acknowledgement; restart recovery; and historical read-only verification. Counts must sum to at least 10,000 and no class may be satisfied only by synthetic duplicates.

## Mismatch record

Capture input bytes/digest, logical rendering, Python behavior, Rust behavior, resulting state, classification (`PYTHON_WRONG`, `RUST_WRONG`, `SPEC_AMBIGUOUS`, `COMPARISON_INVALID`), rationale, affected fixtures, adjudicator, resolution commit and evidence digest. Only Shaun Allan Marshall adjudicates `SPEC_AMBIGUOUS`.

## Reset rules

Any change to canonical bytes, digest, acceptance/refusal, diagnostic identity/precedence, state transition, transaction outcome, retry semantics, or observable chain state resets the 1,000-clean counter. Documentation-only changes that provably cannot affect behavior do not.

## Authority boundary

Passing this matrix does not appoint or activate a Rust writer. Python `ModuleService` remains the sole authoritative lifecycle writer until a separate exact-head owner-approved cutover. No qualification run may create a dual-writer interval.
