# Conformance harness

This directory will contain the cross-language runner, mismatch reports,
mutation twins, crash matrix, concurrency matrix, and shadow qualification
reports. It must distinguish `UNEVALUATED`, `PASS`, and `FAIL`; absence of
evidence is never a pass.

