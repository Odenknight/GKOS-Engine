# ADR-0001 — Greenfield CBOR authority

**Status:** accepted by owner  
**Date:** 2026-08-23  
**Owner:** Shaun Allan Marshall

## Decision

Marshal Core Rust is a greenfield authority implementation. All new authority,
evidence, receipt, approval, checkpoint, and governed interchange artifacts use
deterministic CBOR. The profile is `MARSHAL-CBOR-1`, a no-floating-point subset
of GKOS `GKX-CBOR-1` for authority-bearing records.

Existing Python/JCS EVD-002 and GKX checkpoint v1 materials are pre-production
qualification history. They are preserved without modification but are not
imported as an authoritative production chain. No JCS writer is implemented in
the Rust authority.

Python retained for differential qualification consumes the same logical
fixtures and CBOR vectors. It is not an independent serialization authority.

GKX checkpoint v1 remains historically intact and is superseded for new work by
a separately versioned CBOR checkpoint v2. Historical hashes are never rewritten.

## Consequences

- The first Rust writer is `rust-authority-gen-1`, because no production Python
  authority precedes it in the greenfield chain.
- There is no Python-to-Rust production-chain transition record.
- JCS fixtures may be retained only as labeled historical regression material.
- New canonical values reject floating point, indefinite lengths, duplicate map
  keys, invalid Unicode normalization, and unknown canonical versions.
- JSON remains permitted for non-authoritative operator APIs and diagnostics;
  clients never submit authoritative canonical bytes.

