# Ratified owner decisions

## 2026-08-23 — Rust Core and EVD-002

- EVD-002 is the first lane of the broader Marshal Core Rust rebuild.
- Implementation lives in both this reusable Core repository and TheMarshal-008
  as the reference/integration repository.
- Shaun Allan Marshall adjudicates all `SPEC_AMBIGUOUS` cases.
- Shaun Allan Marshall is the sole greenfield appointment authority.
- The Python verifier is retained permanently for historical verification and
  remains permanently read-only and non-authoritative.
- The qualification threshold is recorded in the EVD-002 specification and work packet.

## 2026-08-23 — Greenfield canonical authority

- All new authoritative artifacts use deterministic CBOR.
- Authority and evidence records prohibit floating-point values.
- Existing Python/JCS artifacts are preserved as non-production history and are
  not migrated into the production chain.
- The first production writer is `rust-authority-gen-1`.
- New GKX checkpoints require a separately qualified CBOR v2 contract.
