#![doc = "Module SDK boundary; G-M1..G-M12 definitions require authority intake."]

pub const CONFORMANCE_GATES: [&str; 12] = [
    "G-M1", "G-M2", "G-M3", "G-M4", "G-M5", "G-M6", "G-M7", "G-M8", "G-M9", "G-M10", "G-M11",
    "G-M12",
];
