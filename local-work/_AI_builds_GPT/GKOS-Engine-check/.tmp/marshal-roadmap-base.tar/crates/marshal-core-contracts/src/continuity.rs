//! Durable-continuity v1 values and stable refusal identities.
//!
//! This module contains values only. It performs no filesystem discovery and
//! grants no deployment, runtime, or writer authority.

use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;
use std::fmt;

pub const CONTINUITY_SCHEMA: &str = "harness/durable-continuity-envelope/v1";
pub const CONTINUITY_CONTRACT_ID: &str = "DURABLE-CONTINUITY-v1";

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DurabilityAuthority {
    ApplicationManaged,
    HumanOperatorExternal,
}

impl Default for DurabilityAuthority {
    fn default() -> Self {
        Self::ApplicationManaged
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum InstallPolicy {
    Managed,
    VerifyOnly,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Permission {
    Permitted,
    Forbidden,
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum StateClass {
    Truth,
    OperatorConfig,
    Candidate,
    ProjectArtifact,
    Projection,
    Resumable,
    Episodic,
    Ephemeral,
    Secret,
}

impl StateClass {
    pub const ALL: [Self; 9] = [
        Self::Truth,
        Self::OperatorConfig,
        Self::Candidate,
        Self::ProjectArtifact,
        Self::Projection,
        Self::Resumable,
        Self::Episodic,
        Self::Ephemeral,
        Self::Secret,
    ];
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RecoveryMode {
    ExternalInPlace,
    Rebuild,
    Never,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MutationMode {
    GovernedRuntimeOnly,
    AtomicWrite,
    ReviewedPromotionOnly,
    ExplicitRebuildOnly,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct StateClassPolicy {
    pub state_class: StateClass,
    pub recovery: RecoveryMode,
    pub mutation: Option<MutationMode>,
}

impl StateClassPolicy {
    fn is_v1_profile(&self) -> bool {
        let expected = match self.state_class {
            StateClass::Truth | StateClass::Resumable | StateClass::Episodic => (
                RecoveryMode::ExternalInPlace,
                Some(MutationMode::GovernedRuntimeOnly),
            ),
            StateClass::OperatorConfig | StateClass::Secret => (
                RecoveryMode::ExternalInPlace,
                Some(MutationMode::AtomicWrite),
            ),
            StateClass::Candidate => (
                RecoveryMode::ExternalInPlace,
                Some(MutationMode::ReviewedPromotionOnly),
            ),
            StateClass::ProjectArtifact => (RecoveryMode::ExternalInPlace, None),
            StateClass::Projection => (
                RecoveryMode::Rebuild,
                Some(MutationMode::ExplicitRebuildOnly),
            ),
            StateClass::Ephemeral => (RecoveryMode::Never, None),
        };
        (self.recovery, self.mutation) == expected
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DurableRoot {
    pub root_id: String,
    pub normalized_runtime_path: String,
    #[serde(default)]
    pub authority: DurabilityAuthority,
    pub must_preexist: bool,
    pub install_policy: InstallPolicy,
    pub application_backup: Permission,
    pub application_restore: Permission,
    pub application_encryption: Permission,
    pub application_projection_rebuild: Permission,
}

impl DurableRoot {
    #[must_use]
    pub fn application_managed(
        root_id: impl Into<String>,
        normalized_runtime_path: impl Into<String>,
    ) -> Self {
        Self {
            root_id: root_id.into(),
            normalized_runtime_path: normalized_runtime_path.into(),
            authority: DurabilityAuthority::ApplicationManaged,
            must_preexist: false,
            install_policy: InstallPolicy::Managed,
            application_backup: Permission::Permitted,
            application_restore: Permission::Permitted,
            application_encryption: Permission::Permitted,
            application_projection_rebuild: Permission::Forbidden,
        }
    }

    /// Validate product-independent root facts without consulting a filesystem.
    ///
    /// # Errors
    /// Returns the first stable continuity diagnostic for malformed or
    /// internally inconsistent values.
    pub fn validate(&self) -> Result<(), ContinuityRefusal> {
        if !valid_token(&self.root_id, 160) {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::ContinuityEnvelopeInvalid,
                Some(self.root_id.clone()),
                None,
            ));
        }
        validate_normalized_path(&self.normalized_runtime_path).map_err(|diagnostic| {
            ContinuityRefusal::new(diagnostic, Some(self.root_id.clone()), None)
        })?;
        if self.authority == DurabilityAuthority::HumanOperatorExternal
            && (!self.must_preexist
                || self.install_policy != InstallPolicy::VerifyOnly
                || self.application_backup != Permission::Forbidden
                || self.application_restore != Permission::Forbidden
                || self.application_encryption != Permission::Forbidden
                || self.application_projection_rebuild != Permission::Forbidden)
        {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::ContinuityEnvelopeInvalid,
                Some(self.root_id.clone()),
                None,
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
#[allow(clippy::struct_excessive_bools)]
pub struct RecoveryPolicy {
    pub quiesce_before_external_restore: bool,
    pub verify_before_writers: bool,
    pub projections_may_be_rebuilt: bool,
    pub live_mount_restore_by_application: bool,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DurableContinuityEnvelopeV1 {
    pub schema: String,
    pub deployment_id: String,
    pub roots: Vec<DurableRoot>,
    pub state_classes: Vec<StateClassPolicy>,
    pub recovery: RecoveryPolicy,
}

impl DurableContinuityEnvelopeV1 {
    /// Validate all envelope values without inspecting runtime state.
    ///
    /// # Errors
    /// Returns the first stable continuity diagnostic. Root order never changes
    /// the decision.
    pub fn validate(&self) -> Result<(), ContinuityRefusal> {
        validate_contract_header(&self.schema, &self.deployment_id)?;
        validate_roots(&self.roots)?;
        let classes: BTreeSet<_> = self
            .state_classes
            .iter()
            .map(|policy| policy.state_class)
            .collect();
        if classes.len() != self.state_classes.len()
            || classes != StateClass::ALL.into_iter().collect()
            || self
                .state_classes
                .iter()
                .any(|policy| !policy.is_v1_profile())
        {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::ContinuityEnvelopeInvalid,
                None,
                None,
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LifecycleOperation {
    VerifyPreflight,
    VerifyRestoredState,
    Initialize,
    Seed,
    Migrate,
    RecursiveChown,
    RecursiveChmod,
    Backup,
    RestoreFetch,
    RestoreDecrypt,
    RestoreDelete,
    RestoreExtract,
    Encrypt,
    ProjectionRebuild,
}

impl LifecycleOperation {
    #[must_use]
    pub const fn is_read_only(self) -> bool {
        matches!(self, Self::VerifyPreflight | Self::VerifyRestoredState)
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd, Serialize, Deserialize)]
#[repr(u16)]
#[allow(clippy::module_name_repetitions)]
pub enum ContinuityDiagnostic {
    ContinuitySchemaUnsupported = 8101,
    ContinuityEnvelopeInvalid = 8102,
    NormalizedPathInvalid = 8103,
    DurableRootAmbiguous = 8104,
    DurableRootFactMissing = 8105,
    DurableMountMissing = 8106,
    DurableRootMappingMismatch = 8107,
    ExternalDurabilityAuthority = 8108,
    ProjectionRebuildRequired = 8109,
    EphemeralRestoreRefused = 8110,
    WritersNotQuiesced = 8111,
    DreamStateNotQuiesced = 8112,
    RestoredRecordDuplicate = 8113,
    ArtifactHashMissing = 8114,
    ArtifactHashMismatch = 8115,
    ResumableCompatibilityMissing = 8116,
    ContinuityEnumUnknown = 8117,
    ContinuityOperationForbidden = 8118,
    ArtifactReceiptSchemaInvalid = 8120,
    ArtifactReceiptInvalid = 8121,
}

impl ContinuityDiagnostic {
    #[must_use]
    pub const fn symbol(self) -> &'static str {
        match self {
            Self::ContinuitySchemaUnsupported => "CONTINUITY_SCHEMA_UNSUPPORTED",
            Self::ContinuityEnvelopeInvalid => "CONTINUITY_ENVELOPE_INVALID",
            Self::NormalizedPathInvalid => "NORMALIZED_PATH_INVALID",
            Self::DurableRootAmbiguous => "DURABLE_ROOT_AMBIGUOUS",
            Self::DurableRootFactMissing => "DURABLE_ROOT_FACT_MISSING",
            Self::DurableMountMissing => "DURABLE_MOUNT_MISSING",
            Self::DurableRootMappingMismatch => "DURABLE_ROOT_MAPPING_MISMATCH",
            Self::ExternalDurabilityAuthority => "EXTERNAL_DURABILITY_AUTHORITY",
            Self::ProjectionRebuildRequired => "PROJECTION_REBUILD_REQUIRED",
            Self::EphemeralRestoreRefused => "EPHEMERAL_RESTORE_REFUSED",
            Self::WritersNotQuiesced => "WRITERS_NOT_QUIESCED",
            Self::DreamStateNotQuiesced => "DREAM_STATE_NOT_QUIESCED",
            Self::RestoredRecordDuplicate => "RESTORED_RECORD_DUPLICATE",
            Self::ArtifactHashMissing => "ARTIFACT_HASH_MISSING",
            Self::ArtifactHashMismatch => "ARTIFACT_HASH_MISMATCH",
            Self::ResumableCompatibilityMissing => "RESUMABLE_COMPATIBILITY_MISSING",
            Self::ContinuityEnumUnknown => "CONTINUITY_ENUM_UNKNOWN",
            Self::ContinuityOperationForbidden => "CONTINUITY_OPERATION_FORBIDDEN",
            Self::ArtifactReceiptSchemaInvalid => "ARTIFACT_RECEIPT_SCHEMA_INVALID",
            Self::ArtifactReceiptInvalid => "ARTIFACT_RECEIPT_INVALID",
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[allow(clippy::module_name_repetitions)]
pub struct ContinuityRefusal {
    pub diagnostic: ContinuityDiagnostic,
    pub root_id: Option<String>,
    pub operation: Option<LifecycleOperation>,
}

impl ContinuityRefusal {
    #[must_use]
    pub const fn new(
        diagnostic: ContinuityDiagnostic,
        root_id: Option<String>,
        operation: Option<LifecycleOperation>,
    ) -> Self {
        Self {
            diagnostic,
            root_id,
            operation,
        }
    }
}

impl fmt::Display for ContinuityRefusal {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            formatter,
            "{}:{}",
            self.diagnostic as u16,
            self.diagnostic.symbol()
        )
    }
}

impl std::error::Error for ContinuityRefusal {}

/// Validate the contract identity and deployment token.
///
/// # Errors
/// Returns a stable schema or envelope diagnostic.
pub fn validate_contract_header(
    schema: &str,
    deployment_id: &str,
) -> Result<(), ContinuityRefusal> {
    if schema != CONTINUITY_SCHEMA {
        return Err(ContinuityRefusal::new(
            ContinuityDiagnostic::ContinuitySchemaUnsupported,
            None,
            None,
        ));
    }
    if !valid_token(deployment_id, 160) {
        return Err(ContinuityRefusal::new(
            ContinuityDiagnostic::ContinuityEnvelopeInvalid,
            None,
            None,
        ));
    }
    Ok(())
}

/// Validate caller-supplied lexical roots and reject ambiguous duplicates.
///
/// # Errors
/// Returns the first stable root validation diagnostic.
pub fn validate_roots(roots: &[DurableRoot]) -> Result<(), ContinuityRefusal> {
    if roots.is_empty() {
        return Err(ContinuityRefusal::new(
            ContinuityDiagnostic::ContinuityEnvelopeInvalid,
            None,
            None,
        ));
    }
    let mut ids = BTreeSet::new();
    let mut paths = BTreeSet::new();
    for root in roots {
        root.validate()?;
        if !ids.insert(root.root_id.as_str())
            || !paths.insert(root.normalized_runtime_path.as_str())
        {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::DurableRootAmbiguous,
                Some(root.root_id.clone()),
                None,
            ));
        }
    }
    Ok(())
}

/// Validate a caller-supplied normalized absolute POSIX-style path.
///
/// This proves lexical form only. It does not claim that a path exists, is a
/// mount, resolves to a host path, or is free of symlinks.
///
/// # Errors
/// Returns `NORMALIZED_PATH_INVALID` for relative, empty, dot-segment,
/// repeated-separator, trailing-separator, backslash, or control-byte input.
pub fn validate_normalized_path(path: &str) -> Result<(), ContinuityDiagnostic> {
    if path == "/" {
        return Ok(());
    }
    if path.is_empty()
        || !path.starts_with('/')
        || path.contains('\\')
        || path.chars().any(char::is_control)
        || (path.len() > 1 && path.ends_with('/'))
        || path
            .split('/')
            .skip(1)
            .any(|part| part.is_empty() || matches!(part, "." | ".."))
    {
        Err(ContinuityDiagnostic::NormalizedPathInvalid)
    } else {
        Ok(())
    }
}

fn valid_token(value: &str, maximum: usize) -> bool {
    !value.is_empty()
        && value.len() <= maximum
        && value.is_ascii()
        && value
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'.' | b'_' | b'-' | b':'))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn application_managed_is_the_compatibility_default() {
        assert_eq!(
            DurabilityAuthority::default(),
            DurabilityAuthority::ApplicationManaged
        );
        assert_eq!(
            DurableRoot::application_managed("primary", "/opt/marshal/usr").validate(),
            Ok(())
        );
    }

    #[test]
    fn external_profile_requires_verify_only_and_forbidden_application_actions() {
        let mut root = DurableRoot::application_managed("external", "/durable");
        root.authority = DurabilityAuthority::HumanOperatorExternal;
        assert_eq!(
            root.validate().map_err(|error| error.diagnostic),
            Err(ContinuityDiagnostic::ContinuityEnvelopeInvalid)
        );
        root.must_preexist = true;
        root.install_policy = InstallPolicy::VerifyOnly;
        root.application_backup = Permission::Forbidden;
        root.application_restore = Permission::Forbidden;
        root.application_encryption = Permission::Forbidden;
        root.application_projection_rebuild = Permission::Forbidden;
        assert_eq!(root.validate(), Ok(()));
    }

    #[test]
    fn normalized_paths_are_lexical_facts_not_discovery() {
        assert_eq!(validate_normalized_path("/"), Ok(()));
        assert_eq!(validate_normalized_path("/a/b"), Ok(()));
        for invalid in ["", "relative", "/a/../b", "/a/./b", "/a//b", "/a/", "\\a"] {
            assert_eq!(
                validate_normalized_path(invalid),
                Err(ContinuityDiagnostic::NormalizedPathInvalid)
            );
        }
    }
}
