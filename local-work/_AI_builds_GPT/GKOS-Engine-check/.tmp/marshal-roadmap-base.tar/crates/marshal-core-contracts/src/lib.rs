#![doc = "Stable, product-independent candidate contracts for Marshal Core."]

use serde::{Deserialize, Serialize};

pub mod artifact_receipt;
pub mod continuity;

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Digest32(pub [u8; 32]);

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum MismatchDisposition {
    PythonWrong,
    RustWrong,
    SpecAmbiguous,
    ComparisonInvalid,
}

/// Diagnostic identities already present in the candidate registry.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u16)]
pub enum DiagnosticCode {
    PayloadSchemaInvalid = 2006,
    TransitionInvalid = 3001,
    StateTerminal = 3002,
    StateVersionStale = 3003,
    InternalInvariantBroken = 9501,
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct Revision(u64);

impl Revision {
    #[must_use]
    pub const fn new(value: u64) -> Self {
        Self(value)
    }
    #[must_use]
    pub const fn get(self) -> u64 {
        self.0
    }
    fn checked_next(self) -> Result<Self, DiagnosticCode> {
        self.0
            .checked_add(1)
            .map(Self)
            .ok_or(DiagnosticCode::InternalInvariantBroken)
    }
}

/// CLC component lifecycle, separate from the work/runtime lifecycle.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ComponentLifecycleState {
    Inactive,
    Blocked,
    Ready,
    Active,
    Suspended,
}

impl ComponentLifecycleState {
    pub const ALL: [Self; 5] = [
        Self::Inactive,
        Self::Blocked,
        Self::Ready,
        Self::Active,
        Self::Suspended,
    ];
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DesiredComponentState {
    Active,
    Inactive,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ReasonClass {
    Dependency,
    Authority,
    Governance,
    Configuration,
    Preflight,
    Continuity,
    Incident,
    Operator,
    Cleanup,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LifecycleReason {
    pub class: ReasonClass,
    pub code: String,
}

impl LifecycleReason {
    /// # Errors
    /// Returns `PAYLOAD_SCHEMA_INVALID` when `code` is blank.
    pub fn new(class: ReasonClass, code: impl Into<String>) -> Result<Self, DiagnosticCode> {
        let code = code.into();
        if code.trim().is_empty() {
            return Err(DiagnosticCode::PayloadSchemaInvalid);
        }
        Ok(Self { class, code })
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ComponentLifecycleRecord {
    desired_state: DesiredComponentState,
    observed_state: ComponentLifecycleState,
    revision: Revision,
    activation_context_fingerprint: Option<String>,
    reasons: Vec<LifecycleReason>,
    suspension_cause: Option<String>,
}

impl ComponentLifecycleRecord {
    #[must_use]
    pub const fn inactive(desired_state: DesiredComponentState) -> Self {
        Self {
            desired_state,
            observed_state: ComponentLifecycleState::Inactive,
            revision: Revision::new(0),
            activation_context_fingerprint: None,
            reasons: Vec::new(),
            suspension_cause: None,
        }
    }
    #[must_use]
    pub const fn desired_state(&self) -> DesiredComponentState {
        self.desired_state
    }
    #[must_use]
    pub const fn observed_state(&self) -> ComponentLifecycleState {
        self.observed_state
    }
    #[must_use]
    pub const fn revision(&self) -> Revision {
        self.revision
    }
    #[must_use]
    pub fn activation_context_fingerprint(&self) -> Option<&str> {
        self.activation_context_fingerprint.as_deref()
    }
    #[must_use]
    pub fn reasons(&self) -> &[LifecycleReason] {
        &self.reasons
    }
    #[must_use]
    pub fn suspension_cause(&self) -> Option<&str> {
        self.suspension_cause.as_deref()
    }
}

/// Opaque proof that the authority boundary has validated live authority,
/// activation-context equality, and preflight success for recovery.
///
/// Public callers may carry a proof received from a future authority-boundary
/// adapter, but cannot construct or deserialize one in this candidate slice.
///
/// ```compile_fail
/// use marshal_core_contracts::RecoveryProof;
/// let forged = RecoveryProof {
///     persisted_activation_context_fingerprint: "caller-asserted".to_owned(),
///     current_activation_context_fingerprint: "caller-asserted".to_owned(),
///     _authority_boundary: (),
/// };
/// ```
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RecoveryProof {
    persisted_activation_context_fingerprint: String,
    current_activation_context_fingerprint: String,
    _authority_boundary: (),
}

impl RecoveryProof {
    #[cfg(test)]
    fn qualified_for_test(
        persisted_activation_context_fingerprint: impl Into<String>,
        current_activation_context_fingerprint: impl Into<String>,
    ) -> Self {
        Self {
            persisted_activation_context_fingerprint: persisted_activation_context_fingerprint
                .into(),
            current_activation_context_fingerprint: current_activation_context_fingerprint.into(),
            _authority_boundary: (),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ComponentTransitionRequest {
    pub expected_state: ComponentLifecycleState,
    pub expected_revision: Revision,
    pub target_state: ComponentLifecycleState,
    pub activation_context_fingerprint: Option<String>,
    pub reasons: Vec<LifecycleReason>,
    pub suspension_cause: Option<String>,
    pub recovery_proof: Option<RecoveryProof>,
}

#[must_use]
pub const fn component_transition_allowed(
    source: ComponentLifecycleState,
    target: ComponentLifecycleState,
) -> bool {
    use ComponentLifecycleState::{Active, Blocked, Inactive, Ready, Suspended};
    matches!(
        (source, target),
        (Inactive | Ready | Active | Suspended, Blocked)
            | (Inactive | Blocked | Suspended, Ready)
            | (Blocked | Ready | Active | Suspended, Inactive)
            | (Ready, Active)
            | (Active, Suspended)
    )
}

/// Evaluate a non-authoritative component lifecycle candidate transition.
///
/// # Errors
/// Returns an approved diagnostic for stale input, an invalid edge/invariant, or revision exhaustion.
pub fn evaluate_component_transition(
    current: &ComponentLifecycleRecord,
    request: ComponentTransitionRequest,
) -> Result<ComponentLifecycleRecord, DiagnosticCode> {
    if current.observed_state != request.expected_state
        || current.revision != request.expected_revision
    {
        return Err(DiagnosticCode::StateVersionStale);
    }
    if !component_transition_allowed(current.observed_state, request.target_state) {
        return Err(DiagnosticCode::TransitionInvalid);
    }
    let mut activation_context = request
        .activation_context_fingerprint
        .or_else(|| current.activation_context_fingerprint.clone());
    let mut suspension_cause = request.suspension_cause;
    if current.observed_state == ComponentLifecycleState::Suspended
        && request.target_state == ComponentLifecycleState::Ready
    {
        let recovery = request
            .recovery_proof
            .as_ref()
            .ok_or(DiagnosticCode::PayloadSchemaInvalid)?;
        if recovery.persisted_activation_context_fingerprint
            != recovery.current_activation_context_fingerprint
            || current.activation_context_fingerprint.as_deref()
                != Some(recovery.persisted_activation_context_fingerprint.as_str())
        {
            return Err(DiagnosticCode::PayloadSchemaInvalid);
        }
        activation_context = Some(recovery.current_activation_context_fingerprint.clone());
    }
    if matches!(
        request.target_state,
        ComponentLifecycleState::Active | ComponentLifecycleState::Suspended
    ) && activation_context.as_deref().is_none_or(str::is_empty)
    {
        return Err(DiagnosticCode::PayloadSchemaInvalid);
    }
    if request.target_state == ComponentLifecycleState::Active
        && current.desired_state != DesiredComponentState::Active
    {
        return Err(DiagnosticCode::PayloadSchemaInvalid);
    }
    if matches!(
        request.target_state,
        ComponentLifecycleState::Blocked | ComponentLifecycleState::Suspended
    ) && request.reasons.is_empty()
    {
        return Err(DiagnosticCode::PayloadSchemaInvalid);
    }
    if request.target_state == ComponentLifecycleState::Suspended
        && suspension_cause.as_deref().is_none_or(str::is_empty)
    {
        return Err(DiagnosticCode::PayloadSchemaInvalid);
    }
    if request.target_state != ComponentLifecycleState::Suspended {
        suspension_cause = None;
    }
    if request.target_state == ComponentLifecycleState::Inactive {
        activation_context = None;
    }
    Ok(ComponentLifecycleRecord {
        desired_state: current.desired_state,
        observed_state: request.target_state,
        revision: current.revision.checked_next()?,
        activation_context_fingerprint: activation_context,
        reasons: request.reasons,
        suspension_cause,
    })
}

/// Work/runtime lifecycle, separate from the CLC component lifecycle.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeLifecycleState {
    Created,
    AdmissionPending,
    Admitted,
    Running,
    Completing,
    Completed,
    Refused,
    Failed,
    Cancelled,
}

impl RuntimeLifecycleState {
    pub const ALL: [Self; 9] = [
        Self::Created,
        Self::AdmissionPending,
        Self::Admitted,
        Self::Running,
        Self::Completing,
        Self::Completed,
        Self::Refused,
        Self::Failed,
        Self::Cancelled,
    ];
    #[must_use]
    pub const fn is_terminal(self) -> bool {
        matches!(
            self,
            Self::Completed | Self::Refused | Self::Failed | Self::Cancelled
        )
    }
}

#[must_use]
pub const fn runtime_transition_allowed(
    source: RuntimeLifecycleState,
    target: RuntimeLifecycleState,
) -> bool {
    use RuntimeLifecycleState::{
        AdmissionPending, Admitted, Cancelled, Completed, Completing, Created, Failed, Refused,
        Running,
    };
    matches!(
        (source, target),
        (Created, AdmissionPending)
            | (AdmissionPending, Admitted | Refused | Cancelled)
            | (Admitted, Running | Cancelled)
            | (Running, Completing | Failed | Cancelled)
            | (Completing, Completed | Failed)
    )
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct RuntimeLifecycleRecord {
    state: RuntimeLifecycleState,
    revision: Revision,
}

impl RuntimeLifecycleRecord {
    #[must_use]
    pub const fn created() -> Self {
        Self {
            state: RuntimeLifecycleState::Created,
            revision: Revision::new(0),
        }
    }
    #[must_use]
    pub const fn from_parts(state: RuntimeLifecycleState, revision: Revision) -> Self {
        Self { state, revision }
    }
    #[must_use]
    pub const fn state(self) -> RuntimeLifecycleState {
        self.state
    }
    #[must_use]
    pub const fn revision(self) -> Revision {
        self.revision
    }
}

/// Evaluate a non-authoritative work/runtime lifecycle candidate transition.
///
/// # Errors
/// Returns an approved diagnostic for stale input, terminal state, invalid edge, or revision exhaustion.
pub fn evaluate_runtime_transition(
    current: RuntimeLifecycleRecord,
    expected_revision: Revision,
    target: RuntimeLifecycleState,
) -> Result<RuntimeLifecycleRecord, DiagnosticCode> {
    if current.revision != expected_revision {
        return Err(DiagnosticCode::StateVersionStale);
    }
    if current.state.is_terminal() {
        return Err(DiagnosticCode::StateTerminal);
    }
    if !runtime_transition_allowed(current.state, target) {
        return Err(DiagnosticCode::TransitionInvalid);
    }
    Ok(RuntimeLifecycleRecord {
        state: target,
        revision: current.revision.checked_next()?,
    })
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct CutoverThreshold {
    pub deterministic_chain_entries: u64,
    pub representative_shadow_comparisons: u64,
    pub consecutive_clean_after_change: u64,
    pub unresolved_mismatches: u64,
}
impl CutoverThreshold {
    pub const RATIFIED: Self = Self {
        deterministic_chain_entries: 100_000,
        representative_shadow_comparisons: 10_000,
        consecutive_clean_after_change: 1_000,
        unresolved_mismatches: 0,
    };
}

#[cfg(test)]
mod tests {
    use super::*;
    fn reason() -> LifecycleReason {
        LifecycleReason::new(ReasonClass::Continuity, "continuity_lost").unwrap()
    }
    fn component_request(
        source: ComponentLifecycleState,
        target: ComponentLifecycleState,
    ) -> ComponentTransitionRequest {
        ComponentTransitionRequest {
            expected_state: source,
            expected_revision: Revision::new(0),
            target_state: target,
            activation_context_fingerprint: Some("acf:1".to_owned()),
            reasons: vec![reason()],
            suspension_cause: Some("required_dependency_lost".to_owned()),
            recovery_proof: Some(RecoveryProof::qualified_for_test("acf:1", "acf:1")),
        }
    }

    #[test]
    fn component_matrix_classifies_all_25_pairs_and_exactly_13_edges() {
        let mut allowed = 0;
        let mut classified = 0;
        for source in ComponentLifecycleState::ALL {
            for target in ComponentLifecycleState::ALL {
                classified += 1;
                if component_transition_allowed(source, target) {
                    allowed += 1;
                }
            }
        }
        assert_eq!(classified, 25);
        assert_eq!(allowed, 13);
    }

    #[test]
    fn component_enforces_context_reason_and_revision_invariants() {
        let inactive = ComponentLifecycleRecord::inactive(DesiredComponentState::Active);
        let ready = evaluate_component_transition(
            &inactive,
            component_request(
                ComponentLifecycleState::Inactive,
                ComponentLifecycleState::Ready,
            ),
        )
        .unwrap();
        let mut activate = component_request(
            ComponentLifecycleState::Ready,
            ComponentLifecycleState::Active,
        );
        activate.expected_revision = Revision::new(1);
        let active = evaluate_component_transition(&ready, activate).unwrap();
        assert_eq!(active.observed_state(), ComponentLifecycleState::Active);
        let mut stale = component_request(
            ComponentLifecycleState::Active,
            ComponentLifecycleState::Suspended,
        );
        stale.expected_revision = Revision::new(1);
        assert_eq!(
            evaluate_component_transition(&active, stale),
            Err(DiagnosticCode::StateVersionStale)
        );
        let mut missing_reason = component_request(
            ComponentLifecycleState::Active,
            ComponentLifecycleState::Suspended,
        );
        missing_reason.expected_revision = Revision::new(2);
        missing_reason.reasons.clear();
        assert_eq!(
            evaluate_component_transition(&active, missing_reason),
            Err(DiagnosticCode::PayloadSchemaInvalid)
        );
    }

    #[test]
    fn suspended_recovery_fails_closed_without_an_authority_bound_proof() {
        let current = ComponentLifecycleRecord {
            desired_state: DesiredComponentState::Active,
            observed_state: ComponentLifecycleState::Suspended,
            revision: Revision::new(7),
            activation_context_fingerprint: Some("acf:1".to_owned()),
            reasons: vec![reason()],
            suspension_cause: Some("hold".to_owned()),
        };
        let mut request = component_request(
            ComponentLifecycleState::Suspended,
            ComponentLifecycleState::Ready,
        );
        request.expected_revision = Revision::new(7);
        request.recovery_proof = None;
        assert_eq!(
            evaluate_component_transition(&current, request),
            Err(DiagnosticCode::PayloadSchemaInvalid)
        );
    }

    #[test]
    fn internal_qualified_recovery_proof_permits_only_the_ready_barrier() {
        let current = ComponentLifecycleRecord {
            desired_state: DesiredComponentState::Active,
            observed_state: ComponentLifecycleState::Suspended,
            revision: Revision::new(7),
            activation_context_fingerprint: Some("acf:1".to_owned()),
            reasons: vec![reason()],
            suspension_cause: Some("hold".to_owned()),
        };
        let mut request = component_request(
            ComponentLifecycleState::Suspended,
            ComponentLifecycleState::Ready,
        );
        request.expected_revision = Revision::new(7);
        let ready = evaluate_component_transition(&current, request).unwrap();
        assert_eq!(ready.observed_state(), ComponentLifecycleState::Ready);
        assert_eq!(ready.activation_context_fingerprint(), Some("acf:1"));
    }

    #[test]
    fn direct_suspended_to_active_is_refused() {
        assert!(!component_transition_allowed(
            ComponentLifecycleState::Suspended,
            ComponentLifecycleState::Active
        ));
    }

    #[test]
    fn runtime_matrix_classifies_all_81_pairs_and_exact_edges() {
        let mut allowed = 0;
        let mut classified = 0;
        for source in RuntimeLifecycleState::ALL {
            for target in RuntimeLifecycleState::ALL {
                classified += 1;
                if runtime_transition_allowed(source, target) {
                    allowed += 1;
                }
            }
        }
        assert_eq!(classified, 81);
        assert_eq!(allowed, 11);
    }

    #[test]
    fn runtime_has_exactly_four_terminal_states_and_cannot_reopen_them() {
        let terminals: Vec<_> = RuntimeLifecycleState::ALL
            .into_iter()
            .filter(|state| state.is_terminal())
            .collect();
        assert_eq!(terminals.len(), 4);
        for terminal in terminals {
            for target in RuntimeLifecycleState::ALL {
                assert!(!runtime_transition_allowed(terminal, target));
                assert_eq!(
                    evaluate_runtime_transition(
                        RuntimeLifecycleRecord::from_parts(terminal, Revision::new(4)),
                        Revision::new(4),
                        target
                    ),
                    Err(DiagnosticCode::StateTerminal)
                );
            }
        }
    }

    #[test]
    fn revision_overflow_fails_closed() {
        assert_eq!(
            evaluate_runtime_transition(
                RuntimeLifecycleRecord::from_parts(
                    RuntimeLifecycleState::Created,
                    Revision::new(u64::MAX)
                ),
                Revision::new(u64::MAX),
                RuntimeLifecycleState::AdmissionPending
            ),
            Err(DiagnosticCode::InternalInvariantBroken)
        );
    }

    #[test]
    fn ratified_threshold_is_not_weakened() {
        assert_eq!(
            CutoverThreshold::RATIFIED.deterministic_chain_entries,
            100_000
        );
        assert_eq!(
            CutoverThreshold::RATIFIED.representative_shadow_comparisons,
            10_000
        );
        assert_eq!(
            CutoverThreshold::RATIFIED.consecutive_clean_after_change,
            1_000
        );
        assert_eq!(CutoverThreshold::RATIFIED.unresolved_mismatches, 0);
    }
}
