//! Generated-artifact receipt v1.

use crate::continuity::{ContinuityDiagnostic, ContinuityRefusal};
use serde::{Deserialize, Deserializer, Serialize};

pub const GENERATED_ARTIFACT_RECEIPT_SCHEMA: &str = "harness/generated-artifact-receipt/v1";

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(transparent)]
pub struct Sha256Ref(String);

impl Sha256Ref {
    /// Construct a validated lowercase SHA-256 reference.
    ///
    /// # Errors
    /// Returns `ARTIFACT_RECEIPT_INVALID` for any other representation.
    pub fn new(value: impl Into<String>) -> Result<Self, ContinuityRefusal> {
        let value = value.into();
        let valid = value.strip_prefix("sha256:").is_some_and(|hex| {
            hex.len() == 64
                && hex
                    .bytes()
                    .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
        });
        if valid {
            Ok(Self(value))
        } else {
            Err(invalid())
        }
    }

    #[must_use]
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl<'de> Deserialize<'de> for Sha256Ref {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let value = String::deserialize(deserializer)?;
        Self::new(value).map_err(serde::de::Error::custom)
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(transparent)]
pub struct ReceiptTimestamp(String);

impl ReceiptTimestamp {
    /// Construct the exact UTC microsecond timestamp used by this candidate.
    ///
    /// # Errors
    /// Returns `ARTIFACT_RECEIPT_INVALID` for malformed or impossible values.
    pub fn new(value: impl Into<String>) -> Result<Self, ContinuityRefusal> {
        let value = value.into();
        if valid_timestamp(&value) {
            Ok(Self(value))
        } else {
            Err(invalid())
        }
    }

    #[must_use]
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl<'de> Deserialize<'de> for ReceiptTimestamp {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let value = String::deserialize(deserializer)?;
        Self::new(value).map_err(serde::de::Error::custom)
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ArtifactAuthority {
    GeneratedDerivative,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct GeneratedArtifactReceiptV1 {
    schema: String,
    artifact_ref: String,
    project_ref: Option<String>,
    task_ref: String,
    producer: String,
    input_hash: Sha256Ref,
    output_hash: Sha256Ref,
    bytes: u64,
    media_type: String,
    created_at: ReceiptTimestamp,
    authority: ArtifactAuthority,
    truth_ref: Option<String>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ReceiptWire {
    schema: String,
    artifact_ref: String,
    project_ref: Option<String>,
    task_ref: String,
    producer: String,
    input_hash: Sha256Ref,
    output_hash: Sha256Ref,
    bytes: u64,
    media_type: String,
    created_at: ReceiptTimestamp,
    authority: ArtifactAuthority,
    truth_ref: Option<String>,
}

impl<'de> Deserialize<'de> for GeneratedArtifactReceiptV1 {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let wire = ReceiptWire::deserialize(deserializer)?;
        Self::from_wire(wire).map_err(serde::de::Error::custom)
    }
}

impl GeneratedArtifactReceiptV1 {
    /// Construct and validate a generated-derivative receipt.
    ///
    /// # Errors
    /// Returns a stable receipt diagnostic when any supplied identifier,
    /// digest, timestamp, or media type violates the v1 contract.
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        artifact_ref: impl Into<String>,
        project_ref: Option<String>,
        task_ref: impl Into<String>,
        producer: impl Into<String>,
        input_hash: Sha256Ref,
        output_hash: Sha256Ref,
        bytes: u64,
        media_type: impl Into<String>,
        created_at: ReceiptTimestamp,
        truth_ref: Option<String>,
    ) -> Result<Self, ContinuityRefusal> {
        Self::from_wire(ReceiptWire {
            schema: GENERATED_ARTIFACT_RECEIPT_SCHEMA.to_owned(),
            artifact_ref: artifact_ref.into(),
            project_ref,
            task_ref: task_ref.into(),
            producer: producer.into(),
            input_hash,
            output_hash,
            bytes,
            media_type: media_type.into(),
            created_at,
            authority: ArtifactAuthority::GeneratedDerivative,
            truth_ref,
        })
    }

    fn from_wire(wire: ReceiptWire) -> Result<Self, ContinuityRefusal> {
        if wire.schema != GENERATED_ARTIFACT_RECEIPT_SCHEMA {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::ArtifactReceiptSchemaInvalid,
                None,
                None,
            ));
        }
        if !valid_ref(&wire.artifact_ref)
            || !wire.project_ref.as_deref().is_none_or(valid_ref)
            || !valid_ref(&wire.task_ref)
            || !valid_ref(&wire.producer)
            || !wire.truth_ref.as_deref().is_none_or(valid_ref)
            || !valid_media_type(&wire.media_type)
        {
            return Err(invalid());
        }
        Ok(Self {
            schema: wire.schema,
            artifact_ref: wire.artifact_ref,
            project_ref: wire.project_ref,
            task_ref: wire.task_ref,
            producer: wire.producer,
            input_hash: wire.input_hash,
            output_hash: wire.output_hash,
            bytes: wire.bytes,
            media_type: wire.media_type,
            created_at: wire.created_at,
            authority: wire.authority,
            truth_ref: wire.truth_ref,
        })
    }

    #[must_use]
    pub fn artifact_ref(&self) -> &str {
        &self.artifact_ref
    }

    #[must_use]
    pub const fn bytes(&self) -> u64 {
        self.bytes
    }

    #[must_use]
    pub fn output_hash(&self) -> &Sha256Ref {
        &self.output_hash
    }
}

fn invalid() -> ContinuityRefusal {
    ContinuityRefusal::new(ContinuityDiagnostic::ArtifactReceiptInvalid, None, None)
}

fn valid_ref(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 512
        && !value.chars().any(char::is_control)
        && !value.chars().any(char::is_whitespace)
}

fn valid_media_type(value: &str) -> bool {
    let Some((kind, subtype)) = value.split_once('/') else {
        return false;
    };
    !kind.is_empty()
        && !subtype.is_empty()
        && !subtype.contains('/')
        && value.is_ascii()
        && value.bytes().all(|byte| {
            byte.is_ascii_alphanumeric()
                || matches!(
                    byte,
                    b'!' | b'#' | b'$' | b'&' | b'-' | b'^' | b'_' | b'.' | b'+' | b'/'
                )
        })
}

fn valid_timestamp(value: &str) -> bool {
    let bytes = value.as_bytes();
    let punctuation = [
        (4, b'-'),
        (7, b'-'),
        (10, b'T'),
        (13, b':'),
        (16, b':'),
        (19, b'.'),
        (26, b'Z'),
    ];
    if bytes.len() != 27
        || punctuation
            .iter()
            .any(|(index, byte)| bytes[*index] != *byte)
        || bytes.iter().enumerate().any(|(index, byte)| {
            !punctuation.iter().any(|(position, _)| *position == index) && !byte.is_ascii_digit()
        })
    {
        return false;
    }
    let number = |start: usize, end: usize| -> Option<u32> {
        std::str::from_utf8(&bytes[start..end]).ok()?.parse().ok()
    };
    let (Some(year), Some(month), Some(day), Some(hour), Some(minute), Some(second)) = (
        number(0, 4),
        number(5, 7),
        number(8, 10),
        number(11, 13),
        number(14, 16),
        number(17, 19),
    ) else {
        return false;
    };
    let leap = year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    let max_day = match month {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 if leap => 29,
        2 => 28,
        _ => return false,
    };
    year != 0 && day != 0 && day <= max_day && hour < 24 && minute < 60 && second < 60
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn receipt_construction_validates_hash_time_and_media_type() {
        let hash = Sha256Ref::new(format!("sha256:{}", "a".repeat(64))).unwrap();
        let created_at = ReceiptTimestamp::new("2026-08-29T00:00:00.000000Z").unwrap();
        let receipt = GeneratedArtifactReceiptV1::new(
            "artifact/example",
            None,
            "task/example",
            "package/example",
            hash.clone(),
            hash,
            0,
            "application/octet-stream",
            created_at,
            None,
        )
        .unwrap();
        assert_eq!(receipt.artifact_ref(), "artifact/example");
        assert_eq!(receipt.bytes(), 0);
        assert!(Sha256Ref::new(format!("sha256:{}", "A".repeat(64))).is_err());
        assert!(ReceiptTimestamp::new("2026-08-29T00:00:00Z").is_err());
    }
}
