//! Pure durable-continuity guard decisions.
//!
//! Every path, presence, and mapping value in this module is a caller-supplied
//! lexical fact. This module performs no discovery and grants no authority.

use marshal_core_contracts::continuity::{
    validate_contract_header, validate_normalized_path, validate_roots, ContinuityDiagnostic,
    ContinuityRefusal, DurabilityAuthority, DurableRoot, InstallPolicy, LifecycleOperation,
    Permission,
};
use std::collections::BTreeSet;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RootObservation {
    pub root_id: String,
    pub present: bool,
    pub mapping_matches: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
#[allow(clippy::module_name_repetitions)]
pub struct ContinuityFacts {
    pub normalized_path: String,
    pub roots: Vec<RootObservation>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum GuardDisposition {
    Allowed,
    OutsideDeclaredRoots,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GuardDecision {
    pub disposition: GuardDisposition,
    pub root_id: Option<String>,
    pub authority: Option<DurabilityAuthority>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DurabilityGuardV1 {
    deployment_id: String,
    roots: Vec<DurableRoot>,
}

impl DurabilityGuardV1 {
    /// Construct a pure guard from explicit contract values.
    ///
    /// # Errors
    /// Returns the first stable contract diagnostic. No runtime facts are
    /// discovered while constructing the guard.
    pub fn new(
        schema: &str,
        deployment_id: impl Into<String>,
        roots: Vec<DurableRoot>,
    ) -> Result<Self, ContinuityRefusal> {
        let deployment_id = deployment_id.into();
        validate_contract_header(schema, &deployment_id)?;
        validate_roots(&roots)?;
        Ok(Self {
            deployment_id,
            roots,
        })
    }

    #[must_use]
    pub fn deployment_id(&self) -> &str {
        &self.deployment_id
    }

    /// Decide from supplied lexical facts with deterministic refusal precedence.
    ///
    /// Precedence is: contract at construction; normalized target path; owning
    /// root; duplicate/missing observation; missing root; mapping mismatch;
    /// external-authority mutation refusal.
    ///
    /// # Errors
    /// Returns the first stable continuity refusal. It never invokes a mutator.
    pub fn decide(
        &self,
        facts: &ContinuityFacts,
        operation: LifecycleOperation,
    ) -> Result<GuardDecision, ContinuityRefusal> {
        validate_normalized_path(&facts.normalized_path)
            .map_err(|diagnostic| ContinuityRefusal::new(diagnostic, None, Some(operation)))?;
        let Some(root) = self.owning_root(&facts.normalized_path) else {
            return Ok(GuardDecision {
                disposition: GuardDisposition::OutsideDeclaredRoots,
                root_id: None,
                authority: None,
            });
        };
        let mut seen = BTreeSet::new();
        let mut matching = None;
        for observation in &facts.roots {
            if !seen.insert(observation.root_id.as_str()) {
                return Err(ContinuityRefusal::new(
                    ContinuityDiagnostic::DurableRootAmbiguous,
                    Some(observation.root_id.clone()),
                    Some(operation),
                ));
            }
            if observation.root_id == root.root_id {
                matching = Some(observation);
            }
        }
        let Some(observation) = matching else {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::DurableRootFactMissing,
                Some(root.root_id.clone()),
                Some(operation),
            ));
        };
        if root.must_preexist && !observation.present {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::DurableMountMissing,
                Some(root.root_id.clone()),
                Some(operation),
            ));
        }
        if !observation.mapping_matches {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::DurableRootMappingMismatch,
                Some(root.root_id.clone()),
                Some(operation),
            ));
        }
        if root.authority == DurabilityAuthority::HumanOperatorExternal && !operation.is_read_only()
        {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::ExternalDurabilityAuthority,
                Some(root.root_id.clone()),
                Some(operation),
            ));
        }
        if operation_forbidden(root, operation) {
            return Err(ContinuityRefusal::new(
                ContinuityDiagnostic::ContinuityOperationForbidden,
                Some(root.root_id.clone()),
                Some(operation),
            ));
        }
        Ok(GuardDecision {
            disposition: GuardDisposition::Allowed,
            root_id: Some(root.root_id.clone()),
            authority: Some(root.authority),
        })
    }

    fn owning_root(&self, normalized_path: &str) -> Option<&DurableRoot> {
        self.roots
            .iter()
            .filter(|root| path_is_within(normalized_path, &root.normalized_runtime_path))
            .max_by(|left, right| {
                left.normalized_runtime_path
                    .len()
                    .cmp(&right.normalized_runtime_path.len())
                    .then_with(|| right.root_id.cmp(&left.root_id))
            })
    }
}

fn operation_forbidden(root: &DurableRoot, operation: LifecycleOperation) -> bool {
    use LifecycleOperation::{
        Backup, Encrypt, Initialize, Migrate, RecursiveChmod, RecursiveChown, RestoreDecrypt,
        RestoreDelete, RestoreExtract, RestoreFetch, Seed,
    };
    match operation {
        Initialize | Seed | Migrate | RecursiveChown | RecursiveChmod => {
            root.install_policy == InstallPolicy::VerifyOnly
        }
        Backup => root.application_backup == Permission::Forbidden,
        RestoreFetch | RestoreDecrypt | RestoreDelete | RestoreExtract => {
            root.application_restore == Permission::Forbidden
        }
        Encrypt => root.application_encryption == Permission::Forbidden,
        LifecycleOperation::ProjectionRebuild => {
            root.application_projection_rebuild == Permission::Forbidden
        }
        LifecycleOperation::VerifyPreflight | LifecycleOperation::VerifyRestoredState => false,
    }
}

fn path_is_within(path: &str, root: &str) -> bool {
    if root == "/" {
        return path.starts_with('/');
    }
    path == root
        || path
            .strip_prefix(root)
            .is_some_and(|remainder| remainder.starts_with('/'))
}

#[cfg(test)]
mod tests {
    use super::*;
    use marshal_core_contracts::continuity::CONTINUITY_SCHEMA;
    use marshal_core_contracts::continuity::{InstallPolicy, Permission};

    fn external(root_id: &str, path: &str) -> DurableRoot {
        DurableRoot {
            root_id: root_id.to_owned(),
            normalized_runtime_path: path.to_owned(),
            authority: DurabilityAuthority::HumanOperatorExternal,
            must_preexist: true,
            install_policy: InstallPolicy::VerifyOnly,
            application_backup: Permission::Forbidden,
            application_restore: Permission::Forbidden,
            application_encryption: Permission::Forbidden,
            application_projection_rebuild: Permission::Forbidden,
        }
    }

    fn facts(path: &str, observations: Vec<RootObservation>) -> ContinuityFacts {
        ContinuityFacts {
            normalized_path: path.to_owned(),
            roots: observations,
        }
    }

    fn observed(root_id: &str, present: bool, mapping_matches: bool) -> RootObservation {
        RootObservation {
            root_id: root_id.to_owned(),
            present,
            mapping_matches,
        }
    }

    #[test]
    fn application_managed_preserves_current_behavior() {
        let guard = DurabilityGuardV1::new(
            CONTINUITY_SCHEMA,
            "deployment",
            vec![DurableRoot::application_managed("primary", "/durable")],
        )
        .unwrap();
        let decision = guard
            .decide(
                &facts("/durable/data", vec![observed("primary", true, true)]),
                LifecycleOperation::RestoreDelete,
            )
            .unwrap();
        assert_eq!(decision.disposition, GuardDisposition::Allowed);
        assert_eq!(
            decision.authority,
            Some(DurabilityAuthority::ApplicationManaged)
        );
    }

    #[test]
    fn external_refusal_precedes_no_operation_and_follows_missing_mapping_facts() {
        let guard = DurabilityGuardV1::new(
            CONTINUITY_SCHEMA,
            "deployment",
            vec![external("primary", "/durable")],
        )
        .unwrap();
        assert_eq!(
            guard
                .decide(
                    &facts("/durable/data", vec![observed("primary", false, false)]),
                    LifecycleOperation::Backup,
                )
                .map_err(|error| error.diagnostic),
            Err(ContinuityDiagnostic::DurableMountMissing)
        );
        assert_eq!(
            guard
                .decide(
                    &facts("/durable/data", vec![observed("primary", true, false)]),
                    LifecycleOperation::Backup,
                )
                .map_err(|error| error.diagnostic),
            Err(ContinuityDiagnostic::DurableRootMappingMismatch)
        );
        assert_eq!(
            guard
                .decide(
                    &facts("/durable/data", vec![observed("primary", true, true)]),
                    LifecycleOperation::Backup,
                )
                .map_err(|error| error.diagnostic),
            Err(ContinuityDiagnostic::ExternalDurabilityAuthority)
        );
    }

    #[test]
    fn longest_matching_root_owns_overlapping_paths() {
        let guard = DurabilityGuardV1::new(
            CONTINUITY_SCHEMA,
            "deployment",
            vec![external("parent", "/durable"), {
                let mut projection =
                    DurableRoot::application_managed("projection", "/durable/projection");
                projection.application_projection_rebuild = Permission::Permitted;
                projection
            }],
        )
        .unwrap();
        let decision = guard
            .decide(
                &facts(
                    "/durable/projection/index",
                    vec![
                        observed("parent", true, true),
                        observed("projection", true, true),
                    ],
                ),
                LifecycleOperation::ProjectionRebuild,
            )
            .unwrap();
        assert_eq!(decision.root_id.as_deref(), Some("projection"));
    }

    #[test]
    fn external_projection_rebuild_is_not_a_bypass() {
        let guard = DurabilityGuardV1::new(
            CONTINUITY_SCHEMA,
            "deployment",
            vec![external("primary", "/durable")],
        )
        .unwrap();
        assert_eq!(
            guard
                .decide(
                    &facts("/durable/index", vec![observed("primary", true, true)]),
                    LifecycleOperation::ProjectionRebuild,
                )
                .map_err(|error| error.diagnostic),
            Err(ContinuityDiagnostic::ExternalDurabilityAuthority)
        );
    }

    #[test]
    fn application_managed_permissions_are_enforced_without_changing_defaults() {
        let mut root = DurableRoot::application_managed("primary", "/durable");
        root.application_backup = Permission::Forbidden;
        let guard = DurabilityGuardV1::new(CONTINUITY_SCHEMA, "deployment", vec![root]).unwrap();
        assert_eq!(
            guard
                .decide(
                    &facts("/durable/data", vec![observed("primary", true, true)]),
                    LifecycleOperation::Backup,
                )
                .map_err(|error| error.diagnostic),
            Err(ContinuityDiagnostic::ContinuityOperationForbidden)
        );
    }

    #[test]
    fn projection_rebuild_requires_a_separately_permitted_projection_root() {
        for root_id in ["truth", "config"] {
            let root = DurableRoot::application_managed(root_id, format!("/durable/{root_id}"));
            let guard =
                DurabilityGuardV1::new(CONTINUITY_SCHEMA, "deployment", vec![root]).unwrap();
            assert_eq!(
                guard
                    .decide(
                        &facts(
                            &format!("/durable/{root_id}/value"),
                            vec![observed(root_id, true, true)],
                        ),
                        LifecycleOperation::ProjectionRebuild,
                    )
                    .map_err(|error| error.diagnostic),
                Err(ContinuityDiagnostic::ContinuityOperationForbidden)
            );
        }
    }
}
