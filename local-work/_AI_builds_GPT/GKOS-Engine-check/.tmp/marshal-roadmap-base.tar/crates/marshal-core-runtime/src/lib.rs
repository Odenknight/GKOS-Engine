#![doc = "Runtime admission boundary. Product dispatch is not implemented."]

use marshal_core_authority::{require_sole_writer, AuthorityError, AuthorityGate};

pub mod continuity;

/// Enforce the sole-writer boundary before product dispatch.
///
/// # Errors
///
/// Returns [`AuthorityError::NotAppointed`] unless the owner has appointed Rust.
pub fn require_write_authority(gate: &AuthorityGate) -> Result<(), AuthorityError> {
    require_sole_writer(gate)
}
