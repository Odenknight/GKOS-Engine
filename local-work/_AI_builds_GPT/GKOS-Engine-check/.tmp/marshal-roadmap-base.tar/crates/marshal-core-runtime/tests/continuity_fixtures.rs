use marshal_core_contracts::continuity::{
    ContinuityDiagnostic, DurabilityAuthority, DurableRoot, InstallPolicy, LifecycleOperation,
    Permission, CONTINUITY_SCHEMA,
};
use marshal_core_runtime::continuity::{
    ContinuityFacts, DurabilityGuardV1, GuardDisposition, RootObservation,
};

const CASES: &str = include_str!("../../../fixtures/continuity/v1/guard-cases.tsv");

fn external() -> DurableRoot {
    DurableRoot {
        root_id: "primary".to_owned(),
        normalized_runtime_path: "/opt/marshal/usr".to_owned(),
        authority: DurabilityAuthority::HumanOperatorExternal,
        must_preexist: true,
        install_policy: InstallPolicy::VerifyOnly,
        application_backup: Permission::Forbidden,
        application_restore: Permission::Forbidden,
        application_encryption: Permission::Forbidden,
        application_projection_rebuild: Permission::Forbidden,
    }
}

fn roots(scenario: &str) -> Vec<DurableRoot> {
    match scenario {
        "application" => vec![DurableRoot::application_managed(
            "primary",
            "/opt/marshal/usr",
        )],
        "external" => vec![external()],
        "overlap" => vec![external(), {
            let mut projection =
                DurableRoot::application_managed("projection", "/opt/marshal/usr/projection");
            projection.application_projection_rebuild = Permission::Permitted;
            projection
        }],
        _ => panic!("unknown fixture scenario {scenario}"),
    }
}

fn operation(value: &str) -> LifecycleOperation {
    match value {
        "verify_preflight" => LifecycleOperation::VerifyPreflight,
        "backup" => LifecycleOperation::Backup,
        "restore_delete" => LifecycleOperation::RestoreDelete,
        "projection_rebuild" => LifecycleOperation::ProjectionRebuild,
        _ => panic!("unknown fixture operation {value}"),
    }
}

fn bool_value(value: &str) -> bool {
    match value {
        "true" => true,
        "false" => false,
        _ => panic!("unknown fixture boolean {value}"),
    }
}

#[test]
fn exact_guard_cases_preserve_refusal_precedence() {
    let mut count = 0_usize;
    for line in CASES.lines().filter(|line| !line.starts_with('#')) {
        if line.is_empty() {
            continue;
        }
        count += 1;
        let fields: Vec<_> = line.split('\t').collect();
        assert_eq!(fields.len(), 7, "fixture {}", fields[0]);
        let scenario_roots = roots(fields[1]);
        let guard = DurabilityGuardV1::new(CONTINUITY_SCHEMA, "deployment", scenario_roots.clone())
            .expect("fixture guard");
        let observations = scenario_roots
            .iter()
            .map(|root| RootObservation {
                root_id: root.root_id.clone(),
                present: bool_value(fields[3]),
                mapping_matches: bool_value(fields[4]),
            })
            .collect();
        let result = guard.decide(
            &ContinuityFacts {
                normalized_path: fields[2].to_owned(),
                roots: observations,
            },
            operation(fields[5]),
        );
        let actual = match result {
            Ok(decision) if decision.disposition == GuardDisposition::OutsideDeclaredRoots => {
                "outside_declared_roots".to_owned()
            }
            Ok(decision) => format!(
                "allowed:{}:{}",
                decision.root_id.as_deref().unwrap_or(""),
                match decision.authority {
                    Some(DurabilityAuthority::ApplicationManaged) => "application_managed",
                    Some(DurabilityAuthority::HumanOperatorExternal) => {
                        "human_operator_external"
                    }
                    None => "",
                }
            ),
            Err(error) => error.to_string(),
        };
        assert_eq!(actual, fields[6], "fixture {}", fields[0]);
    }
    assert_eq!(count, 9, "fixture count is a coverage guard");
    assert_eq!(
        ContinuityDiagnostic::ExternalDurabilityAuthority as u16,
        8108
    );
}
