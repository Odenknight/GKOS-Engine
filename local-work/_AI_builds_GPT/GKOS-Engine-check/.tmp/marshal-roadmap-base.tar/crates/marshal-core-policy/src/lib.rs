#![doc = "Policy decision contracts. No PHI classifier is claimed by this bootstrap."]

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Decision {
    Permit,
    Refuse,
    Unevaluated,
}

#[must_use]
pub const fn default_decision() -> Decision {
    Decision::Unevaluated
}

#[cfg(test)]
mod tests {
    use super::{default_decision, Decision};
    #[test]
    fn unknown_policy_is_not_a_pass() {
        assert_eq!(default_decision(), Decision::Unevaluated);
    }
}
