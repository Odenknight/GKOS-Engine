#![doc = "Opaque secret-reference contracts; secret storage is out of scope."]

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OpaqueSecretRef(String);

impl OpaqueSecretRef {
    pub fn parse(value: impl Into<String>) -> Option<Self> {
        let value = value.into();
        value.starts_with("secret-ref:").then_some(Self(value))
    }

    #[must_use]
    pub fn as_str(&self) -> &str {
        &self.0
    }
}
