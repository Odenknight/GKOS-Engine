#![doc = "Thin, non-authoritative Python binding for deterministic Marshal Core semantics."]

use marshal_core_canonical::{digest_evd_entry, verify as verify_canonical_bytes};
use marshal_core_contracts::artifact_receipt::{
    GeneratedArtifactReceiptV1, ReceiptTimestamp, Sha256Ref, GENERATED_ARTIFACT_RECEIPT_SCHEMA,
};
use marshal_core_contracts::continuity::{
    ContinuityDiagnostic, ContinuityRefusal, DurabilityAuthority, DurableContinuityEnvelopeV1,
    DurableRoot, InstallPolicy, LifecycleOperation, MutationMode, Permission, RecoveryMode,
    RecoveryPolicy, StateClass, StateClassPolicy, CONTINUITY_CONTRACT_ID,
};
use marshal_core_contracts::{
    component_transition_allowed, evaluate_runtime_transition, ComponentLifecycleState, Digest32,
    Revision, RuntimeLifecycleRecord, RuntimeLifecycleState,
};
use marshal_core_evidence::{
    candidate_lifecycle_registry, validate_typed_record, verify as verify_chain_entries,
    EventClass, PayloadSchema, SealedEntry,
};
use marshal_core_runtime::continuity::{
    ContinuityFacts, DurabilityGuardV1, GuardDisposition, RootObservation,
};
use marshal_core_verify::continuity::{
    verify_continuity_v1 as verify_continuity_values, ProjectionStatus, RestoredRecordV1,
};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyModule};

const ABI_ID: &str = "marshal-core-python/2";

type PythonRoot = (
    String,
    String,
    String,
    bool,
    String,
    String,
    String,
    String,
    String,
);
type PythonObservation = (String, bool, bool);
type PythonFinding = (u16, &'static str, String);
type PythonRestoredRecord = (String, String, Vec<u8>, Option<String>, bool, bool, String);

fn invalid(message: &impl ToString) -> PyErr {
    PyValueError::new_err(message.to_string())
}

fn refusal(error: &ContinuityRefusal) -> PyErr {
    invalid(error)
}

fn diagnostic_error(diagnostic: ContinuityDiagnostic) -> PyErr {
    invalid(&format!("{}:{}", diagnostic as u16, diagnostic.symbol()))
}

fn component_state(value: &str) -> PyResult<ComponentLifecycleState> {
    match value {
        "INACTIVE" => Ok(ComponentLifecycleState::Inactive),
        "BLOCKED" => Ok(ComponentLifecycleState::Blocked),
        "READY" => Ok(ComponentLifecycleState::Ready),
        "ACTIVE" => Ok(ComponentLifecycleState::Active),
        "SUSPENDED" => Ok(ComponentLifecycleState::Suspended),
        _ => Err(invalid(&"COMPONENT_STATE_UNKNOWN")),
    }
}

fn runtime_state(value: &str) -> PyResult<RuntimeLifecycleState> {
    match value {
        "CREATED" => Ok(RuntimeLifecycleState::Created),
        "ADMISSION_PENDING" => Ok(RuntimeLifecycleState::AdmissionPending),
        "ADMITTED" => Ok(RuntimeLifecycleState::Admitted),
        "RUNNING" => Ok(RuntimeLifecycleState::Running),
        "COMPLETING" => Ok(RuntimeLifecycleState::Completing),
        "COMPLETED" => Ok(RuntimeLifecycleState::Completed),
        "REFUSED" => Ok(RuntimeLifecycleState::Refused),
        "FAILED" => Ok(RuntimeLifecycleState::Failed),
        "CANCELLED" => Ok(RuntimeLifecycleState::Cancelled),
        _ => Err(invalid(&"RUNTIME_STATE_UNKNOWN")),
    }
}

const fn runtime_name(value: RuntimeLifecycleState) -> &'static str {
    match value {
        RuntimeLifecycleState::Created => "CREATED",
        RuntimeLifecycleState::AdmissionPending => "ADMISSION_PENDING",
        RuntimeLifecycleState::Admitted => "ADMITTED",
        RuntimeLifecycleState::Running => "RUNNING",
        RuntimeLifecycleState::Completing => "COMPLETING",
        RuntimeLifecycleState::Completed => "COMPLETED",
        RuntimeLifecycleState::Refused => "REFUSED",
        RuntimeLifecycleState::Failed => "FAILED",
        RuntimeLifecycleState::Cancelled => "CANCELLED",
    }
}

fn digest32(value: &[u8], diagnostic: &str) -> PyResult<Digest32> {
    let bytes: [u8; 32] = value.try_into().map_err(|_| invalid(&diagnostic))?;
    Ok(Digest32(bytes))
}

#[pyfunction]
fn abi_info() -> (
    &'static str,
    &'static str,
    &'static str,
    &'static str,
    bool,
    bool,
) {
    (
        ABI_ID,
        marshal_core_evidence::CANONICAL_PROFILE,
        marshal_core_evidence::CONTRACT_VERSION,
        CONTINUITY_CONTRACT_ID,
        false,
        false,
    )
}

fn durability_authority(value: &str) -> PyResult<DurabilityAuthority> {
    match value {
        "application_managed" => Ok(DurabilityAuthority::ApplicationManaged),
        "human_operator_external" => Ok(DurabilityAuthority::HumanOperatorExternal),
        _ => Err(diagnostic_error(
            ContinuityDiagnostic::ContinuityEnumUnknown,
        )),
    }
}

fn install_policy(value: &str) -> PyResult<InstallPolicy> {
    match value {
        "managed" => Ok(InstallPolicy::Managed),
        "verify_only" => Ok(InstallPolicy::VerifyOnly),
        _ => Err(diagnostic_error(
            ContinuityDiagnostic::ContinuityEnumUnknown,
        )),
    }
}

fn permission(value: &str) -> PyResult<Permission> {
    match value {
        "permitted" => Ok(Permission::Permitted),
        "forbidden" => Ok(Permission::Forbidden),
        _ => Err(diagnostic_error(
            ContinuityDiagnostic::ContinuityEnumUnknown,
        )),
    }
}

fn lifecycle_operation(value: &str) -> PyResult<LifecycleOperation> {
    match value {
        "verify_preflight" => Ok(LifecycleOperation::VerifyPreflight),
        "verify_restored_state" => Ok(LifecycleOperation::VerifyRestoredState),
        "initialize" => Ok(LifecycleOperation::Initialize),
        "seed" => Ok(LifecycleOperation::Seed),
        "migrate" => Ok(LifecycleOperation::Migrate),
        "recursive_chown" => Ok(LifecycleOperation::RecursiveChown),
        "recursive_chmod" => Ok(LifecycleOperation::RecursiveChmod),
        "backup" => Ok(LifecycleOperation::Backup),
        "restore_fetch" => Ok(LifecycleOperation::RestoreFetch),
        "restore_decrypt" => Ok(LifecycleOperation::RestoreDecrypt),
        "restore_delete" => Ok(LifecycleOperation::RestoreDelete),
        "restore_extract" => Ok(LifecycleOperation::RestoreExtract),
        "encrypt" => Ok(LifecycleOperation::Encrypt),
        "projection_rebuild" => Ok(LifecycleOperation::ProjectionRebuild),
        _ => Err(diagnostic_error(
            ContinuityDiagnostic::ContinuityEnumUnknown,
        )),
    }
}

fn state_class(value: &str) -> PyResult<StateClass> {
    match value {
        "truth" => Ok(StateClass::Truth),
        "operator_config" => Ok(StateClass::OperatorConfig),
        "candidate" => Ok(StateClass::Candidate),
        "project_artifact" => Ok(StateClass::ProjectArtifact),
        "projection" => Ok(StateClass::Projection),
        "resumable" => Ok(StateClass::Resumable),
        "episodic" => Ok(StateClass::Episodic),
        "ephemeral" => Ok(StateClass::Ephemeral),
        "secret" => Ok(StateClass::Secret),
        _ => Err(diagnostic_error(
            ContinuityDiagnostic::ContinuityEnumUnknown,
        )),
    }
}

fn projection_status(value: &str) -> PyResult<ProjectionStatus> {
    match value {
        "not_applicable" => Ok(ProjectionStatus::NotApplicable),
        "current" => Ok(ProjectionStatus::Current),
        "missing" => Ok(ProjectionStatus::Missing),
        "stale" => Ok(ProjectionStatus::Stale),
        _ => Err(diagnostic_error(
            ContinuityDiagnostic::ContinuityEnumUnknown,
        )),
    }
}

fn roots(values: Vec<PythonRoot>) -> PyResult<Vec<DurableRoot>> {
    values
        .into_iter()
        .map(
            |(
                root_id,
                normalized_runtime_path,
                authority,
                must_preexist,
                policy,
                backup,
                restore,
                encryption,
                projection_rebuild,
            )| {
                Ok(DurableRoot {
                    root_id,
                    normalized_runtime_path,
                    authority: durability_authority(&authority)?,
                    must_preexist,
                    install_policy: install_policy(&policy)?,
                    application_backup: permission(&backup)?,
                    application_restore: permission(&restore)?,
                    application_encryption: permission(&encryption)?,
                    application_projection_rebuild: permission(&projection_rebuild)?,
                })
            },
        )
        .collect()
}

fn observations(values: Vec<PythonObservation>) -> Vec<RootObservation> {
    values
        .into_iter()
        .map(|(root_id, present, mapping_matches)| RootObservation {
            root_id,
            present,
            mapping_matches,
        })
        .collect()
}

fn reference_state_policies() -> Vec<StateClassPolicy> {
    StateClass::ALL
        .into_iter()
        .map(|state_class| StateClassPolicy {
            state_class,
            recovery: if state_class == StateClass::Projection {
                RecoveryMode::Rebuild
            } else if state_class == StateClass::Ephemeral {
                RecoveryMode::Never
            } else {
                RecoveryMode::ExternalInPlace
            },
            mutation: match state_class {
                StateClass::Truth | StateClass::Episodic | StateClass::Resumable => {
                    Some(MutationMode::GovernedRuntimeOnly)
                }
                StateClass::OperatorConfig | StateClass::Secret => Some(MutationMode::AtomicWrite),
                StateClass::Candidate => Some(MutationMode::ReviewedPromotionOnly),
                StateClass::Projection => Some(MutationMode::ExplicitRebuildOnly),
                StateClass::ProjectArtifact | StateClass::Ephemeral => None,
            },
        })
        .collect()
}

#[pyfunction]
fn continuity_decide_v1(
    schema: &str,
    deployment_id: &str,
    root_values: Vec<PythonRoot>,
    observation_values: Vec<PythonObservation>,
    normalized_path: &str,
    operation: &str,
) -> PyResult<(&'static str, Option<String>, Option<&'static str>)> {
    let guard = DurabilityGuardV1::new(schema, deployment_id, roots(root_values)?)
        .map_err(|error| refusal(&error))?;
    let facts = ContinuityFacts {
        normalized_path: normalized_path.to_owned(),
        roots: observations(observation_values),
    };
    let decision = guard
        .decide(&facts, lifecycle_operation(operation)?)
        .map_err(|error| refusal(&error))?;
    let disposition = match decision.disposition {
        GuardDisposition::Allowed => "allowed",
        GuardDisposition::OutsideDeclaredRoots => "outside_declared_roots",
    };
    let authority = decision.authority.map(|authority| match authority {
        DurabilityAuthority::ApplicationManaged => "application_managed",
        DurabilityAuthority::HumanOperatorExternal => "human_operator_external",
    });
    Ok((disposition, decision.root_id, authority))
}

#[pyfunction]
#[allow(clippy::too_many_arguments)]
fn validate_generated_artifact_receipt_v1(
    schema: &str,
    artifact_ref: &str,
    project_ref: Option<String>,
    task_ref: &str,
    producer: &str,
    input_hash: &str,
    output_hash: &str,
    byte_count: u64,
    media_type: &str,
    created_at: &str,
    authority: &str,
    truth_ref: Option<String>,
) -> PyResult<bool> {
    if schema != GENERATED_ARTIFACT_RECEIPT_SCHEMA {
        return Err(diagnostic_error(
            ContinuityDiagnostic::ArtifactReceiptSchemaInvalid,
        ));
    }
    if authority != "generated_derivative" {
        return Err(diagnostic_error(
            ContinuityDiagnostic::ArtifactReceiptInvalid,
        ));
    }
    let _receipt = GeneratedArtifactReceiptV1::new(
        artifact_ref,
        project_ref,
        task_ref,
        producer,
        Sha256Ref::new(input_hash).map_err(|error| refusal(&error))?,
        Sha256Ref::new(output_hash).map_err(|error| refusal(&error))?,
        byte_count,
        media_type,
        ReceiptTimestamp::new(created_at).map_err(|error| refusal(&error))?,
        truth_ref,
    )
    .map_err(|error| refusal(&error))?;
    Ok(true)
}

#[pyfunction]
fn verify_continuity_v1(
    schema: &str,
    deployment_id: &str,
    root_values: Vec<PythonRoot>,
    observation_values: Vec<PythonObservation>,
    record_values: Vec<PythonRestoredRecord>,
    writers_stopped: bool,
    dream_state_stopped: bool,
) -> PyResult<(bool, Vec<PythonFinding>)> {
    let roots = roots(root_values)?;
    let envelope = DurableContinuityEnvelopeV1 {
        schema: schema.to_owned(),
        deployment_id: deployment_id.to_owned(),
        roots,
        state_classes: reference_state_policies(),
        recovery: RecoveryPolicy {
            quiesce_before_external_restore: true,
            verify_before_writers: true,
            projections_may_be_rebuilt: true,
            live_mount_restore_by_application: false,
        },
    };
    let records = record_values
        .into_iter()
        .map(
            |(
                record_id,
                class,
                content,
                expected_hash,
                resume_requested,
                compatibility_validated,
                status,
            )| {
                Ok(RestoredRecordV1 {
                    record_id,
                    state_class: state_class(&class)?,
                    content,
                    expected_hash: expected_hash
                        .map(Sha256Ref::new)
                        .transpose()
                        .map_err(|error| refusal(&error))?,
                    resume_requested,
                    compatibility_validated,
                    projection_status: projection_status(&status)?,
                })
            },
        )
        .collect::<PyResult<Vec<_>>>()?;
    let report = verify_continuity_values(
        &envelope,
        &observations(observation_values),
        &records,
        writers_stopped,
        dream_state_stopped,
    );
    Ok((
        report.passed,
        report
            .findings
            .into_iter()
            .map(|finding| {
                (
                    finding.diagnostic as u16,
                    finding.diagnostic.symbol(),
                    finding.subject_id,
                )
            })
            .collect(),
    ))
}

#[pyfunction]
fn verify_canonical(bytes: &Bound<'_, PyBytes>) -> PyResult<()> {
    verify_canonical_bytes(bytes.as_bytes()).map_err(|error| invalid(&error))
}

#[pyfunction]
fn evd_entry_digest(bytes: &Bound<'_, PyBytes>) -> String {
    hex::encode(digest_evd_entry(bytes.as_bytes()).0)
}

#[pyfunction]
fn component_edge_allowed(source: &str, target: &str) -> PyResult<bool> {
    Ok(component_transition_allowed(
        component_state(source)?,
        component_state(target)?,
    ))
}

#[pyfunction]
fn evaluate_runtime(
    current: &str,
    revision: u64,
    expected_revision: u64,
    target: &str,
) -> PyResult<(&'static str, u64)> {
    let result = evaluate_runtime_transition(
        RuntimeLifecycleRecord::from_parts(runtime_state(current)?, Revision::new(revision)),
        Revision::new(expected_revision),
        runtime_state(target)?,
    )
    .map_err(|code| invalid(&format!("{}", code as u16)))?;
    Ok((runtime_name(result.state()), result.revision().get()))
}

#[pyfunction]
fn validate_evd(bytes: &Bound<'_, PyBytes>) -> PyResult<(u16, &'static str, String)> {
    let validated = validate_typed_record(bytes.as_bytes(), Some(candidate_lifecycle_registry()))
        .map_err(|error| invalid(&error))?;
    let event_code = match validated.event_class {
        EventClass::Genesis => 1,
        EventClass::LifecycleTransition => 2,
    };
    let schema = match validated.payload_schema {
        PayloadSchema::GenesisV1 => marshal_core_evidence::GENESIS_PAYLOAD_SCHEMA,
        PayloadSchema::LifecycleTransitionV1 => {
            marshal_core_evidence::LIFECYCLE_TRANSITION_PAYLOAD_SCHEMA
        }
    };
    Ok((event_code, schema, hex::encode(validated.digest.0)))
}

type PythonChainEntry = (Vec<u8>, u64, Option<Vec<u8>>, Vec<u8>, Vec<u8>);

#[pyfunction]
fn verify_chain(entries: Vec<PythonChainEntry>) -> PyResult<Option<String>> {
    let entries = entries
        .into_iter()
        .map(|(chain_id, sequence, previous, canonical_bytes, digest)| {
            Ok(SealedEntry {
                chain_id: digest32(&chain_id, "EVD_CHAIN_ID_LENGTH")?,
                sequence,
                previous: previous
                    .as_deref()
                    .map(|value| digest32(value, "EVD_PREDECESSOR_LENGTH"))
                    .transpose()?,
                canonical_bytes,
                digest: digest32(&digest, "EVD_DIGEST_LENGTH")?,
            })
        })
        .collect::<PyResult<Vec<_>>>()?;
    verify_chain_entries(&entries)
        .map(|head| head.map(|digest| hex::encode(digest.0)))
        .map_err(|error| invalid(&error))
}

#[pymodule]
fn _marshal_core_rs(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(abi_info, module)?)?;
    module.add_function(wrap_pyfunction!(verify_canonical, module)?)?;
    module.add_function(wrap_pyfunction!(evd_entry_digest, module)?)?;
    module.add_function(wrap_pyfunction!(component_edge_allowed, module)?)?;
    module.add_function(wrap_pyfunction!(evaluate_runtime, module)?)?;
    module.add_function(wrap_pyfunction!(validate_evd, module)?)?;
    module.add_function(wrap_pyfunction!(verify_chain, module)?)?;
    module.add_function(wrap_pyfunction!(continuity_decide_v1, module)?)?;
    module.add_function(wrap_pyfunction!(
        validate_generated_artifact_receipt_v1,
        module
    )?)?;
    module.add_function(wrap_pyfunction!(verify_continuity_v1, module)?)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn binding_identity_never_claims_authority() {
        let (_, profile, contract, continuity, runtime_authority, writer_authority) = abi_info();
        assert_eq!(profile, "MARSHAL-CBOR-1");
        assert_eq!(contract, "EVD-002");
        assert_eq!(continuity, "DURABLE-CONTINUITY-v1");
        assert!(!runtime_authority);
        assert!(!writer_authority);
    }

    #[test]
    fn binding_delegates_lifecycle_and_digest_semantics() {
        assert!(component_edge_allowed("READY", "ACTIVE").unwrap());
        assert!(!component_edge_allowed("SUSPENDED", "ACTIVE").unwrap());
        assert_eq!(
            evaluate_runtime("CREATED", 0, 0, "ADMISSION_PENDING").unwrap(),
            ("ADMISSION_PENDING", 1)
        );
        assert_eq!(
            hex::encode(digest_evd_entry(&[0xf6]).0),
            "f05f14b89ba03a5c1cc4ae922be92badb9ef3ffd466c5871372ca04dfde33d9f"
        );
    }
}
