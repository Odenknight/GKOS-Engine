#![doc = "Read-only verification facade; this crate contains no write API."]

pub use marshal_core_canonical::{
    decode as decode_canonical, verify as verify_canonical, CanonicalError, Value,
};
pub use marshal_core_evidence::{verify, SealedEntry, VerifyError};

pub mod continuity;
