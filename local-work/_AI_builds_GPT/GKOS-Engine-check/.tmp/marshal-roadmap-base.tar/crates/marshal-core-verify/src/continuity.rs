//! Read-only structural verification over caller-supplied in-memory values.

use marshal_core_contracts::artifact_receipt::Sha256Ref;
use marshal_core_contracts::continuity::{
    ContinuityDiagnostic, DurableContinuityEnvelopeV1, LifecycleOperation, StateClass,
};
use marshal_core_runtime::continuity::{ContinuityFacts, DurabilityGuardV1, RootObservation};
use sha2::{Digest, Sha256};
use std::collections::BTreeSet;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProjectionStatus {
    NotApplicable,
    Current,
    Missing,
    Stale,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RestoredRecordV1 {
    pub record_id: String,
    pub state_class: StateClass,
    pub content: Vec<u8>,
    pub expected_hash: Option<Sha256Ref>,
    pub resume_requested: bool,
    pub compatibility_validated: bool,
    pub projection_status: ProjectionStatus,
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct VerificationFinding {
    pub diagnostic: ContinuityDiagnostic,
    pub subject_id: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
#[allow(clippy::module_name_repetitions)]
pub struct ContinuityVerificationReport {
    pub passed: bool,
    pub findings: Vec<VerificationFinding>,
}

/// Verify restored structure without repairing, resuming, or invoking a writer.
///
/// All bytes and runtime observations are supplied by the caller. A failed
/// envelope returns one deterministic finding and does not reinterpret values.
#[must_use]
pub fn verify_continuity_v1(
    envelope: &DurableContinuityEnvelopeV1,
    observations: &[RootObservation],
    records: &[RestoredRecordV1],
    writers_stopped: bool,
    dream_state_stopped: bool,
) -> ContinuityVerificationReport {
    if let Err(refusal) = envelope.validate() {
        return report(vec![finding(refusal.diagnostic, "envelope")]);
    }
    let guard = match DurabilityGuardV1::new(
        &envelope.schema,
        envelope.deployment_id.clone(),
        envelope.roots.clone(),
    ) {
        Ok(guard) => guard,
        Err(refusal) => return report(vec![finding(refusal.diagnostic, "envelope")]),
    };
    let mut findings = Vec::new();
    if !writers_stopped {
        findings.push(finding(ContinuityDiagnostic::WritersNotQuiesced, "runtime"));
    }
    if !dream_state_stopped {
        findings.push(finding(
            ContinuityDiagnostic::DreamStateNotQuiesced,
            "dream-state",
        ));
    }
    for root in &envelope.roots {
        let facts = ContinuityFacts {
            normalized_path: root.normalized_runtime_path.clone(),
            roots: observations.to_vec(),
        };
        if let Err(refusal) = guard.decide(&facts, LifecycleOperation::VerifyRestoredState) {
            findings.push(finding(
                refusal.diagnostic,
                refusal.root_id.as_deref().unwrap_or("root"),
            ));
        }
    }
    let mut record_ids = BTreeSet::new();
    for record in records {
        if !valid_record_id(&record.record_id) || !record_ids.insert(record.record_id.as_str()) {
            findings.push(finding(
                ContinuityDiagnostic::RestoredRecordDuplicate,
                &record.record_id,
            ));
            continue;
        }
        match record.state_class {
            StateClass::Ephemeral if !record.content.is_empty() || record.resume_requested => {
                findings.push(finding(
                    ContinuityDiagnostic::EphemeralRestoreRefused,
                    &record.record_id,
                ));
            }
            StateClass::ProjectArtifact => match &record.expected_hash {
                None => findings.push(finding(
                    ContinuityDiagnostic::ArtifactHashMissing,
                    &record.record_id,
                )),
                Some(expected) if digest_ref(&record.content) != expected.as_str() => {
                    findings.push(finding(
                        ContinuityDiagnostic::ArtifactHashMismatch,
                        &record.record_id,
                    ));
                }
                Some(_) => {}
            },
            StateClass::Resumable if record.resume_requested && !record.compatibility_validated => {
                findings.push(finding(
                    ContinuityDiagnostic::ResumableCompatibilityMissing,
                    &record.record_id,
                ));
            }
            StateClass::Projection => {
                if matches!(
                    record.projection_status,
                    ProjectionStatus::Missing | ProjectionStatus::Stale
                ) {
                    findings.push(finding(
                        ContinuityDiagnostic::ProjectionRebuildRequired,
                        &record.record_id,
                    ));
                }
            }
            _ => {}
        }
    }
    report(findings)
}

fn report(mut findings: Vec<VerificationFinding>) -> ContinuityVerificationReport {
    findings.sort();
    ContinuityVerificationReport {
        passed: findings.is_empty(),
        findings,
    }
}

fn finding(diagnostic: ContinuityDiagnostic, subject_id: &str) -> VerificationFinding {
    VerificationFinding {
        diagnostic,
        subject_id: subject_id.to_owned(),
    }
}

fn valid_record_id(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 512
        && !value.chars().any(char::is_control)
        && !value.chars().any(char::is_whitespace)
}

fn digest_ref(bytes: &[u8]) -> String {
    format!("sha256:{}", hex_lower(&Sha256::digest(bytes)))
}

fn hex_lower(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut output = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        output.push(char::from(HEX[usize::from(byte >> 4)]));
        output.push(char::from(HEX[usize::from(byte & 0x0f)]));
    }
    output
}

#[cfg(test)]
mod tests {
    use super::*;
    use marshal_core_contracts::continuity::{
        DurabilityAuthority, DurableRoot, InstallPolicy, MutationMode, Permission, RecoveryMode,
        RecoveryPolicy, StateClassPolicy, CONTINUITY_SCHEMA,
    };

    fn envelope() -> DurableContinuityEnvelopeV1 {
        DurableContinuityEnvelopeV1 {
            schema: CONTINUITY_SCHEMA.to_owned(),
            deployment_id: "deployment".to_owned(),
            roots: vec![DurableRoot {
                root_id: "primary".to_owned(),
                normalized_runtime_path: "/durable".to_owned(),
                authority: DurabilityAuthority::HumanOperatorExternal,
                must_preexist: true,
                install_policy: InstallPolicy::VerifyOnly,
                application_backup: Permission::Forbidden,
                application_restore: Permission::Forbidden,
                application_encryption: Permission::Forbidden,
                application_projection_rebuild: Permission::Forbidden,
            }],
            state_classes: StateClass::ALL
                .into_iter()
                .map(|state_class| StateClassPolicy {
                    state_class,
                    recovery: if state_class == StateClass::Projection {
                        RecoveryMode::Rebuild
                    } else if state_class == StateClass::Ephemeral {
                        RecoveryMode::Never
                    } else {
                        RecoveryMode::ExternalInPlace
                    },
                    mutation: match state_class {
                        StateClass::Truth | StateClass::Episodic | StateClass::Resumable => {
                            Some(MutationMode::GovernedRuntimeOnly)
                        }
                        StateClass::OperatorConfig | StateClass::Secret => {
                            Some(MutationMode::AtomicWrite)
                        }
                        StateClass::Candidate => Some(MutationMode::ReviewedPromotionOnly),
                        StateClass::Projection => Some(MutationMode::ExplicitRebuildOnly),
                        StateClass::ProjectArtifact | StateClass::Ephemeral => None,
                    },
                })
                .collect(),
            recovery: RecoveryPolicy {
                quiesce_before_external_restore: true,
                verify_before_writers: true,
                projections_may_be_rebuilt: true,
                live_mount_restore_by_application: false,
            },
        }
    }

    fn observation() -> RootObservation {
        RootObservation {
            root_id: "primary".to_owned(),
            present: true,
            mapping_matches: true,
        }
    }

    #[test]
    fn clean_supplied_values_pass_without_any_repair_api() {
        let report = verify_continuity_v1(&envelope(), &[observation()], &[], true, true);
        assert!(report.passed);
        assert!(report.findings.is_empty());
    }

    #[test]
    fn verifier_reports_ephemeral_projection_artifact_and_resume_failures() {
        let records = vec![
            RestoredRecordV1 {
                record_id: "ephemeral/pid".to_owned(),
                state_class: StateClass::Ephemeral,
                content: b"123".to_vec(),
                expected_hash: None,
                resume_requested: false,
                compatibility_validated: false,
                projection_status: ProjectionStatus::NotApplicable,
            },
            RestoredRecordV1 {
                record_id: "projection/vector".to_owned(),
                state_class: StateClass::Projection,
                content: Vec::new(),
                expected_hash: None,
                resume_requested: false,
                compatibility_validated: false,
                projection_status: ProjectionStatus::Stale,
            },
            RestoredRecordV1 {
                record_id: "artifact/report".to_owned(),
                state_class: StateClass::ProjectArtifact,
                content: b"report".to_vec(),
                expected_hash: None,
                resume_requested: false,
                compatibility_validated: false,
                projection_status: ProjectionStatus::NotApplicable,
            },
            RestoredRecordV1 {
                record_id: "resume/task".to_owned(),
                state_class: StateClass::Resumable,
                content: Vec::new(),
                expected_hash: None,
                resume_requested: true,
                compatibility_validated: false,
                projection_status: ProjectionStatus::NotApplicable,
            },
        ];
        let report = verify_continuity_v1(&envelope(), &[observation()], &records, false, false);
        assert!(!report.passed);
        let diagnostics: BTreeSet<_> = report
            .findings
            .iter()
            .map(|finding| finding.diagnostic)
            .collect();
        assert!(diagnostics.contains(&ContinuityDiagnostic::EphemeralRestoreRefused));
        assert!(diagnostics.contains(&ContinuityDiagnostic::ProjectionRebuildRequired));
        assert!(diagnostics.contains(&ContinuityDiagnostic::ArtifactHashMissing));
        assert!(diagnostics.contains(&ContinuityDiagnostic::ResumableCompatibilityMissing));
        assert!(diagnostics.contains(&ContinuityDiagnostic::WritersNotQuiesced));
        assert!(diagnostics.contains(&ContinuityDiagnostic::DreamStateNotQuiesced));
    }
}
