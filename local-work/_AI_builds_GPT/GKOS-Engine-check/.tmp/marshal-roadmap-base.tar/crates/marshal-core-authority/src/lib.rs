#![doc = "Fail-closed authority boundary; activation remains external and explicit."]

use thiserror::Error;

/// Comparison posture is operational configuration, not an authority grant.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct ShadowPosture {
    enabled: bool,
}

impl ShadowPosture {
    #[must_use]
    pub const fn enabled() -> Self {
        Self { enabled: true }
    }
    #[must_use]
    pub const fn is_enabled(self) -> bool {
        self.enabled
    }
}

/// Opaque, unappointed authority gate.
///
/// This candidate exposes no grant-state enum, serializer, or sole-writer
/// constructor. A later ratified appointment verifier must replace this inert
/// boundary rather than self-mint authority here.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct AuthorityGate {
    _private: (),
}

impl AuthorityGate {
    #[must_use]
    pub const fn unappointed() -> Self {
        Self { _private: () }
    }
}

#[derive(Debug, Error, Eq, PartialEq)]
pub enum AuthorityError {
    #[error("Rust authority has not been appointed by an exact-head owner cutover")]
    NotAppointed,
}

/// Enforce the fail-closed boundary. No public candidate grant can pass it.
///
/// # Errors
/// Always returns [`AuthorityError::NotAppointed`] in this non-authoritative slice.
pub const fn require_sole_writer(_gate: &AuthorityGate) -> Result<(), AuthorityError> {
    Err(AuthorityError::NotAppointed)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shadow_posture_is_not_authority() {
        let posture = ShadowPosture::enabled();
        let gate = AuthorityGate::unappointed();
        assert!(posture.is_enabled());
        assert_eq!(
            require_sole_writer(&gate),
            Err(AuthorityError::NotAppointed)
        );
    }

    #[test]
    fn default_gate_fails_closed() {
        assert_eq!(
            require_sole_writer(&AuthorityGate::default()),
            Err(AuthorityError::NotAppointed)
        );
    }
}
