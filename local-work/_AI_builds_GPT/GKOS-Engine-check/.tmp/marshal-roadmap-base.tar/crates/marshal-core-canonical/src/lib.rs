#![doc = "Strict MARSHAL-CBOR-1 canonical-byte boundary. This crate grants no authority."]

use marshal_core_contracts::Digest32;
use sha2::{Digest, Sha256};
use std::cmp::Ordering;
use thiserror::Error;
use unicode_normalization::UnicodeNormalization;

pub const MAX_DEPTH: usize = 32;
pub const MAX_ADMITTED_REQUEST_BYTES: usize = 1024 * 1024;
pub const MAX_CANONICAL_PAYLOAD_BYTES: usize = 256 * 1024;
pub const MAX_EVD_RECORD_BYTES: usize = 512 * 1024;
pub const MAX_IDENTITY_ACTION_SCHEMA_TEXT_BYTES: usize = 255;
pub const PINNED_UNICODE_DATA_VERSION: (u8, u8, u8) = (17, 0, 0);
pub const COMPILED_UNICODE_DATA_VERSION: (u8, u8, u8) = unicode_normalization::UNICODE_VERSION;
pub const PINNED_UNICODE_NORMALIZATION_CRATE: &str = "0.1.25";
const EVD_ENTRY_DOMAIN: &[u8] = b"marshal-core\0evd-002\0entry\0v1\0";

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Value {
    Null,
    Bool(bool),
    Unsigned(u64),
    Negative(i64),
    Bytes(Vec<u8>),
    Text(String),
    Array(Vec<Value>),
    Map(Vec<(Value, Value)>),
}

/// Stable primary diagnostics, evaluated in parser/validator order.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Error)]
pub enum CanonicalError {
    #[error("CBOR_TRUNCATED")]
    Truncated,
    #[error("CBOR_TRAILING_DATA")]
    TrailingData,
    #[error("CBOR_INDEFINITE_LENGTH")]
    IndefiniteLength,
    #[error("CBOR_NON_SHORTEST_ENCODING")]
    NonShortestEncoding,
    #[error("CBOR_PROHIBITED_FLOAT")]
    ProhibitedFloat,
    #[error("CBOR_PROHIBITED_TAG")]
    ProhibitedTag,
    #[error("CBOR_PROHIBITED_SIMPLE_VALUE")]
    ProhibitedSimpleValue,
    #[error("TEXT_INVALID_UTF8")]
    InvalidUtf8,
    #[error("TEXT_NOT_NFC")]
    TextNotNfc,
    #[error("CBOR_MAX_DEPTH")]
    MaxDepth,
    #[error("CBOR_MAP_KEY_ORDER")]
    MapKeyOrder,
    #[error("CBOR_DUPLICATE_KEY")]
    DuplicateKey,
    #[error("INTEGER_OUT_OF_PROFILE")]
    IntegerOutOfProfile,
    #[error("ADMITTED_REQUEST_TOO_LARGE")]
    AdmittedRequestTooLarge,
    #[error("CANONICAL_PAYLOAD_TOO_LARGE")]
    CanonicalPayloadTooLarge,
    #[error("EVD_RECORD_TOO_LARGE")]
    EvdRecordTooLarge,
    #[error("IDENTITY_ACTION_SCHEMA_TEXT_TOO_LONG")]
    IdentityActionSchemaTextTooLong,
}

/// Dedicated encoder. Generic Rust struct serialization is not protocol authority.
///
/// # Errors
///
/// Refuses non-NFC text, duplicate canonical map keys, values beyond the profile's
/// integer domain, and structures deeper than [`MAX_DEPTH`].
pub fn encode(value: &Value) -> Result<Vec<u8>, CanonicalError> {
    let mut out = Vec::new();
    encode_at(value, &mut out, 0)?;
    require_evd_record_bytes(out.len())?;
    Ok(out)
}

/// Strictly parse canonical bytes. Input is refused rather than repaired.
///
/// # Errors
///
/// Returns the first stable [`CanonicalError`] encountered while parsing and
/// validating the complete byte slice.
pub fn decode(bytes: &[u8]) -> Result<Value, CanonicalError> {
    require_evd_record_bytes(bytes.len())?;
    let mut parser = Parser { bytes, offset: 0 };
    let value = parser.value(0)?;
    if parser.offset == bytes.len() {
        Ok(value)
    } else {
        Err(CanonicalError::TrailingData)
    }
}

/// Prove strict decode/re-encode byte identity.
///
/// # Errors
///
/// Returns the first canonical validation failure, or
/// [`CanonicalError::NonShortestEncoding`] if re-encoding is not byte-identical.
pub fn verify(bytes: &[u8]) -> Result<(), CanonicalError> {
    let value = decode(bytes)?;
    if encode(&value)? == bytes {
        Ok(())
    } else {
        Err(CanonicalError::NonShortestEncoding)
    }
}

/// Enforce the maximum encoded request admitted by a future writer boundary.
///
/// This is a pure bound check and grants no admission or write authority.
///
/// # Errors
///
/// Returns `AdmittedRequestTooLarge` above 1 MiB.
pub fn require_admitted_request_bytes(byte_len: usize) -> Result<(), CanonicalError> {
    require_bound(
        byte_len,
        MAX_ADMITTED_REQUEST_BYTES,
        CanonicalError::AdmittedRequestTooLarge,
    )
}

/// Enforce the maximum canonical payload size before embedding it in an EVD record.
///
/// # Errors
///
/// Returns `CanonicalPayloadTooLarge` above 256 KiB.
pub fn require_canonical_payload_bytes(byte_len: usize) -> Result<(), CanonicalError> {
    require_bound(
        byte_len,
        MAX_CANONICAL_PAYLOAD_BYTES,
        CanonicalError::CanonicalPayloadTooLarge,
    )
}

/// Enforce the maximum complete canonical EVD record size.
///
/// # Errors
///
/// Returns `EvdRecordTooLarge` above 512 KiB.
pub fn require_evd_record_bytes(byte_len: usize) -> Result<(), CanonicalError> {
    require_bound(
        byte_len,
        MAX_EVD_RECORD_BYTES,
        CanonicalError::EvdRecordTooLarge,
    )
}

/// Validate an identity, action, or schema text field against the v1 byte ceiling.
///
/// The owning schema remains responsible for required/optional and field semantics.
///
/// # Errors
///
/// Returns NFC or 255-byte bound failures without normalizing or truncating input.
pub fn require_identity_action_schema_text(text: &str) -> Result<(), CanonicalError> {
    require_nfc(text)?;
    require_bound(
        text.len(),
        MAX_IDENTITY_ACTION_SCHEMA_TEXT_BYTES,
        CanonicalError::IdentityActionSchemaTextTooLong,
    )
}

fn require_bound(
    actual: usize,
    maximum: usize,
    error: CanonicalError,
) -> Result<(), CanonicalError> {
    if actual <= maximum {
        Ok(())
    } else {
        Err(error)
    }
}

/// `SHA-256("marshal-core\\0evd-002\\0entry\\0v1\\0" || u64_be(len) || bytes)`.
#[must_use]
pub fn digest_evd_entry(bytes: &[u8]) -> Digest32 {
    let mut hasher = Sha256::new();
    hasher.update(EVD_ENTRY_DOMAIN);
    hasher.update(u64::try_from(bytes.len()).unwrap_or(u64::MAX).to_be_bytes());
    hasher.update(bytes);
    Digest32(hasher.finalize().into())
}

fn encode_at(value: &Value, out: &mut Vec<u8>, depth: usize) -> Result<(), CanonicalError> {
    if depth > MAX_DEPTH {
        return Err(CanonicalError::MaxDepth);
    }
    match value {
        Value::Null => out.push(0xf6),
        Value::Bool(false) => out.push(0xf4),
        Value::Bool(true) => out.push(0xf5),
        Value::Unsigned(n) => head(0, *n, out),
        Value::Negative(n) => {
            if *n >= 0 {
                return Err(CanonicalError::IntegerOutOfProfile);
            }
            head(
                1,
                u64::try_from(i128::from(-1) - i128::from(*n))
                    .map_err(|_| CanonicalError::IntegerOutOfProfile)?,
                out,
            );
        }
        Value::Bytes(bytes) => {
            head(2, len(bytes.len())?, out);
            out.extend_from_slice(bytes);
        }
        Value::Text(text) => {
            require_nfc(text)?;
            head(3, len(text.len())?, out);
            out.extend_from_slice(text.as_bytes());
        }
        Value::Array(values) => {
            head(4, len(values.len())?, out);
            for value in values {
                encode_at(value, out, depth + 1)?;
            }
        }
        Value::Map(entries) => {
            let mut encoded = Vec::with_capacity(entries.len());
            for (key, value) in entries {
                let mut key_bytes = Vec::new();
                encode_at(key, &mut key_bytes, depth + 1)?;
                encoded.push((key_bytes, value));
            }
            encoded.sort_by(|a, b| key_cmp(&a.0, &b.0));
            if encoded.windows(2).any(|p| p[0].0 == p[1].0) {
                return Err(CanonicalError::DuplicateKey);
            }
            head(5, len(encoded.len())?, out);
            for (key, value) in encoded {
                out.extend_from_slice(&key);
                encode_at(value, out, depth + 1)?;
            }
        }
    }
    Ok(())
}

fn key_cmp(left: &[u8], right: &[u8]) -> Ordering {
    left.len().cmp(&right.len()).then_with(|| left.cmp(right))
}
fn require_nfc(text: &str) -> Result<(), CanonicalError> {
    if text.nfc().eq(text.chars()) {
        Ok(())
    } else {
        Err(CanonicalError::TextNotNfc)
    }
}
fn len(value: usize) -> Result<u64, CanonicalError> {
    u64::try_from(value).map_err(|_| CanonicalError::IntegerOutOfProfile)
}
fn head(major: u8, n: u64, out: &mut Vec<u8>) {
    let p = major << 5;
    match n {
        0..=23 => out.push(p | u8::try_from(n).expect("match bounds n to u8")),
        24..=0xff => {
            out.extend([p | 24, u8::try_from(n).expect("match bounds n to u8")]);
        }
        0x100..=0xffff => {
            out.push(p | 25);
            out.extend_from_slice(
                &u16::try_from(n)
                    .expect("match bounds n to u16")
                    .to_be_bytes(),
            );
        }
        0x1_0000..=0xffff_ffff => {
            out.push(p | 26);
            out.extend_from_slice(
                &u32::try_from(n)
                    .expect("match bounds n to u32")
                    .to_be_bytes(),
            );
        }
        _ => {
            out.push(p | 27);
            out.extend_from_slice(&n.to_be_bytes());
        }
    }
}

struct Parser<'a> {
    bytes: &'a [u8],
    offset: usize,
}
impl Parser<'_> {
    fn byte(&mut self) -> Result<u8, CanonicalError> {
        let b = *self
            .bytes
            .get(self.offset)
            .ok_or(CanonicalError::Truncated)?;
        self.offset += 1;
        Ok(b)
    }
    fn take(&mut self, n: usize) -> Result<&[u8], CanonicalError> {
        let end = self
            .offset
            .checked_add(n)
            .ok_or(CanonicalError::Truncated)?;
        let v = self
            .bytes
            .get(self.offset..end)
            .ok_or(CanonicalError::Truncated)?;
        self.offset = end;
        Ok(v)
    }
    fn argument(&mut self, a: u8) -> Result<u64, CanonicalError> {
        match a {
            n @ 0..=23 => Ok(u64::from(n)),
            24 => {
                let n = u64::from(self.byte()?);
                if n < 24 {
                    Err(CanonicalError::NonShortestEncoding)
                } else {
                    Ok(n)
                }
            }
            25 => {
                let n = u64::from(u16::from_be_bytes(
                    self.take(2)?.try_into().expect("length"),
                ));
                if n <= 0xff {
                    Err(CanonicalError::NonShortestEncoding)
                } else {
                    Ok(n)
                }
            }
            26 => {
                let n = u64::from(u32::from_be_bytes(
                    self.take(4)?.try_into().expect("length"),
                ));
                if n <= 0xffff {
                    Err(CanonicalError::NonShortestEncoding)
                } else {
                    Ok(n)
                }
            }
            27 => {
                let n = u64::from_be_bytes(self.take(8)?.try_into().expect("length"));
                if n <= 0xffff_ffff {
                    Err(CanonicalError::NonShortestEncoding)
                } else {
                    Ok(n)
                }
            }
            31 => Err(CanonicalError::IndefiniteLength),
            _ => Err(CanonicalError::ProhibitedSimpleValue),
        }
    }
    fn value(&mut self, depth: usize) -> Result<Value, CanonicalError> {
        if depth > MAX_DEPTH {
            return Err(CanonicalError::MaxDepth);
        }
        let initial = self.byte()?;
        let major = initial >> 5;
        let a = initial & 0x1f;
        match major {
            0 => Ok(Value::Unsigned(self.argument(a)?)),
            1 => {
                let n = self.argument(a)?;
                Ok(Value::Negative(
                    i64::try_from(-1_i128 - i128::from(n))
                        .map_err(|_| CanonicalError::IntegerOutOfProfile)?,
                ))
            }
            2 => {
                let n = usize::try_from(self.argument(a)?)
                    .map_err(|_| CanonicalError::IntegerOutOfProfile)?;
                Ok(Value::Bytes(self.take(n)?.to_vec()))
            }
            3 => {
                let n = usize::try_from(self.argument(a)?)
                    .map_err(|_| CanonicalError::IntegerOutOfProfile)?;
                let text = std::str::from_utf8(self.take(n)?)
                    .map_err(|_| CanonicalError::InvalidUtf8)?
                    .to_owned();
                require_nfc(&text)?;
                Ok(Value::Text(text))
            }
            4 => {
                let n = self.argument(a)?;
                let mut values = Vec::new();
                for _ in 0..n {
                    values.push(self.value(depth + 1)?);
                }
                Ok(Value::Array(values))
            }
            5 => {
                let n = self.argument(a)?;
                let mut entries = Vec::new();
                let mut prior: Option<Vec<u8>> = None;
                for _ in 0..n {
                    let start = self.offset;
                    let key = self.value(depth + 1)?;
                    let key_bytes = self.bytes[start..self.offset].to_vec();
                    if let Some(p) = &prior {
                        match key_cmp(p, &key_bytes) {
                            Ordering::Greater => return Err(CanonicalError::MapKeyOrder),
                            Ordering::Equal => return Err(CanonicalError::DuplicateKey),
                            Ordering::Less => {}
                        }
                    }
                    prior = Some(key_bytes);
                    let value = self.value(depth + 1)?;
                    entries.push((key, value));
                }
                Ok(Value::Map(entries))
            }
            6 => Err(CanonicalError::ProhibitedTag),
            7 => match a {
                20 => Ok(Value::Bool(false)),
                21 => Ok(Value::Bool(true)),
                22 => Ok(Value::Null),
                25..=27 => Err(CanonicalError::ProhibitedFloat),
                31 => Err(CanonicalError::IndefiniteLength),
                _ => Err(CanonicalError::ProhibitedSimpleValue),
            },
            _ => Err(CanonicalError::ProhibitedSimpleValue),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn normative_null_empty_and_order() {
        let v = Value::Map(vec![
            (Value::Text("aa".into()), Value::Null),
            (Value::Unsigned(1), Value::Bytes(vec![])),
            (Value::Text("b".into()), Value::Text(String::new())),
        ]);
        let b = encode(&v).unwrap();
        assert_eq!(hex::encode(&b), "a30140616260626161f6");
        verify(&b).unwrap();
    }
    #[test]
    fn mutation_twins_are_refused() {
        assert_eq!(decode(&[0x18, 1]), Err(CanonicalError::NonShortestEncoding));
        assert_eq!(decode(&[0x9f, 0xff]), Err(CanonicalError::IndefiniteLength));
        assert_eq!(decode(&[0xf9, 0, 0]), Err(CanonicalError::ProhibitedFloat));
        assert_eq!(decode(&[0xc0, 0]), Err(CanonicalError::ProhibitedTag));
        assert_eq!(
            decode(&[0xa2, 2, 0xf6, 1, 0xf6]),
            Err(CanonicalError::MapKeyOrder)
        );
        assert_eq!(
            decode(&[0xa2, 1, 0xf6, 1, 0xf6]),
            Err(CanonicalError::DuplicateKey)
        );
        assert_eq!(
            decode(&hex::decode("6365cc81").unwrap()),
            Err(CanonicalError::TextNotNfc)
        );
    }
    #[test]
    fn digest_is_deterministic() {
        assert_eq!(digest_evd_entry(b"ab"), digest_evd_entry(b"ab"));
        assert_ne!(digest_evd_entry(b"ab"), digest_evd_entry(b"a"));
    }

    #[test]
    fn nested_map_keys_consume_parent_depth() {
        let mut key = Value::Unsigned(0);
        for _ in 0..MAX_DEPTH {
            key = Value::Array(vec![key]);
        }
        assert_eq!(
            encode(&Value::Map(vec![(key, Value::Null)])),
            Err(CanonicalError::MaxDepth)
        );
    }

    #[test]
    fn resource_ceilings_fail_closed_at_the_first_excess_byte() {
        assert_eq!(
            require_admitted_request_bytes(MAX_ADMITTED_REQUEST_BYTES + 1),
            Err(CanonicalError::AdmittedRequestTooLarge)
        );
        assert_eq!(
            require_canonical_payload_bytes(MAX_CANONICAL_PAYLOAD_BYTES + 1),
            Err(CanonicalError::CanonicalPayloadTooLarge)
        );
        assert_eq!(
            decode(&vec![0; MAX_EVD_RECORD_BYTES + 1]),
            Err(CanonicalError::EvdRecordTooLarge)
        );
        assert_eq!(
            require_identity_action_schema_text(&"a".repeat(256)),
            Err(CanonicalError::IdentityActionSchemaTextTooLong)
        );
        assert!(require_identity_action_schema_text(&"é".repeat(127)).is_ok());
        assert_eq!(
            require_identity_action_schema_text(&"é".repeat(128)),
            Err(CanonicalError::IdentityActionSchemaTextTooLong)
        );
    }

    #[test]
    fn unicode_tables_match_the_pinned_profile() {
        assert_eq!(COMPILED_UNICODE_DATA_VERSION, PINNED_UNICODE_DATA_VERSION);
        assert_eq!(PINNED_UNICODE_NORMALIZATION_CRATE, "0.1.25");
    }
}
