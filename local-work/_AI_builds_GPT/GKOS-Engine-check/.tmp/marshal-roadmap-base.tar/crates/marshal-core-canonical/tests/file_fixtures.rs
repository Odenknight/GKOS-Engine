use marshal_core_canonical::{
    digest_evd_entry, encode, require_admitted_request_bytes, require_canonical_payload_bytes,
    require_identity_action_schema_text, verify, Value,
};

const CASES: &str = include_str!("../../../fixtures/cbor/v1/cases.tsv");

fn verdict(result: Result<(), marshal_core_canonical::CanonicalError>) -> String {
    result.map_or_else(|error| error.to_string(), |()| "OK".to_owned())
}

#[test]
fn language_neutral_cbor_and_digest_fixtures_conform() {
    let mut count = 0_usize;
    for (line_number, line) in CASES.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        count += 1;
        let fields: Vec<_> = line.split('\t').collect();
        assert_eq!(fields.len(), 4, "fixture line {}", line_number + 1);
        let (id, operation, argument, expected) = (fields[0], fields[1], fields[2], fields[3]);
        let actual = match operation {
            "verify_hex" => verdict(verify(&hex::decode(argument).expect("fixture hex"))),
            "verify_nested" => {
                let mut value = Value::Null;
                for _ in 0..argument.parse::<usize>().expect("fixture depth") {
                    value = Value::Array(vec![value]);
                }
                verdict(encode(&value).map(|_| ()))
            }
            "verify_bytes" => verdict(
                encode(&Value::Bytes(vec![
                    0_u8;
                    argument.parse().expect("fixture length")
                ]))
                .map(|_| ()),
            ),
            "limit_request" => verdict(require_admitted_request_bytes(
                argument.parse().expect("fixture length"),
            )),
            "limit_payload" => verdict(require_canonical_payload_bytes(
                argument.parse().expect("fixture length"),
            )),
            "short_text_ascii" => verdict(require_identity_action_schema_text(
                &"a".repeat(argument.parse().expect("fixture length")),
            )),
            "digest_hex" => {
                let bytes = if argument == "-" {
                    Vec::new()
                } else {
                    hex::decode(argument).expect("fixture hex")
                };
                hex::encode(digest_evd_entry(&bytes).0)
            }
            _ => panic!("unknown fixture operation {operation} in {id}"),
        };
        assert_eq!(actual, expected, "fixture {id}");
    }
    assert_eq!(count, 29, "fixture count is an explicit coverage guard");
}
