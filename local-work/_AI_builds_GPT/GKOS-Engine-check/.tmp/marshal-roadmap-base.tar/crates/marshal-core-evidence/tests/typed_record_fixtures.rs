use marshal_core_canonical::{decode, encode, Value};
use marshal_core_evidence::{validate_typed_record, LifecycleRegistry};
use sha2::{Digest, Sha256};

const POSITIVE: &str = include_str!("../../../fixtures/evd/v1/typed-record-positive.tsv");
const MUTATIONS: &str = include_str!("../../../fixtures/evd/v1/typed-record-mutations.tsv");
const REGISTRY: &str = include_str!("../../../fixtures/evd/v1/lifecycle-registry-candidate.tsv");
const REGISTRY_DIGEST: &str = "363ecc2ebc1e7faad6668e960db1043ab926f3c0b784e8b75c5e7a67e0cd599c";

fn registry() -> LifecycleRegistry<'static> {
    assert_eq!(
        hex::encode(Sha256::digest(REGISTRY.as_bytes())),
        REGISTRY_DIGEST
    );
    let mut version = "";
    let mut states = Vec::new();
    let mut edges = Vec::new();
    let mut results = Vec::new();
    let mut terminals = Vec::new();
    for line in REGISTRY.lines().filter(|line| !line.starts_with('#')) {
        let fields: Vec<_> = line.split('\t').collect();
        assert_eq!(fields.len(), 4);
        match (fields[0], fields[1]) {
            ("meta", "version") => version = fields[2],
            ("state", domain) => states.push((domain, fields[2])),
            ("result", "v1") => results.push(fields[2]),
            ("transition", domain) => edges.push((domain, fields[2], fields[3])),
            ("terminal", "runtime") => terminals.push(fields[2]),
            _ => panic!("unknown lifecycle registry row: {line}"),
        }
    }
    assert_eq!(version, "MCR-EVD-LIFECYCLE-REGISTRY-CANDIDATE-2");
    assert_eq!(
        states
            .iter()
            .filter(|(domain, _)| *domain == "component")
            .count(),
        5
    );
    assert_eq!(
        states
            .iter()
            .filter(|(domain, _)| *domain == "runtime")
            .count(),
        9
    );
    assert_eq!(
        edges
            .iter()
            .filter(|(domain, _, _)| *domain == "component")
            .count(),
        13
    );
    assert_eq!(
        edges
            .iter()
            .filter(|(domain, _, _)| *domain == "runtime")
            .count(),
        11
    );
    assert_eq!(terminals, ["COMPLETED", "REFUSED", "FAILED", "CANCELLED"]);
    assert_eq!(results, ["SUCCESS", "REFUSED", "FAILED", "CANCELLED"]);
    LifecycleRegistry {
        version,
        digest_hex: REGISTRY_DIGEST,
        state_domains: Box::leak(states.into_boxed_slice()),
        legal_edges: Box::leak(edges.into_boxed_slice()),
        runtime_terminals: Box::leak(terminals.into_boxed_slice()),
        transition_results: Box::leak(results.into_boxed_slice()),
    }
}

fn with_registry(name: &str) -> Option<LifecycleRegistry<'static>> {
    match name {
        "candidate" => Some(registry()),
        "none" => None,
        "stale" => {
            let mut registry = registry();
            registry.digest_hex =
                "0000000000000000000000000000000000000000000000000000000000000000";
            Some(registry)
        }
        "ambiguous" => {
            let mut registry = registry();
            let mut states = registry.state_domains.to_vec();
            states.push(("runtime", "READY"));
            states.push(("runtime", "ACTIVE"));
            registry.state_domains = Box::leak(states.into_boxed_slice());
            Some(registry)
        }
        _ => panic!("unknown registry fixture {name}"),
    }
}

fn positive_rows() -> Vec<Vec<&'static str>> {
    POSITIVE
        .lines()
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(|line| line.split('\t').collect())
        .collect()
}

#[test]
fn exact_typed_positive_bytes_and_digests_conform() {
    let rows = positive_rows();
    assert_eq!(rows.len(), 8, "positive fixture count is a coverage guard");
    for fields in rows {
        assert_eq!(fields.len(), 5, "fixture {}", fields[0]);
        let bytes = hex::decode(fields[2]).expect("fixture hex");
        let actual = validate_typed_record(&bytes, with_registry(fields[1]))
            .unwrap_or_else(|error| panic!("fixture {}: {error}", fields[0]));
        assert_eq!(actual.canonical_bytes, bytes, "fixture {}", fields[0]);
        assert_eq!(
            hex::encode(actual.digest.0),
            fields[4],
            "fixture {}",
            fields[0]
        );
    }
}

#[test]
fn typed_mutation_twins_fail_closed() {
    let positives = positive_rows();
    let mut count = 0_usize;
    for line in MUTATIONS
        .lines()
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
    {
        count += 1;
        let fields: Vec<_> = line.split('\t').collect();
        assert_eq!(fields.len(), 6, "mutation line {count}");
        let base = positives
            .iter()
            .find(|row| row[0] == fields[1])
            .unwrap_or_else(|| panic!("unknown base {}", fields[1]));
        let bytes = hex::decode(base[2]).expect("base fixture hex");
        let mut value = decode(&bytes).expect("base fixture canonical CBOR");
        mutate(&mut value, fields[2], fields[3]);
        let mutated = encode(&value).expect("mutation remains canonical CBOR");
        let actual = validate_typed_record(&mutated, with_registry(fields[4]))
            .map_or_else(|error| error.to_string(), |_| "OK".to_owned());
        assert_eq!(actual, fields[5], "mutation {}", fields[0]);
    }
    assert_eq!(count, 94, "mutation fixture count is a coverage guard");
}

fn mutate(root: &mut Value, operation: &str, argument: &str) {
    match operation {
        "identity" => {}
        "set_event_code" => set(root, 7, unsigned(argument)),
        "set_schema" => set(root, 14, Value::Text(argument.to_owned())),
        "set_sequence" => set(root, 4, unsigned(argument)),
        "set_predecessor_null" => set(root, 5, Value::Null),
        "set_occurred_at" => set(root, 8, Value::Text(argument.to_owned())),
        "set_outcome" => set(root, 12, unsigned(argument)),
        "set_diagnostic" => set(root, 13, unsigned(argument)),
        "remove_envelope_key" => remove(root, parse_u64(argument)),
        "add_envelope_key" => set(root, parse_u64(argument), Value::Unsigned(0)),
        "set_envelope_null" => set(root, parse_u64(argument), Value::Null),
        "set_envelope_bool" => set(root, parse_u64(argument), Value::Bool(true)),
        "set_chain_id_text" => set(root, 3, Value::Text(argument.to_owned())),
        "remove_payload_key" => remove(payload(root), parse_u64(argument)),
        "add_payload_key" => set(payload(root), parse_u64(argument), Value::Unsigned(0)),
        "set_payload_null" => set(payload(root), parse_u64(argument), Value::Null),
        "set_expected_revision_text" => {
            set(payload(root), 3, Value::Text(argument.to_owned()));
        }
        "set_committed_revision" => set(payload(root), 4, unsigned(argument)),
        "set_resulting_state" => set(payload(root), 2, Value::Text(argument.to_owned())),
        "set_transition_result" => set(payload(root), 6, Value::Text(argument.to_owned())),
        "set_source_observed_at" => set(payload(root), 7, Value::Text(argument.to_owned())),
        "set_inventory_digest_short" => {
            set(payload(root), 1, Value::Bytes(argument.as_bytes().to_vec()));
        }
        "set_writer_generation" => set(payload(root), 8, Value::Text(argument.to_owned())),
        _ => panic!("unknown mutation operation {operation}"),
    }
}

fn parse_u64(value: &str) -> u64 {
    value.parse().expect("fixture unsigned integer")
}

fn unsigned(value: &str) -> Value {
    Value::Unsigned(parse_u64(value))
}

fn entries(value: &mut Value) -> &mut Vec<(Value, Value)> {
    let Value::Map(entries) = value else {
        panic!("fixture target is not a map");
    };
    entries
}

fn payload(root: &mut Value) -> &mut Value {
    entries(root)
        .iter_mut()
        .find_map(|(key, value)| (*key == Value::Unsigned(15)).then_some(value))
        .expect("fixture payload key")
}

fn set(value: &mut Value, key: u64, replacement: Value) {
    if let Some((_, current)) = entries(value)
        .iter_mut()
        .find(|(candidate, _)| *candidate == Value::Unsigned(key))
    {
        *current = replacement;
    } else {
        entries(value).push((Value::Unsigned(key), replacement));
    }
}

fn remove(value: &mut Value, key: u64) {
    entries(value).retain(|(candidate, _)| *candidate != Value::Unsigned(key));
}
