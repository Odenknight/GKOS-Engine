use marshal_core_evidence::validate_symbolic_metadata;

const CASES: &str = include_str!("../../../fixtures/evd/v1/typed-metadata.tsv");

#[test]
fn approved_symbolic_metadata_pairs_and_refusals_conform() {
    let mut count = 0_usize;
    for (line_number, line) in CASES.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        count += 1;
        let fields: Vec<_> = line.split('\t').collect();
        assert_eq!(fields.len(), 4, "fixture line {}", line_number + 1);
        let (id, event_class, payload_schema, expected) =
            (fields[0], fields[1], fields[2], fields[3]);
        let actual = validate_symbolic_metadata(event_class, payload_schema)
            .map_or_else(|error| error.to_string(), |_| "OK".to_owned());
        assert_eq!(actual, expected, "fixture {id}");
    }
    assert_eq!(count, 7, "fixture count is an explicit coverage guard");
}
