#![doc = "Read-only EVD-002 chain primitives. This crate contains no persistence writer or authority activation."]

use marshal_core_canonical::{
    decode as decode_canonical, digest_evd_entry, encode as encode_canonical,
    require_canonical_payload_bytes, require_identity_action_schema_text,
    verify as verify_canonical, CanonicalError, Value,
};
use marshal_core_contracts::Digest32;
use thiserror::Error;

pub const GENESIS_PAYLOAD_SCHEMA: &str = "marshal/evd/genesis/v1";
pub const LIFECYCLE_TRANSITION_PAYLOAD_SCHEMA: &str = "marshal/evd/lifecycle-transition/v1";
pub const GENESIS_EVENT_CODE: u16 = 1;
pub const LIFECYCLE_TRANSITION_EVENT_CODE: u16 = 2;
pub const CONTRACT_VERSION: &str = "EVD-002";
pub const CANONICAL_PROFILE: &str = "MARSHAL-CBOR-1";
pub const WRITER_GENERATION: &str = "rust-authority-gen-1";
pub const LIFECYCLE_REGISTRY_VERSION: &str = "MCR-EVD-LIFECYCLE-REGISTRY-CANDIDATE-2";
pub const LIFECYCLE_REGISTRY_DIGEST: &str =
    "363ecc2ebc1e7faad6668e960db1043ab926f3c0b784e8b75c5e7a67e0cd599c";
const CANDIDATE_STATE_DOMAINS: &[(&str, &str)] = &[
    ("component", "INACTIVE"),
    ("component", "BLOCKED"),
    ("component", "READY"),
    ("component", "ACTIVE"),
    ("component", "SUSPENDED"),
    ("runtime", "CREATED"),
    ("runtime", "ADMISSION_PENDING"),
    ("runtime", "ADMITTED"),
    ("runtime", "RUNNING"),
    ("runtime", "COMPLETING"),
    ("runtime", "COMPLETED"),
    ("runtime", "REFUSED"),
    ("runtime", "FAILED"),
    ("runtime", "CANCELLED"),
];
const CANDIDATE_LEGAL_EDGES: &[(&str, &str, &str)] = &[
    ("component", "INACTIVE", "BLOCKED"),
    ("component", "READY", "BLOCKED"),
    ("component", "ACTIVE", "BLOCKED"),
    ("component", "SUSPENDED", "BLOCKED"),
    ("component", "INACTIVE", "READY"),
    ("component", "BLOCKED", "READY"),
    ("component", "SUSPENDED", "READY"),
    ("component", "BLOCKED", "INACTIVE"),
    ("component", "READY", "INACTIVE"),
    ("component", "ACTIVE", "INACTIVE"),
    ("component", "SUSPENDED", "INACTIVE"),
    ("component", "READY", "ACTIVE"),
    ("component", "ACTIVE", "SUSPENDED"),
    ("runtime", "CREATED", "ADMISSION_PENDING"),
    ("runtime", "ADMISSION_PENDING", "ADMITTED"),
    ("runtime", "ADMISSION_PENDING", "REFUSED"),
    ("runtime", "ADMISSION_PENDING", "CANCELLED"),
    ("runtime", "ADMITTED", "RUNNING"),
    ("runtime", "ADMITTED", "CANCELLED"),
    ("runtime", "RUNNING", "COMPLETING"),
    ("runtime", "RUNNING", "FAILED"),
    ("runtime", "RUNNING", "CANCELLED"),
    ("runtime", "COMPLETING", "COMPLETED"),
    ("runtime", "COMPLETING", "FAILED"),
];
const CANDIDATE_RUNTIME_TERMINALS: &[&str] = &["COMPLETED", "REFUSED", "FAILED", "CANCELLED"];
const CANDIDATE_TRANSITION_RESULTS: &[&str] = &["SUCCESS", "REFUSED", "FAILED", "CANCELLED"];

/// Symbolic event classes approved for the bounded EVD v1 fixture scope.
///
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u16)]
pub enum EventClass {
    Genesis = GENESIS_EVENT_CODE,
    LifecycleTransition = LIFECYCLE_TRANSITION_EVENT_CODE,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PayloadSchema {
    GenesisV1,
    LifecycleTransitionV1,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Error)]
pub enum MetadataError {
    #[error("EVD_UNKNOWN_EVENT_CLASS")]
    UnknownEventClass,
    #[error("EVD_UNKNOWN_PAYLOAD_SCHEMA")]
    UnknownPayloadSchema,
    #[error("EVD_EVENT_CLASS_SCHEMA_MISMATCH")]
    EventClassSchemaMismatch,
}

/// Parse and cross-check the approved symbolic event-class/schema pair.
///
/// This compatibility parser is a conformance boundary only. It does not encode
/// an EVD envelope and grants no authority. New vectors use the frozen u16 codes.
///
/// # Errors
///
/// Refuses unknown classes, unknown schemas, and known but mismatched pairs in
/// that deterministic order.
pub fn validate_symbolic_metadata(
    event_class: &str,
    payload_schema: &str,
) -> Result<(EventClass, PayloadSchema), MetadataError> {
    let event_class = match event_class {
        "GENESIS" => EventClass::Genesis,
        "LIFECYCLE_TRANSITION" => EventClass::LifecycleTransition,
        _ => return Err(MetadataError::UnknownEventClass),
    };
    let payload_schema = match payload_schema {
        GENESIS_PAYLOAD_SCHEMA => PayloadSchema::GenesisV1,
        LIFECYCLE_TRANSITION_PAYLOAD_SCHEMA => PayloadSchema::LifecycleTransitionV1,
        _ => return Err(MetadataError::UnknownPayloadSchema),
    };
    match (event_class, payload_schema) {
        (EventClass::Genesis, PayloadSchema::GenesisV1)
        | (EventClass::LifecycleTransition, PayloadSchema::LifecycleTransitionV1) => {
            Ok((event_class, payload_schema))
        }
        _ => Err(MetadataError::EventClassSchemaMismatch),
    }
}

/// Explicit, candidate-only registry binding for lifecycle payload text.
/// Core does not invent lifecycle states or transition results.
#[derive(Clone, Copy, Debug)]
pub struct LifecycleRegistry<'a> {
    pub version: &'a str,
    pub digest_hex: &'a str,
    pub state_domains: &'a [(&'a str, &'a str)],
    pub legal_edges: &'a [(&'a str, &'a str, &'a str)],
    pub runtime_terminals: &'a [&'a str],
    pub transition_results: &'a [&'a str],
}

/// Return the exact candidate registry compiled into this qualified slice.
///
/// This accessor exposes immutable validation inputs only. It grants no write,
/// appointment, persistence, activation, or registry-amendment authority.
#[must_use]
pub const fn candidate_lifecycle_registry() -> LifecycleRegistry<'static> {
    LifecycleRegistry {
        version: LIFECYCLE_REGISTRY_VERSION,
        digest_hex: LIFECYCLE_REGISTRY_DIGEST,
        state_domains: CANDIDATE_STATE_DOMAINS,
        legal_edges: CANDIDATE_LEGAL_EDGES,
        runtime_terminals: CANDIDATE_RUNTIME_TERMINALS,
        transition_results: CANDIDATE_TRANSITION_RESULTS,
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ValidatedEvdRecord {
    pub event_class: EventClass,
    pub payload_schema: PayloadSchema,
    pub canonical_bytes: Vec<u8>,
    pub digest: Digest32,
}

/// Existing approved diagnostic names plus qualification dispositions. This
/// implementation allocates no new numeric diagnostic identity.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Error)]
pub enum TypedEvdError {
    #[error("REQUIRED_FIELD_MISSING")]
    RequiredFieldMissing,
    #[error("UNKNOWN_FIELD")]
    UnknownField,
    #[error("FIELD_TYPE_INVALID")]
    FieldTypeInvalid,
    #[error("FIELD_BOUND_INVALID")]
    FieldBoundInvalid,
    #[error("PAYLOAD_SCHEMA_UNKNOWN")]
    PayloadSchemaUnknown,
    #[error("PAYLOAD_SCHEMA_INVALID")]
    PayloadSchemaInvalid,
    #[error("SEQUENCE_MISMATCH")]
    SequenceMismatch,
    #[error("PREDECESSOR_MISMATCH")]
    PredecessorMismatch,
    #[error("GENESIS_INVALID")]
    GenesisInvalid,
    #[error("PROTOCOL_VERSION_UNSUPPORTED")]
    ProtocolVersionUnsupported,
    #[error("CANONICAL_PROFILE_UNSUPPORTED")]
    CanonicalProfileUnsupported,
    #[error("SPEC_AMBIGUOUS")]
    SpecAmbiguous,
    #[error(transparent)]
    Canonical(#[from] CanonicalError),
}

/// Validate exact canonical bytes against the closed EVD-002 v1 envelope and
/// payload schemas. This pure conformance function neither writes nor activates.
///
/// # Errors
///
/// Fails closed on canonical errors, unknown/missing keys, wrong types or bounds,
/// unsupported versions/codes/schemas, timestamp violations, linkage errors,
/// revision mismatch, or an absent/unbound lifecycle registry.
pub fn validate_typed_record(
    bytes: &[u8],
    lifecycle_registry: Option<LifecycleRegistry<'_>>,
) -> Result<ValidatedEvdRecord, TypedEvdError> {
    verify_canonical(bytes)?;
    let root = decode_canonical(bytes)?;
    let fields = exact_integer_map(&root, 1, 17, &[])?;

    expect_fixed_text(
        field(&fields, 1)?,
        CONTRACT_VERSION,
        TypedEvdError::ProtocolVersionUnsupported,
    )?;
    expect_fixed_text(
        field(&fields, 2)?,
        CANONICAL_PROFILE,
        TypedEvdError::CanonicalProfileUnsupported,
    )?;
    expect_bytes_len(field(&fields, 3)?, 16)?;
    let sequence = expect_unsigned(field(&fields, 4)?)?;
    if sequence == 0 || sequence > i64::MAX as u64 {
        return Err(TypedEvdError::SequenceMismatch);
    }
    match field(&fields, 5)? {
        Value::Null if sequence == 1 => {}
        Value::Null => return Err(TypedEvdError::PredecessorMismatch),
        Value::Bytes(value) if value.len() != 32 => {
            return Err(TypedEvdError::FieldBoundInvalid);
        }
        Value::Bytes(_) if sequence == 1 => return Err(TypedEvdError::GenesisInvalid),
        Value::Bytes(_) => {}
        _ => return Err(TypedEvdError::FieldTypeInvalid),
    }
    expect_bytes_len(field(&fields, 6)?, 16)?;
    let event_class = match expect_unsigned(field(&fields, 7)?)? {
        1 => EventClass::Genesis,
        2 => EventClass::LifecycleTransition,
        _ => return Err(TypedEvdError::FieldBoundInvalid),
    };
    expect_timestamp(field(&fields, 8)?)?;
    for key in 9..=11 {
        expect_short_nonempty_text(field(&fields, key)?)?;
    }
    let outcome = expect_unsigned(field(&fields, 12)?)?;
    if outcome > 3 {
        return Err(TypedEvdError::FieldBoundInvalid);
    }
    let diagnostic = expect_unsigned(field(&fields, 13)?)?;
    if (outcome == 0) != (diagnostic == 0) || !approved_diagnostic(diagnostic) {
        return Err(TypedEvdError::PayloadSchemaInvalid);
    }
    let schema_text = expect_short_nonempty_text(field(&fields, 14)?)?;
    let payload_schema = match schema_text {
        GENESIS_PAYLOAD_SCHEMA => PayloadSchema::GenesisV1,
        LIFECYCLE_TRANSITION_PAYLOAD_SCHEMA => PayloadSchema::LifecycleTransitionV1,
        _ => return Err(TypedEvdError::PayloadSchemaUnknown),
    };
    let payload = field(&fields, 15)?;
    require_canonical_payload_bytes(encode_canonical(payload)?.len())?;
    match (event_class, payload_schema) {
        (EventClass::Genesis, PayloadSchema::GenesisV1) => validate_genesis(payload)?,
        (EventClass::LifecycleTransition, PayloadSchema::LifecycleTransitionV1) => {
            validate_lifecycle(payload, lifecycle_registry)?;
        }
        _ => return Err(TypedEvdError::PayloadSchemaInvalid),
    }
    match field(&fields, 16)? {
        Value::Null => {}
        value => expect_bytes_len(value, 32)?,
    }
    expect_bytes_len(field(&fields, 17)?, 16)?;
    if (sequence == 1) != (event_class == EventClass::Genesis) {
        return Err(TypedEvdError::GenesisInvalid);
    }
    Ok(ValidatedEvdRecord {
        event_class,
        payload_schema,
        canonical_bytes: bytes.to_vec(),
        digest: digest_evd_entry(bytes),
    })
}

fn validate_genesis(payload: &Value) -> Result<(), TypedEvdError> {
    let fields = exact_integer_map(payload, 1, 9, &[])?;
    for key in 1..=7 {
        expect_bytes_len(field(&fields, key)?, 32)?;
    }
    expect_text_eq(field(&fields, 8)?, WRITER_GENERATION)?;
    expect_short_nonempty_text(field(&fields, 9)?)?;
    Ok(())
}

fn validate_lifecycle(
    payload: &Value,
    registry: Option<LifecycleRegistry<'_>>,
) -> Result<(), TypedEvdError> {
    let fields = exact_integer_map(payload, 1, 7, &[7])?;
    let registry = registry.ok_or(TypedEvdError::SpecAmbiguous)?;
    if registry.version != LIFECYCLE_REGISTRY_VERSION
        || registry.digest_hex != LIFECYCLE_REGISTRY_DIGEST
        || registry.state_domains != CANDIDATE_STATE_DOMAINS
        || registry.legal_edges != CANDIDATE_LEGAL_EDGES
        || registry.runtime_terminals != CANDIDATE_RUNTIME_TERMINALS
        || registry.transition_results != CANDIDATE_TRANSITION_RESULTS
    {
        return Err(TypedEvdError::SpecAmbiguous);
    }
    let prior = expect_short_nonempty_text(field(&fields, 1)?)?;
    let resulting = expect_short_nonempty_text(field(&fields, 2)?)?;
    let prior_domains: Vec<_> = registry
        .state_domains
        .iter()
        .filter_map(|(domain, state)| (*state == prior).then_some(*domain))
        .collect();
    let resulting_domains: Vec<_> = registry
        .state_domains
        .iter()
        .filter_map(|(domain, state)| (*state == resulting).then_some(*domain))
        .collect();
    let shared_domains: Vec<_> = prior_domains
        .iter()
        .filter(|domain| resulting_domains.contains(domain))
        .copied()
        .collect();
    if shared_domains.len() != 1 {
        return Err(TypedEvdError::PayloadSchemaInvalid);
    }
    let domain = shared_domains[0];
    if !registry.legal_edges.contains(&(domain, prior, resulting)) {
        return Err(TypedEvdError::PayloadSchemaInvalid);
    }
    let expected = expect_unsigned(field(&fields, 3)?)?;
    let committed = expect_unsigned(field(&fields, 4)?)?;
    if expected.checked_add(1) != Some(committed) {
        return Err(TypedEvdError::PayloadSchemaInvalid);
    }
    expect_short_nonempty_text(field(&fields, 5)?)?;
    let result = expect_short_nonempty_text(field(&fields, 6)?)?;
    if !registry.transition_results.contains(&result) {
        return Err(TypedEvdError::PayloadSchemaInvalid);
    }
    if let Some(value) = fields.get(6).copied().flatten() {
        expect_timestamp(value)?;
    }
    Ok(())
}

fn exact_integer_map<'a>(
    value: &'a Value,
    minimum: u64,
    maximum: u64,
    optional: &[u64],
) -> Result<Vec<Option<&'a Value>>, TypedEvdError> {
    let Value::Map(entries) = value else {
        return Err(TypedEvdError::FieldTypeInvalid);
    };
    let field_count = usize::try_from(maximum).map_err(|_| TypedEvdError::FieldBoundInvalid)?;
    let mut fields = vec![None; field_count];
    for (key, value) in entries {
        let Value::Unsigned(key) = key else {
            return Err(TypedEvdError::UnknownField);
        };
        if *key < minimum || *key > maximum {
            return Err(TypedEvdError::UnknownField);
        }
        let index = usize::try_from(*key - 1).map_err(|_| TypedEvdError::FieldBoundInvalid)?;
        fields[index] = Some(value);
    }
    for key in minimum..=maximum {
        let index = usize::try_from(key - 1).map_err(|_| TypedEvdError::FieldBoundInvalid)?;
        if fields[index].is_none() && !optional.contains(&key) {
            return Err(TypedEvdError::RequiredFieldMissing);
        }
    }
    Ok(fields)
}

fn field<'a>(fields: &'a [Option<&'a Value>], key: usize) -> Result<&'a Value, TypedEvdError> {
    fields
        .get(key - 1)
        .copied()
        .flatten()
        .ok_or(TypedEvdError::RequiredFieldMissing)
}

fn expect_unsigned(value: &Value) -> Result<u64, TypedEvdError> {
    match value {
        Value::Unsigned(value) => Ok(*value),
        _ => Err(TypedEvdError::FieldTypeInvalid),
    }
}

fn expect_bytes_len(value: &Value, expected: usize) -> Result<(), TypedEvdError> {
    match value {
        Value::Bytes(bytes) if bytes.len() == expected => Ok(()),
        Value::Bytes(_) => Err(TypedEvdError::FieldBoundInvalid),
        _ => Err(TypedEvdError::FieldTypeInvalid),
    }
}

fn expect_text_eq(value: &Value, expected: &str) -> Result<(), TypedEvdError> {
    match value {
        Value::Text(text) if text == expected => Ok(()),
        Value::Text(_) => Err(TypedEvdError::PayloadSchemaInvalid),
        _ => Err(TypedEvdError::FieldTypeInvalid),
    }
}

fn expect_fixed_text(
    value: &Value,
    expected: &str,
    unsupported: TypedEvdError,
) -> Result<(), TypedEvdError> {
    match value {
        Value::Text(text) if text == expected => Ok(()),
        Value::Text(_) => Err(unsupported),
        _ => Err(TypedEvdError::FieldTypeInvalid),
    }
}

fn expect_short_nonempty_text(value: &Value) -> Result<&str, TypedEvdError> {
    let Value::Text(text) = value else {
        return Err(TypedEvdError::FieldTypeInvalid);
    };
    if text.is_empty() {
        return Err(TypedEvdError::FieldBoundInvalid);
    }
    require_identity_action_schema_text(text)?;
    Ok(text)
}

fn expect_timestamp(value: &Value) -> Result<(), TypedEvdError> {
    let Value::Text(text) = value else {
        return Err(TypedEvdError::FieldTypeInvalid);
    };
    let bytes = text.as_bytes();
    let punctuation = [
        (4, b'-'),
        (7, b'-'),
        (10, b'T'),
        (13, b':'),
        (16, b':'),
        (19, b'.'),
        (26, b'Z'),
    ];
    if bytes.len() != 27
        || punctuation
            .iter()
            .any(|(index, byte)| bytes[*index] != *byte)
        || bytes.iter().enumerate().any(|(index, byte)| {
            !punctuation.iter().any(|(position, _)| *position == index) && !byte.is_ascii_digit()
        })
    {
        return Err(TypedEvdError::FieldBoundInvalid);
    }
    let year = timestamp_number(bytes, 0, 4)?;
    let month = timestamp_number(bytes, 5, 7)?;
    let day = timestamp_number(bytes, 8, 10)?;
    let hour = timestamp_number(bytes, 11, 13)?;
    let minute = timestamp_number(bytes, 14, 16)?;
    let second = timestamp_number(bytes, 17, 19)?;
    let leap = year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    let max_day = match month {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 if leap => 29,
        2 => 28,
        _ => return Err(TypedEvdError::FieldBoundInvalid),
    };
    if !(1..=max_day).contains(&day) || hour > 23 || minute > 59 || second > 59 {
        return Err(TypedEvdError::FieldBoundInvalid);
    }
    Ok(())
}

fn timestamp_number(bytes: &[u8], start: usize, end: usize) -> Result<u32, TypedEvdError> {
    std::str::from_utf8(&bytes[start..end])
        .ok()
        .and_then(|value| value.parse().ok())
        .ok_or(TypedEvdError::FieldBoundInvalid)
}

fn approved_diagnostic(code: u64) -> bool {
    matches!(
        code,
        0 | 1001..=1006
            | 2001..=2006
            | 3001..=3003
            | 4001..=4007
            | 5001..=5004
            | 6001..=6009
            | 7001..=7005
            | 8001..=8002
            | 9001..=9002
            | 9501
    )
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SealedEntry {
    pub chain_id: Digest32,
    pub sequence: u64,
    pub previous: Option<Digest32>,
    pub canonical_bytes: Vec<u8>,
    pub digest: Digest32,
}

#[derive(Debug, Error, Eq, PartialEq)]
pub enum SealError {
    #[error("EVD_SEQUENCE_ZERO")]
    SequenceZero,
    #[error("EVD_INVALID_GENESIS_PREDECESSOR")]
    InvalidGenesisPredecessor,
    #[error("EVD_MISSING_PREDECESSOR")]
    MissingPredecessor,
    #[error(transparent)]
    Canonical(#[from] CanonicalError),
}

#[derive(Debug, Error, Eq, PartialEq)]
pub enum VerifyError {
    #[error("EVD_INDEX_OVERFLOW")]
    IndexOverflow,
    #[error("EVD_SEQUENCE_MISMATCH: expected {expected}, found {found}")]
    Sequence { expected: u64, found: u64 },
    #[error("EVD_CHAIN_ID_MISMATCH at sequence {0}")]
    ChainId(u64),
    #[error("EVD_PREDECESSOR_MISMATCH at sequence {0}")]
    Predecessor(u64),
    #[error("EVD_CANONICAL_INVALID at sequence {sequence}: {source}")]
    Canonical {
        sequence: u64,
        source: CanonicalError,
    },
    #[error("EVD_DIGEST_MISMATCH at sequence {0}")]
    Digest(u64),
}

/// Seal already-canonical bytes for qualification and verification tests only.
/// This function does not persist and does not assert write authority.
///
/// # Errors
///
/// Refuses sequence zero, invalid genesis/predecessor combinations, and any
/// canonical-byte validation failure.
pub fn seal_candidate(
    chain_id: Digest32,
    sequence: u64,
    previous: Option<Digest32>,
    canonical_bytes: Vec<u8>,
) -> Result<SealedEntry, SealError> {
    if sequence == 0 {
        return Err(SealError::SequenceZero);
    }
    match (sequence, previous) {
        (1, Some(_)) => return Err(SealError::InvalidGenesisPredecessor),
        (2.., None) => return Err(SealError::MissingPredecessor),
        _ => {}
    }
    verify_canonical(&canonical_bytes)?;
    let digest = digest_evd_entry(&canonical_bytes);
    Ok(SealedEntry {
        chain_id,
        sequence,
        previous,
        canonical_bytes,
        digest,
    })
}

/// Verify sequence, chain identity, predecessor linkage, canonical bytes, and digest,
/// in that deterministic precedence order. Empty input has no synthetic head.
///
/// # Errors
///
/// Returns the first deterministic structural, linkage, canonical-byte, or
/// digest failure encountered while walking the chain.
pub fn verify(entries: &[SealedEntry]) -> Result<Option<Digest32>, VerifyError> {
    let Some(first) = entries.first() else {
        return Ok(None);
    };
    let chain_id = first.chain_id;
    let mut prior = None;
    for (index, entry) in entries.iter().enumerate() {
        let index = u64::try_from(index).map_err(|_| VerifyError::IndexOverflow)?;
        let expected = index.checked_add(1).ok_or(VerifyError::IndexOverflow)?;
        if entry.sequence != expected {
            return Err(VerifyError::Sequence {
                expected,
                found: entry.sequence,
            });
        }
        if entry.chain_id != chain_id {
            return Err(VerifyError::ChainId(entry.sequence));
        }
        if entry.previous != prior {
            return Err(VerifyError::Predecessor(entry.sequence));
        }
        verify_canonical(&entry.canonical_bytes).map_err(|source| VerifyError::Canonical {
            sequence: entry.sequence,
            source,
        })?;
        if digest_evd_entry(&entry.canonical_bytes) != entry.digest {
            return Err(VerifyError::Digest(entry.sequence));
        }
        prior = Some(entry.digest);
    }
    Ok(prior)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn id(n: u8) -> Digest32 {
        Digest32([n; 32])
    }
    #[test]
    fn verifies_normative_chain_and_rejects_mutation() {
        let first = seal_candidate(id(7), 1, None, vec![0xf6]).unwrap();
        let mut second = seal_candidate(id(7), 2, Some(first.digest), vec![0xf4]).unwrap();
        assert_eq!(
            verify(&[first.clone(), second.clone()]),
            Ok(Some(second.digest))
        );
        second.canonical_bytes = vec![0xf5];
        assert_eq!(verify(&[first, second]), Err(VerifyError::Digest(2)));
    }
    #[test]
    fn structural_rules_fail_closed() {
        assert_eq!(
            seal_candidate(id(1), 0, None, vec![0xf6]),
            Err(SealError::SequenceZero)
        );
        assert_eq!(
            seal_candidate(id(1), 1, Some(id(2)), vec![0xf6]),
            Err(SealError::InvalidGenesisPredecessor)
        );
        assert_eq!(
            seal_candidate(id(1), 2, None, vec![0xf6]),
            Err(SealError::MissingPredecessor)
        );
        assert!(matches!(
            seal_candidate(id(1), 1, None, vec![0x18, 1]),
            Err(SealError::Canonical(CanonicalError::NonShortestEncoding))
        ));
    }
    #[test]
    fn diagnostic_precedence_is_deterministic() {
        let first = seal_candidate(id(7), 1, None, vec![0xf6]).unwrap();
        let mut bad = seal_candidate(id(7), 2, Some(first.digest), vec![0xf4]).unwrap();
        bad.sequence = 9;
        bad.chain_id = id(8);
        bad.previous = None;
        bad.canonical_bytes = vec![0x18, 1];
        assert_eq!(
            verify(&[first, bad]),
            Err(VerifyError::Sequence {
                expected: 2,
                found: 9
            })
        );
    }
}
