#!/usr/bin/env python3
"""Independent, non-authoritative Python comparator for typed EVD TSV fixtures."""
from __future__ import annotations

import hashlib
import re
import unicodedata
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIX = ROOT / "fixtures" / "evd" / "v1"
DOMAIN = b"marshal-core\0evd-002\0entry\0v1\0"
REGISTRY_DIGEST = "363ecc2ebc1e7faad6668e960db1043ab926f3c0b784e8b75c5e7a67e0cd599c"
STAMP = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}Z$")


class Refusal(ValueError):
    pass


def refuse(code: str) -> None:
    raise Refusal(code)


def head(major: int, value: int) -> bytes:
    if value < 24:
        return bytes([(major << 5) | value])
    for marker, width in ((24, 1), (25, 2), (26, 4), (27, 8)):
        if value < 1 << (width * 8):
            return bytes([(major << 5) | marker]) + value.to_bytes(width, "big")
    refuse("INTEGER_OUT_OF_PROFILE")


def encode(value: object) -> bytes:
    if value is None:
        return b"\xf6"
    if value is False:
        return b"\xf4"
    if value is True:
        return b"\xf5"
    if isinstance(value, int) and value >= 0:
        return head(0, value)
    if isinstance(value, bytes):
        return head(2, len(value)) + value
    if isinstance(value, str):
        if unicodedata.normalize("NFC", value) != value:
            refuse("TEXT_NOT_NFC")
        raw = value.encode()
        return head(3, len(raw)) + raw
    if isinstance(value, dict):
        pairs = sorted(((encode(key), encode(item)) for key, item in value.items()),
                       key=lambda pair: (len(pair[0]), pair[0]))
        return head(5, len(pairs)) + b"".join(key + item for key, item in pairs)
    refuse("FIELD_TYPE_INVALID")


def read_uint(raw: bytes, offset: int, additional: int) -> tuple[int, int]:
    if additional < 24:
        return additional, offset
    widths = {24: 1, 25: 2, 26: 4, 27: 8}
    if additional not in widths:
        refuse("CBOR_INDEFINITE_LENGTH")
    width = widths[additional]
    if offset + width > len(raw):
        refuse("CBOR_TRUNCATED")
    value = int.from_bytes(raw[offset:offset + width], "big")
    if value < {1: 24, 2: 256, 4: 65536, 8: 1 << 32}[width]:
        refuse("CBOR_NON_SHORTEST_ENCODING")
    return value, offset + width


def decode_one(raw: bytes, offset: int = 0) -> tuple[object, int]:
    if offset >= len(raw):
        refuse("CBOR_TRUNCATED")
    initial, offset = raw[offset], offset + 1
    major, additional = initial >> 5, initial & 31
    if major <= 5:
        length, offset = read_uint(raw, offset, additional)
    if major == 0:
        return length, offset
    if major == 1:
        return -1 - length, offset
    if major in (2, 3):
        end = offset + length
        if end > len(raw):
            refuse("CBOR_TRUNCATED")
        value = raw[offset:end]
        if major == 2:
            return value, end
        try:
            text_value = value.decode()
        except UnicodeDecodeError:
            refuse("TEXT_INVALID_UTF8")
        if unicodedata.normalize("NFC", text_value) != text_value:
            refuse("TEXT_NOT_NFC")
        return text_value, end
    if major == 4:
        values = []
        for _ in range(length):
            value, offset = decode_one(raw, offset)
            values.append(value)
        return values, offset
    if major == 5:
        result, prior = {}, None
        for _ in range(length):
            start = offset
            key, offset = decode_one(raw, offset)
            key_bytes = raw[start:offset]
            if prior is not None and (len(key_bytes), key_bytes) <= (len(prior), prior):
                refuse("CBOR_DUPLICATE_KEY" if key_bytes == prior else "CBOR_MAP_KEY_ORDER")
            prior = key_bytes
            value, offset = decode_one(raw, offset)
            if key in result:
                refuse("CBOR_DUPLICATE_KEY")
            result[key] = value
        return result, offset
    if major == 6:
        refuse("CBOR_PROHIBITED_TAG")
    if major == 7 and additional in (20, 21, 22):
        return {20: False, 21: True, 22: None}[additional], offset
    refuse("CBOR_PROHIBITED_VALUE")


def decode(raw: bytes) -> object:
    value, offset = decode_one(raw)
    if offset != len(raw):
        refuse("CBOR_TRAILING_DATA")
    if encode(value) != raw:
        refuse("CBOR_NONCANONICAL")
    return value


def exact_map(value: object, required: range, optional: set[int] = frozenset()) -> dict:
    if not isinstance(value, dict):
        refuse("FIELD_TYPE_INVALID")
    allowed = set(required) | optional
    if any(type(key) is not int or key not in allowed for key in value):
        refuse("UNKNOWN_FIELD")
    if any(key not in value for key in required):
        refuse("REQUIRED_FIELD_MISSING")
    return value


def unsigned(value: object) -> int:
    if type(value) is not int or value < 0:
        refuse("FIELD_TYPE_INVALID")
    return value


def blob(value: object, size: int) -> None:
    if not isinstance(value, bytes):
        refuse("FIELD_TYPE_INVALID")
    if len(value) != size:
        refuse("FIELD_BOUND_INVALID")


def text_value(value: object) -> str:
    if not isinstance(value, str):
        refuse("FIELD_TYPE_INVALID")
    if not value or len(value.encode()) > 255:
        refuse("FIELD_BOUND_INVALID")
    return value


def timestamp(value: object) -> None:
    candidate = text_value(value)
    if not STAMP.fullmatch(candidate):
        refuse("FIELD_BOUND_INVALID")
    try:
        datetime.strptime(candidate, "%Y-%m-%dT%H:%M:%S.%fZ")
    except ValueError:
        refuse("FIELD_BOUND_INVALID")


def load_registry(mode: str):
    if mode == "none":
        return None
    raw = (FIX / "lifecycle-registry-candidate.tsv").read_bytes()
    digest, version = hashlib.sha256(raw).hexdigest(), ""
    domains, edges, results = {}, set(), set()
    for line in raw.decode().splitlines():
        if line.startswith("#"):
            continue
        kind, domain, source, target = line.split("\t")
        if kind == "meta":
            version = source
        elif kind == "state":
            domains.setdefault(source, []).append(domain)
        elif kind == "transition":
            edges.add((domain, source, target))
        elif kind == "result":
            results.add(source)
    if mode == "stale":
        digest = "0" * 64
    if mode == "ambiguous":
        refuse("SPEC_AMBIGUOUS")
    if version != "MCR-EVD-LIFECYCLE-REGISTRY-CANDIDATE-2" or digest != REGISTRY_DIGEST:
        refuse("SPEC_AMBIGUOUS")
    return domains, edges, results


def approved_diagnostic(code: int) -> bool:
    ranges = ((1001,1006),(2001,2006),(3001,3003),(4001,4007),(5001,5004),
              (6001,6009),(7001,7005),(8001,8002),(9001,9002),(9501,9501))
    return code == 0 or any(start <= code <= end for start, end in ranges)


def validate(raw: bytes, registry_mode: str) -> str:
    try:
        root = exact_map(decode(raw), range(1, 18))
        if not isinstance(root[1], str): refuse("FIELD_TYPE_INVALID")
        if root[1] != "EVD-002": refuse("PROTOCOL_VERSION_UNSUPPORTED")
        if not isinstance(root[2], str): refuse("FIELD_TYPE_INVALID")
        if root[2] != "MARSHAL-CBOR-1": refuse("CANONICAL_PROFILE_UNSUPPORTED")
        blob(root[3], 16)
        sequence = unsigned(root[4])
        if sequence == 0 or sequence > (1 << 63) - 1: refuse("SEQUENCE_MISMATCH")
        if sequence == 1:
            if isinstance(root[5], bytes):
                blob(root[5], 32)
                refuse("GENESIS_INVALID")
            if root[5] is not None: refuse("FIELD_TYPE_INVALID")
        elif root[5] is None: refuse("PREDECESSOR_MISMATCH")
        else: blob(root[5], 32)
        blob(root[6], 16)
        event = unsigned(root[7])
        if event not in (1, 2): refuse("FIELD_BOUND_INVALID")
        timestamp(root[8])
        for key in (9, 10, 11): text_value(root[key])
        outcome, diagnostic = unsigned(root[12]), unsigned(root[13])
        if outcome > 3: refuse("FIELD_BOUND_INVALID")
        if (outcome == 0) != (diagnostic == 0) or not approved_diagnostic(diagnostic):
            refuse("PAYLOAD_SCHEMA_INVALID")
        schema = text_value(root[14])
        if schema not in ("marshal/evd/genesis/v1", "marshal/evd/lifecycle-transition/v1"):
            refuse("PAYLOAD_SCHEMA_UNKNOWN")
        if event == 1 and schema == "marshal/evd/genesis/v1":
            payload = exact_map(root[15], range(1, 10))
            for key in range(1, 8): blob(payload[key], 32)
            if not isinstance(payload[8], str): refuse("FIELD_TYPE_INVALID")
            if payload[8] != "rust-authority-gen-1": refuse("PAYLOAD_SCHEMA_INVALID")
            text_value(payload[9])
        elif event == 2 and schema == "marshal/evd/lifecycle-transition/v1":
            payload = exact_map(root[15], range(1, 7), {7})
            binding = load_registry(registry_mode)
            if binding is None: refuse("SPEC_AMBIGUOUS")
            domains, edges, results = binding
            prior, resulting = text_value(payload[1]), text_value(payload[2])
            shared = set(domains.get(prior, [])) & set(domains.get(resulting, []))
            if len(shared) != 1: refuse("PAYLOAD_SCHEMA_INVALID")
            domain = next(iter(shared))
            if (domain, prior, resulting) not in edges: refuse("PAYLOAD_SCHEMA_INVALID")
            expected, committed = unsigned(payload[3]), unsigned(payload[4])
            if expected == (1 << 64) - 1 or committed != expected + 1:
                refuse("PAYLOAD_SCHEMA_INVALID")
            text_value(payload[5])
            if text_value(payload[6]) not in results: refuse("PAYLOAD_SCHEMA_INVALID")
            if 7 in payload: timestamp(payload[7])
        else: refuse("PAYLOAD_SCHEMA_INVALID")
        if root[16] is not None: blob(root[16], 32)
        blob(root[17], 16)
        if (sequence == 1) != (event == 1): refuse("GENESIS_INVALID")
        return "OK"
    except Refusal as error:
        return str(error)


def mutate(root: dict, operation: str, argument: str) -> None:
    payload, number = root.get(15), int(argument) if argument.isdigit() else None
    if operation == "identity": return
    if operation == "set_event_code": root[7] = number
    elif operation == "set_schema": root[14] = argument
    elif operation == "set_sequence": root[4] = number
    elif operation == "set_predecessor_null": root[5] = None
    elif operation == "set_occurred_at": root[8] = argument
    elif operation == "set_outcome": root[12] = number
    elif operation == "set_diagnostic": root[13] = number
    elif operation == "remove_envelope_key": root.pop(number)
    elif operation == "add_envelope_key": root[number] = 0
    elif operation == "set_envelope_null": root[number] = None
    elif operation == "set_envelope_bool": root[number] = True
    elif operation == "set_chain_id_text": root[3] = argument
    elif operation == "remove_payload_key": payload.pop(number)
    elif operation == "add_payload_key": payload[number] = 0
    elif operation == "set_payload_null": payload[number] = None
    elif operation == "set_expected_revision_text": payload[3] = argument
    elif operation == "set_committed_revision": payload[4] = number
    elif operation == "set_resulting_state": payload[2] = argument
    elif operation == "set_transition_result": payload[6] = argument
    elif operation == "set_source_observed_at": payload[7] = argument
    elif operation == "set_inventory_digest_short": payload[1] = argument.encode()
    elif operation == "set_writer_generation": payload[8] = argument
    else: raise AssertionError(f"unknown mutation {operation}")


def rows(path: Path) -> list[list[str]]:
    return [line.split("\t") for line in path.read_text().splitlines()
            if line and not line.startswith("#")]


def main() -> None:
    positives = {row[0]: row for row in rows(FIX / "typed-record-positive.tsv")}
    for name, mode, encoded, expected, expected_digest in positives.values():
        raw = bytes.fromhex(encoded)
        assert validate(raw, mode) == expected, name
        digest = hashlib.sha256(DOMAIN + len(raw).to_bytes(8, "big") + raw).hexdigest()
        assert digest == expected_digest, name
    mutations = rows(FIX / "typed-record-mutations.tsv")
    for name, base, operation, argument, mode, expected in mutations:
        value = decode(bytes.fromhex(positives[base][2]))
        assert isinstance(value, dict)
        mutate(value, operation, argument)
        assert validate(encode(value), mode) == expected, name
    print(f"PASS: {len(positives)} positive and {len(mutations)} mutation fixtures")


if __name__ == "__main__":
    main()
