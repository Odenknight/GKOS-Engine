#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

stage1_target="$(mktemp -d)"
stage1_package="$(mktemp -d)"
export CARGO_TARGET_DIR="$stage1_target"

cargo +1.82.0 test --workspace --all-targets
cargo +1.82.0 clippy --workspace --all-targets -- -D warnings
cargo +1.82.0 fmt --all -- --check
cargo +1.82.0 build -p marshal-core-python
cargo +1.82.0 build --release -p marshal-core-python

mkdir -p "$stage1_package/marshal_core_rs"
cp python/marshal_core_rs/__init__.py "$stage1_package/marshal_core_rs/"
cp "$CARGO_TARGET_DIR/debug/lib_marshal_core_rs.so" \
  "$stage1_package/marshal_core_rs/_marshal_core_rs.so"

PYTHONPATH="$stage1_package" python3 -m unittest discover -s tests/python -v
PYTHONPATH="$stage1_package" python3 tools/compare_typed_evd_fixtures.py
PYTHONPATH="$stage1_package" python3 - <<'PY'
import marshal_core_rs as binding

assert binding.abi_info() == (
    "marshal-core-python/1",
    "MARSHAL-CBOR-1",
    "EVD-002",
    False,
    False,
)
assert binding.evd_entry_digest(bytes.fromhex("f6")) == (
    "f05f14b89ba03a5c1cc4ae922be92badb9ef3ffd466c5871372ca04dfde33d9f"
)
print("linux-stage1-binding: PASS")
PY

sha256sum "$CARGO_TARGET_DIR/release/lib_marshal_core_rs.so"
