# Evidence

Only reproducible qualification outputs belong here. Generated evidence must
record toolchain, OS, database, source commit, contract and fixture digests,
command, exit status, timestamps, and content digests. No bootstrap document is
itself proof that a qualification gate passed.

