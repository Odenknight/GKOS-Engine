# Commercial licensing

This project is privately owned and is not offered under an open-source license.
Commercial terms may include negotiated per-seat, per-node, per-organization,
hosted-service, OEM, redistribution, support, or royalty-bearing arrangements.

No royalty obligation exists until it is written into an executed agreement.
Prospective users must obtain written permission from the copyright owner before
evaluation beyond repository access, production deployment, redistribution,
commercial integration, or creation of derivative works.

The following must be settled in each agreement: licensed product and version,
field of use, territory, term, deployment scope, attribution, fees or royalties,
reporting and audit rights, support, warranty, indemnity, termination, survival,
and treatment of modifications.

This document is informational and is not itself an offer or license grant.

