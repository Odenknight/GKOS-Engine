# Coding-agent handoff: independent security and invariant review

**Candidate only. Reviewer must not merge, ratify, or activate.**

## Mission
Adversarially review WP-01 contracts and implementations independently of the implementing lanes.

## Inputs
Exact commit, contracts, source, migrations, dependency lock, fixtures, test/evidence bundles, threat model and owner decisions.

## Review focus
Canonical parser differentials; digest/domain confusion; duplicate keys; Unicode; state bypass; authority self-minting; kill/revocation TOCTOU; idempotency collision/conflict; PostgreSQL privilege/transaction races; verifier write access; secret/PHI leakage; denial of service; unsafe/dependency/licensing violations; evidence falsification.

## Outputs
Severity-ranked findings with exploit path, exact evidence, violated invariant, remediation and regression test; independent recomputation of manifests; explicit unresolved-risk ledger.

## Required validation
Attempt mutation of evidence with app role, commit across kill/revoke, lost-ack duplication, chain fork/gap, malformed/noncanonical CBOR acceptance, comparator false match, qualification-count gaming and historical-profile confusion.

## Forbidden
No fixing findings silently, approving own implementation, weakening a contract to make tests pass, using production data, disclosing secrets, or declaring eligibility with unresolved mismatch/finding.

## Exit report
`DONE` only when findings and residual risks are explicit; `BLOCKED` for missing evidence/access; `NEEDS_HUMAN` for accepted risk, owner authority or ambiguous contract.

## Repository scope

Review the exact WP-01 PR head, all owned crates touched by implementation lanes, migrations, fixtures, conformance tooling, dependency lock, CI and evidence bundles. Place review artifacts under `reviews/wp01-security/**` on a reviewer-owned branch or as PR review comments. Do not commit fixes to an implementation branch.

## Prerequisites

Exact commits/builds, complete diff, contracts/owner decisions, threat model, SBOM/license/advisory results, database role/config dump, test manifests and replay access to ephemeral environments. Missing evidence is reported, not assumed safe.

## Review sequence

1. Recompute source, fixture, migration, binary and bundle digests.
2. Trace untrusted bytes through decode, validation, authority, persistence and verification.
3. Review every deny/permit and diagnostic precedence path for fail-open behavior.
4. Attempt canonical/digest confusion and parser differential cases.
5. Attempt authority escalation, self-minting, stale epoch and kill/revoke TOCTOU.
6. Review SQL roles, queries, transaction/isolation anomalies and recovery claims.
7. Attack comparator, coverage, manifests and evidence-retention claims.
8. Review unsafe ban, dependency features/licenses/advisories, secret/PHI logging and denial-of-service bounds.
9. Re-run selected tests independently and publish findings/residual-risk ledger.

## Required review models/outputs

Finding fields: ID, severity, confidence, exact file/line or artifact, preconditions, exploit/reproduction, violated invariant, impact, remediation, required regression and status. Produce threat-boundary map, attack checklist, independent digest manifest, test transcript and residual-risk register.

## Commands

Run repository fmt/clippy/tests and deny/license/advisory/unsafe gates; fixture/manifest verification; malformed/fuzz regression corpus; PostgreSQL privilege/transaction tests; selected crash/concurrency replays; verifier over corrupted chains; comparator false-match/coverage-gaming tests. Record exact commands and environment.

## Forbidden/non-goals

No silent fix, approval of own code, production data/credentials, destructive non-ephemeral test, contract weakening, dismissed failed test, accepted risk on owner's behalf, merge/ratification/activation, or `DONE` with unresolved critical/high finding.

## Lane interactions

Remain organizationally independent. Ask implementing lanes for reproduction evidence without accepting their conclusion as proof. Route semantic ambiguity to owner; route code defects back with required regression. Evidence lane packages the signed review manifest only after content is final.

## Acceptance checklist

- [ ] Exact head and all artifacts independently identified.
- [ ] Threat boundaries and authority paths traced end-to-end.
- [ ] Canonical, state, database, verifier and comparator attacks attempted.
- [ ] Dependency/license/advisory/unsafe posture reviewed.
- [ ] Every finding has evidence and regression requirement.
- [ ] Residual risks and missing evidence are explicit.

## Strict reporting

`DONE` names reviewed head/builds, commands, artifacts, finding counts by severity, closed regressions and residual risks. `BLOCKED` names missing access/evidence and affected conclusions. `NEEDS_HUMAN` provides the exact risk acceptance or semantic/authority decision, exploit consequence, alternatives, reviewer recommendation and required contract/test changes.
