# Coding-agent handoff: Python comparator and shadow harness

**Candidate only. Python is permanently read-only and non-authoritative.**

## Mission
Compare Rust and Python/reference behavior using identical injected logical inputs and CBOR bytes without allowing Python serialization to define authority.

## Inputs
Normative/mutation fixtures, Rust comparator protocol, stable diagnostics, representative scrubbed operations, coverage-class registry.

## Outputs
Hermetic runner, exact comparison records, 10,000-shadow coverage accounting, 1,000-clean-streak tracker, mismatch ledger, reproducible evidence manifests.

## Compare
Acceptance/refusal, primary diagnostic, canonical bytes supplied by the fixture authority, digest, predecessor linkage and resulting logical chain state. Compare the frozen u16 event code and exact closed payload fields. Python free-form `reason` is ignored for canonical-byte identity and MUST NOT enter the logical authority input. `owner_authorization_digest` maps only to envelope `authority_ref`. Mark invalid or unmapped adapter setup as `COMPARISON_INVALID`; genuine contract ambiguity is `SPEC_AMBIGUOUS`; never conceal either as a match or mint a diagnostic.

## Required tests
All disposition classes; corrupted/truncated IPC; timeout; duplicate/reordered results; deterministic replay; class-minimum enforcement; behavioral-change clean-streak reset; zero-unresolved gate.

## Forbidden
No Python production writes, Python-generated expected CBOR as sole oracle, live secret/PHI capture, mismatch auto-resolution, self-adjudication of `SPEC_AMBIGUOUS`, or claiming activation.

## Exit report
`DONE` with counts by class, streak, ledger digest and exact builds; `BLOCKED`; or `NEEDS_HUMAN` with complete owner adjudication packet.

## Repository scope

Own a non-production harness under `conformance/python-comparator/**`, protocol schemas under `conformance/protocol/**`, shadow manifests/results under ignored or artifact-managed paths, and comparator tests under `tests/comparator/**`. If TheMarshal-008 changes are required, use a separate pinned branch/PR and record both heads; do not place Python in production Core crates.

## Prerequisites and pinned inputs

Pin the Rust executable/binary digest, Python interpreter/environment lock, historical reference commit, contract/fixture/diagnostic digests, comparator protocol version, representative-data classification and required coverage minima. The v1 event registry is closed to u16 codes 1 and 2; exact payload tables are frozen. Pin the regenerated candidate-2 lifecycle registry artifact and derived digest, and compare same-domain resolution plus edge legality for both lifecycle domains. Pin an explicit reviewed mapping for each supported Python outcome to an existing diagnostic. An unmapped case blocks/classifies the comparison; it never receives a best-fit code.

## Implementation sequence

1. Define length-bounded, versioned IPC carrying fixture IDs, exact injected bytes, logical input references and results.
2. Build hermetic Rust and Python adapters that cannot write production state.
3. Compare acceptance, stable diagnostic, supplied canonical bytes, digest, predecessor and logical resulting state field-by-field.
4. Record every run before aggregation; detect missing, duplicate, reordered and timed-out results.
5. Implement mismatch disposition workflow without automatic adjudication.
6. Add representative class counters, final-behavior version marker and clean-streak reset logic.
7. Emit a content-addressed, replayable shadow evidence bundle.

## Required APIs/data models

- `ComparisonInput`, `ImplementationResult`, `FieldDifference`, `ComparisonOutcome`.
- `MismatchDisposition` closed enum with four approved values.
- `CoverageClass`, `CoverageLedger`, `BehaviorVersion`, `CleanStreak`.
- CLI commands equivalent to `compare-fixtures`, `compare-shadow`, `replay`, `summarize`, each accepting exact manifests and emitting machine-readable reports.

## Commands

Localized Python lint/type/test commands must be declared in its lock/project file; run comparator protocol and malformed-IPC tests plus a deterministic replay. Run Rust-side comparator tests. Full verification includes Rust workspace gates, Python locked-environment tests, dependency/license/advisory inventories for both languages, fixture manifest verification and a scrubbed shadow smoke run.

## Evidence outputs

Exact build/environment manifests, fixture and input-set digests, per-class totals, match/mismatch totals, clean-streak state, behavioral-version history, complete mismatch ledger, replay commands, logs and redaction report. Retain permanently as specified, without live secrets/PHI.

## Forbidden/non-goals

No Python authority/write path, Python-created expected CBOR as sole oracle, production mutation, live unsanitized capture, mismatch suppression, automatic `SPEC_AMBIGUOUS` decision, class-count padding with identical duplicates, or eligibility claim.

## Interactions

Canonical/fixture lanes supply identical bytes; lifecycle lane defines logical state; verifier validates resulting chains; evidence lane signs manifests; independent review attacks false-match and coverage gaming. Owner alone adjudicates spec ambiguity.

## Acceptance checklist

- [ ] IPC is versioned, bounded and adversarially tested.
- [ ] Both environments and exact builds are pinned.
- [ ] Every compared field and invalid-comparison condition is explicit.
- [ ] Required class coverage cannot be bypassed.
- [ ] Behavioral changes reset the 1,000-clean counter.
- [ ] No production credentials/data/write capability exists.

## Strict reporting

`DONE` names both exact heads/builds, commands, totals by class, streak, ledger/artifact digests and risks. `BLOCKED` identifies missing reference/data/tool. `NEEDS_HUMAN` includes triggering input, both behaviors, ambiguity, effects, compatibility, recommendation, proposed contract text and affected tests.
