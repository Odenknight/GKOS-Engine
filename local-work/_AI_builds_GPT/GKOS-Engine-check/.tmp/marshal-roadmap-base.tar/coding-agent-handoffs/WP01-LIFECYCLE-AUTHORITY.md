# Coding-agent handoff: lifecycle and authority

**Candidate only. No authority or activation.**

## Mission
Implement pure, deterministic transition evaluators in contracts/authority/runtime crates. Checks must be deny-by-default and usable both before work and immediately before commit.

## Inputs
State-machine candidate, diagnostic registry, typed EVD logical records, appointment/grant/capability/kill schemas, owner-resolved semantics.

## Outputs
Closed enums, transition functions, authority/kill epoch checks, compare-and-set expectations, evidence intents, model-based tests and exhaustive transition tables.

## Boundaries
Functions receive explicit state, epoch, time and request; they do not read globals, mint authority, persist, call tools, or execute work. Return permitted transition plus evidence intent, or one stable refusal.

## Required tests
Every allowed edge and forbidden pair; terminal immutability; stale state; expiry boundary; revocation/kill races; repeated requests; absent appointment; capability subset; re-check before commit; generated sequences against a reference model.

## Forbidden
No self-approval, default allow, owner bypass, audit bypass, implicit time, mutable singleton, swallowed error, direct PostgreSQL, or transition without an evidence intent.

## Exit report
`DONE` with exhaustive matrix results and uncovered-state proof; `BLOCKED` for unavailable contract input; `NEEDS_HUMAN` for semantic ambiguity or owner-only authority.

## Repository scope

Own `crates/marshal-core-contracts/src/{lifecycle,diagnostic,ids}.rs`, `crates/marshal-core-authority/**`, lifecycle orchestration in `crates/marshal-core-runtime/**`, and focused tests under `tests/{lifecycle,authority}/**`. Do not implement persistence, CBOR codecs, policy classifiers, tool execution, secrets, UI, or product integration.

## Pinned prerequisites

The governing non-authoritative migration registration is merged in `Odenknight/TheMarshal-008` at merge commit `416b4e637339c344bc5522a65cb1223cd1f8caa0`, preserving the exact PR #55 authorized head `0898ee476fc857df60aae70d5f03f7fda8bc57ef`. That registration authorizes candidate migration and parity work only; it does not ratify this contract, appoint a writer, activate Rust, deploy, cut over, or permit a dual-writer interval.

Use the state-machine and diagnostic candidates at the work-packet head, the owner appointment model, no-self-mint rule, separate state-domain decision, and canonical evidence-intent types. The component domain has five states and exactly 13 direct edges. The runtime/work domain has nine states, exactly 11 direct edges, and exactly four terminals. Use registry version `MCR-EVD-LIFECYCLE-REGISTRY-CANDIDATE-2` and derive its digest from the normative TSV bytes; do not copy the prior candidate digest. Timestamp authority and any future `IDLE` semantics remain owner/spec inputs; do not infer them.

## Implementation sequence

1. Encode each domain as a closed enum and versioned state object with private fields.
2. Define exhaustive transition tables and stable refusal precedence before orchestration.
3. Implement pure transition evaluators with explicit `now`, authority epoch, kill epoch and expected version.
4. Implement grants as immutable, scoped, expiring capability sets; revocation creates an irreversible terminal grant state.
5. Implement admission and precommit evaluation as separate calls using the same policy contract.
6. Emit typed `EvidenceIntent` for both accepted and refused transitions.
7. Add reference-model and generated sequence tests, then race-oriented integration seams for the PostgreSQL lane.

## Required public models/APIs

- `LifecycleState`, `LifecycleVersion`, `AuthorityState`, `GrantId`, `AuthorityEpoch`, `KillState`, `KillEpoch`.
- `TransitionRequest`, `TransitionDecision::{Permit, Refuse}`, `EvidenceIntent`.
- `evaluate_transition(current, request, context) -> TransitionDecision`.
- `evaluate_authority(grant, required_capability, context) -> AuthorityDecision`.
- `precommit_revalidate(admission_receipt, current_epochs, current_state) -> TransitionDecision`.

All contexts carry explicit time and version inputs. Production constructors for owner appointment/grant material remain outside this lane.

## Commands and evidence

Localized: fmt, clippy and tests for contracts/authority/runtime packages; run transition model tests with a recorded seed. Full: workspace tests/clippy, dependency license/advisory gate, and no-unsafe scan. Emit transition coverage matrix, generated-sequence seed corpus, diagnostic mapping, API documentation, dependency report and exact command logs.

## Security and non-goals

No default allow, owner bypass, audit bypass, self-approval, implicit global clock, mutable singleton, swallowed diagnostic, dynamic string state, database transaction, execution of admitted work, or changing contract semantics to satisfy tests.

## Lane interactions

Canonical lane owns evidence bytes; this lane emits logical intents only. PostgreSQL lane serializes versions/epochs and revalidates under lock. Policy lane supplies a decision, not direct state mutation. Crash lane targets the admission-to-precommit race. Independent review attempts grant escalation and kill/revoke TOCTOU.

## Acceptance checklist

- [ ] All 25 component and 81 runtime state pairs are classified, with exactly 13 and 11 permitted edges.
- [ ] Prior/resulting payload states resolve uniquely in the same domain and every accepted pair is a registered edge.
- [ ] Exactly four runtime states are terminal; the component domain has no terminal predicate.
- [ ] Registry artifact bytes, version, derived digest, and manifest agree; stale-digest and cross-domain fixtures fail closed.
- [ ] Terminal states and revoked grant IDs are immutable.
- [ ] Admission and precommit both check authority and kill epochs.
- [ ] Every decision has exactly one diagnostic and evidence intent.
- [ ] No owner/spec ambiguity was silently resolved.
- [ ] Local and full gates pass; model coverage is complete.

## Strict reporting

`DONE` names exact head/files/APIs, matrix totals, seeds, commands, artifacts and residual risks. `BLOCKED` identifies the unavailable contract/tool and exact unblock action. `NEEDS_HUMAN` supplies the triggering transition, competing outcomes, downstream effects, recommendation, proposed normative text and affected fixtures.
