# Coding-agent handoff: fixtures and qualification evidence

**Candidate only. Evidence collection does not ratify or activate.**

## Mission
Create independently reviewable normative/mutation fixture packs and permanent content-addressed qualification bundles.

## Inputs
Frozen candidate contracts, owner decisions, independent expected-value generator/reviewer, build/database manifests, all lane reports.

## Outputs
Versioned CBOR fixtures, human projections, mutation provenance, SHA-256 manifests, coverage registry, run-bundle schema, reproducibility scripts, mismatch and clean-streak reports.

## Required coverage
Every record field/type/bound, event/outcome/diagnostic class, canonical rule, state edge/refusal, authority/kill boundary, chain/idempotency behavior, database crash/concurrency case and historical verification profile.

## Independence
Expected bytes/digests require either a separately implemented generator plus review or fixed hand-audited vectors. Fixtures generated and consumed by one code path alone are insufficient.

## Forbidden
No mutable fixture under an unchanged version, missing source/build/dependency digest, omitted failed run, self-hash manifest paradox, secret/PHI inclusion, or qualification claim before every gate passes.

## Exit report
`DONE` with artifact inventory/digests/reproduction command; `BLOCKED`; or `NEEDS_HUMAN` for fixture meaning, retention or adjudication.

## Repository scope

Own `fixtures/evd002/**`, `fixtures/mutations/**`, `conformance/manifests/**`, qualification bundle schemas/scripts under `conformance/evidence/**`, and fixture tests. Do not alter runtime/writer behavior, generate owner signatures, overwrite historical fixtures, or store large run outputs in Git unless the work packet explicitly permits it.

## Prerequisites and pinned inputs

Frozen candidate schemas, canonical profile, diagnostic precedence, u16 event codes `1 = GENESIS` and `2 = LIFECYCLE_TRANSITION` with v1 closure, the exact closed nine-key genesis payload and six-required/one-optional lifecycle payload, component five-state/13-edge and runtime nine-state/11-edge/four-terminal domains, registry version `MCR-EVD-LIFECYCLE-REGISTRY-CANDIDATE-2` with digest derived from exact TSV bytes, exact EVD entry domain plus `u64_be` length, writer-minted authoritative timestamp policy, 1 MiB/256 KiB/512 KiB/depth-32/text-255 bounds, Unicode 17.0.0 / `unicode-normalization` 0.1.25 pin, exact reviewed Python adapter mappings, exact implementing builds and PostgreSQL configuration. No fixture may add a diagnostic code, serialize Python free-form reason, or place `owner_authorization_digest` anywhere except envelope `authority_ref`.

## Implementation sequence

1. Define fixture/bundle schemas, versioning and immutable naming.
2. Generate the candidate-2 registry in the exact specified order, derive its SHA-256 from raw bytes, and create an inventory mapping each normative rule to positive, boundary and mutation cases, including all 25/81 pairs and registry-byte mutations.
3. Generate expected values with an independent implementation or hand-audited procedure.
4. Record mutation provenance: source fixture, exact byte/logical mutation and expected diagnostic.
5. Build manifest generation/verification without self-hashing the manifest itself.
6. Define qualification run bundle with exact source/build/dependency/environment/seed/log/result references.
7. Validate clean-room replay and permanent authority-domain retention for canonical entries/metadata, genesis, appointments, receipts, and checkpoint anchors; prove external/raw projections follow separate classification retention and that secrets, PHI, and bulky content are absent.

## Required artifact models/tools

- Fixture record: ID, contract/profile, logical projection, canonical bytes, digest, expected decision/code and provenance.
- Mutation record: parent ID, operation, exact offset/path and expected first diagnostic.
- Run manifest: immutable artifact list/digests, commands, environment, result summary and prior manifest reference where applicable.
- CLI equivalents: `fixtures verify`, `manifest create`, `manifest verify`, `qualification replay`.

## Commands

Localized schema validation, manifest verification, fixture consumer tests in Rust and Python, and clean-directory reproduction. Full: workspace/Python gates, dependency/license/advisory inventories, all fixture packs, 100,000-chain manifest, crash/concurrency bundles, shadow ledger and independent verifier reports.

## Evidence outputs

Coverage traceability matrix, fixture/mutation manifests and SHA-256 digests, independent-oracle report, command/environment transcript, bundle index, retention location/reference, missing/unresolved input register and reproduction timing.

## Security/non-goals

No secrets/PHI, mutable artifact under stable ID, omitted failed run, path traversal/symlink escape, unchecked decompression, self-generated sole oracle, signature impersonation, qualification before all gates, or deletion/rewrite of historical verification material.

## Interactions

Contracts define meaning; canonical lane consumes vectors; comparator supplies mismatch/shadow records; database/crash lanes supply run bundles; verifier supplies independent result; security lane recomputes manifests. Owner signs only separate appointment artifacts.

## Acceptance checklist

- [ ] Every normative statement maps to fixtures/tests.
- [ ] Every mutation has explicit provenance and diagnostic.
- [ ] Expected values have independent review/oracle.
- [ ] Manifests verify in a clean environment.
- [ ] Both exact payload maps, event-code closure, authority-ref mapping, reason exclusion, and unmapped-adapter dispositions have positive and mutation coverage.
- [ ] Candidate-2 registry generation is deterministic; all states, 13/11 edges, four terminals, same-domain checks, and byte/digest mutations are covered.
- [ ] Any unresolved digest-bound registry or adapter mapping is excluded and visible as `SPEC_AMBIGUOUS` or `COMPARISON_INVALID`.
- [ ] Permanent authority-domain retention is documented and non-destructive; external/raw retention is separate.
- [ ] Fixture and qualification bundles contain no secrets, PHI, or bulky raw content.

## Strict reporting

`DONE` names head/files, coverage totals, commands, fixture/bundle digests, storage references and residual gaps. `BLOCKED` identifies missing build/run/source. `NEEDS_HUMAN` gives the unresolved fixture meaning or retention/adjudication choice, alternatives, effects, recommendation and exact artifacts/tests affected.
