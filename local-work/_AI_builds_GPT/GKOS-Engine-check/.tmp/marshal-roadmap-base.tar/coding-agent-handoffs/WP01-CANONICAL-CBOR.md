# Coding-agent handoff: canonical CBOR

**Candidate only. No authority or activation.**

## Mission
Implement `marshal-core-canonical` as the only Rust boundary that validates and emits `MARSHAL-CBOR-1` bytes and domain-separated SHA-256 identities.

## Inputs
`MARSHAL-CBOR-1`, EVD logical-record candidate, diagnostic registry, Unicode 17.0.0 / `unicode-normalization` 0.1.25 pin, normative/mutation fixtures, the approved EVD entry domain with `u64_be` length, and v1 bounds.

## Outputs
Typed encoder/strict decoder, canonicality validator, NFC validator, digest API, fixture runner, property/fuzz tests, documentation of every dependency and feature flag.

## Boundaries
Accept typed logical values or raw bytes for verification. Return canonical bytes/digest or one stable diagnostic. No SQL, runtime state, policy, clock, network, filesystem, JSON identity, or language-default map ordering.

## Required tests
Exact bytes and digest for every normative vector; all mutation twins; duplicate keys; map key length-first ordering; integer/length shortest form; definite lengths; UTF-8/NFC; null/empty distinctions; floats/tags/simple values rejected; decode-reencode equality; cross-language vectors; fuzzing never panics.

## Forbidden
No `unsafe`; no silent normalization; no permissive decoder followed by re-encode; no floats; no unpinned Unicode behavior; no new canonical profile; no self-authored fixture expected values used as the sole oracle.

## Exit report
Return `DONE` with commit, files, tests, fixture and dependency digests; `BLOCKED` with missing reproducible input; or `NEEDS_HUMAN` with exact ambiguity, alternatives, effects and proposed contract text.

## Repository scope

Own only `crates/marshal-core-canonical/**`, canonical-specific fixtures under `fixtures/cbor/**`, and localized tests under `tests/canonical/**`. Changes to `marshal-core-contracts`, specifications, workspace dependencies, or CI require an explicit review note; do not edit authority, runtime, database, policy, secrets, SDK, or product integration code.

## Prerequisites and pinned inputs

- Exact branch base and Rust toolchain recorded in the work packet.
- `specifications/MARSHAL-CBOR-1.md`, EVD logical-record candidate, diagnostic registry, and accepted upstream GKX canonical annex digest.
- Owner-selected v1 inputs: u16 `1 = GENESIS`, `2 = LIFECYCLE_TRANSITION`, `0` prohibited and every other v1 code rejected/reserved; exact closed 9-pair genesis and 6-required/1-optional lifecycle payload tables in the EVD contract; writer-minted `occurred_at`; 1 MiB/256 KiB/512 KiB/depth-32/text-255 ceilings; exact EVD entry domain with `u64_be` length; Unicode 17.0.0 through pinned `unicode-normalization` 0.1.25.
- Dependency allowlist: permissive licenses only; no copyleft/source-available dependency without owner approval.

## Implementation sequence

1. Inventory and pin the CBOR and Unicode crates, features, versions, licenses, advisories and transitive tree.
2. Define bounded logical value types that cannot represent floats, tags, indefinite collections, or unbounded integers.
3. Implement a token-level strict decoder that detects duplicate keys before map construction.
4. Implement deterministic encoder ordering from canonical encoded key bytes.
5. Add NFC validation under the pinned Unicode data version.
6. Add the EVD entry digest exactly as `SHA-256("marshal-core\\0evd-002\\0entry\\0v1\\0" || u64_be(len) || bytes)`; do not reuse it for other artifacts.
7. Import independently reviewed vectors and mutation twins.
8. Add property, differential and fuzz targets; document resource ceilings.

## Required public surface

- `CanonicalProfileId` closed/versioned enum.
- `CanonicalBytes` and `ArtifactDigest` newtypes with private constructors.
- `decode_strict(profile, &[u8]) -> Result<LogicalValue, DiagnosticCode>`.
- `encode_canonical(profile, &LogicalValue) -> Result<CanonicalBytes, DiagnosticCode>`.
- `validate_canonical(profile, &[u8]) -> Result<CanonicalBytes, DiagnosticCode>` requiring input equality.
- `artifact_digest(domain: &DigestDomain, bytes: &CanonicalBytes) -> ArtifactDigest`.

No public API may accept or return `f32`, `f64`, unconstrained `serde_cbor::Value`, or a digest as free-form text.

## Commands

Localized: `cargo fmt --check`; `cargo clippy -p marshal-core-canonical --all-targets --all-features -- -D warnings`; `cargo test -p marshal-core-canonical --all-features`; run canonical fuzz/property targets with pinned seed. Full: `cargo test --workspace --all-features`; `cargo clippy --workspace --all-targets --all-features -- -D warnings`; `cargo deny check` or the repository-equivalent license/advisory gate.

## Evidence outputs

Produce test logs, fixture manifest and SHA-256 digest, dependency/license report, fuzz seeds/corpus digest, coverage by canonical rule, exact Rust/dependency versions, and a table mapping every diagnostic to a mutation fixture.

## Lane interactions

Contracts lane owns logical meaning and diagnostic numbers. Fixture lane independently approves expected bytes. Verifier consumes only the public strict API. PostgreSQL receives opaque `CanonicalBytes`; it must not call an alternate serializer. Python comparator receives the same pinned bytes, never its own serialization authority.

## Acceptance checklist

- [ ] Owner-selected u16 registry, closed payload maps, bounds, time authorship, digest formula, and Unicode pin are implemented exactly; unknown keys/collections and reserved codes fail closed.
- [ ] Free-form reason text is unrepresentable in canonical payload types; diagnostics use only exact reviewed mappings already in the registry.
- [ ] No unsafe Rust or float-capable authority type exists.
- [ ] Duplicate-key detection precedes semantic map construction.
- [ ] Every canonical rule has positive and negative fixtures.
- [ ] Exact bytes/digests agree with the independent oracle.
- [ ] Localized and workspace gates pass with evidence digests.

## Strict reporting

`DONE` must name exact head, changed files, APIs, commands/results, artifact digests, dependencies, residual risks and reviewer. `BLOCKED` must name the failed prerequisite, evidence, safe work completed and exact unblock action. `NEEDS_HUMAN` must present each unresolved semantic choice, alternatives, compatibility/security effects, recommendation, proposed contract text and tests that would change.
