# Coding-agent handoff: PostgreSQL writer

**Candidate only. No authority or activation.**

## Mission
Implement SQLx migrations and the sole append transaction described by the PostgreSQL authority candidate.

## Inputs
Typed validated canonical bytes/digest, expected head/version and epochs, idempotency key/request fingerprint, appointment reference, stable diagnostics.

## Outputs
Migrations with digests, least-privilege roles, repository API, transactional append/lookup, startup integrity gate, structured telemetry, integration tests.

## Boundaries
Store exact bytes; never reserialize them. Lock one chain head `FOR UPDATE`, re-check authority/kill/state, resolve idempotency, insert entry, update head and insert receipt/outbox in one transaction. Return only committed receipt.

## Required tests
Genesis; ordinary append; identical retry; conflicting key; stale head; duplicate digest; lost acknowledgement; independent-chain concurrency; revoke/kill race; migration mismatch; role cannot update/delete evidence; PostgreSQL 15+ matrix.

## Forbidden
No JSONB authority, SQLite production path, process mutex as correctness mechanism, authority repair, unbounded retry, semantic retry under a new key, mutable evidence, success before commit, or `unsafe`.

## Exit report
`DONE` with schema/migration digests, transaction proof and integration results; `BLOCKED` with environment/tool gap; `NEEDS_HUMAN` only for a still-unresolved authority or schema ambiguity. Isolation, retention, timestamp authorship, bounds, and v1 registry defaults are owner-selected below.

## Repository scope

Own a dedicated persistence module under `crates/marshal-core-evidence/src/postgres/**`, SQLx migrations under `migrations/postgres/**`, database integration tests under `tests/postgres/**`, and PostgreSQL test-container configuration. Modify canonical/contracts APIs only through a separately reviewed interface request.

## Prerequisites and owner-selected choices

Pinned inputs are the PostgreSQL authority candidate, EVD logical record, state/authority contracts, diagnostics and canonical opaque types. Require PostgreSQL 15+. Per-chain `FOR UPDATE` plus database invariants is the normative minimum; `SERIALIZABLE` is optional defense. The sole writer mints `occurred_at`. Enforce 1 MiB admitted request, 256 KiB payload, 512 KiB record, depth 32, and text 255. Admit only u16 `1 = GENESIS` and `2 = LIFECYCLE_TRANSITION`; prohibit 0 and reject/reserve every other v1 code. Validate the exact closed nine-key genesis payload and six-required/one-optional lifecycle payload before persistence. Store Python free-form reason nowhere in canonical authority bytes; map `owner_authorization_digest` only to envelope `authority_ref`; accept only exact reviewed existing diagnostics. Permanently retain canonical authority records for the authority-domain lifetime; external/raw projections use separate classification retention and secrets/PHI/bulky content never enter the chain.

## Implementation sequence

1. Threat-model roles, schemas, privileges and migration supply chain.
2. Write forward-only migrations with checked-in SHA-256 manifest, per-chain locking, and database-enforced uniqueness, foreign-key, byte-length, sequence/head/count, genesis/predecessor, idempotency/receipt, and immutability constraints.
3. Define the repository trait and typed SQLx row adapters; canonical bytes remain opaque.
4. Implement read-only idempotency lookup.
5. Implement the single append transaction: lock head, revalidate epochs/state, resolve key/fingerprint, insert entry, compare-and-set head, insert receipt/outbox, commit.
6. Add bounded retry classification and acknowledgement-loss recovery.
7. Add startup migration/appointment/head integrity gate and read-only forensic fallback.
8. Hand fault points to crash/concurrency lane and validate least-privilege roles.

## Required API/data models

- `AppendCommand` containing chain, expected head/version/epochs, canonical bytes/digest, idempotency key and request fingerprint.
- `CommittedReceipt` with committed sequence/digest and stable diagnostic.
- `AppendResult::{Committed, Existing, Refused, Indeterminate}`.
- `EvidenceRepository::{append, lookup_receipt, read_chain, verify_startup}` using typed errors.
- SQL tables `chains`, `evidence_entries`, `append_receipts`, `authority_appointments`, `schema_migrations`, optional checkpoints and outbox exactly as contract-controlled migrations.

## Commands

Localized: start an ephemeral PostgreSQL 15+ instance; `sqlx migrate run`; run package and `tests/postgres` suites in both available isolation profiles; verify application role mutation refusal. Full: workspace fmt/clippy/tests, migration hash check, SQLx offline metadata check, license/advisory scan, crash/concurrency smoke suite.

## Evidence outputs

Migration manifest/digests, database/version/config manifest, privilege dump, transaction trace with secret/body redaction, test logs, schema diagram, query-plan/lock-wait samples, and proof that identical lost-ack retries return one receipt.

## Forbidden/non-goals

No JSONB authority, SQLite production substitute, global/process mutex correctness, repair that invents authority, UPDATE/DELETE capability for the app role, unbounded retries, automatic new idempotency key, success before commit, unsafe Rust, deployment or production credentials.

## Lane interactions

Consumes canonical opaque bytes and state precommit decisions. Verifier reads through read-only credentials. Crash lane owns destructive ephemeral fault testing. Evidence lane packages database manifests. Security review validates roles, TOCTOU and transaction claims.

## Acceptance checklist

- [ ] Schema invariants and least privileges are enforced by tests.
- [ ] Entry/head/receipt/outbox commit atomically.
- [ ] Retry and indeterminate outcomes follow stable diagnostics.
- [ ] Independent chains do not share a global lock.
- [ ] Startup inconsistency fails closed without repair.
- [ ] Per-chain `FOR UPDATE` and database invariants are evidenced; optional `SERIALIZABLE` results do not replace them.
- [ ] Permanent authority retention and separate external/raw retention are enforced without storing secrets, PHI, or bulky content in canonical bytes.

## Strict reporting

`DONE` includes exact head/files, migration digests, PostgreSQL/config version, isolation tested, commands/results, fault hooks and risks. `BLOCKED` identifies missing database/fault capability. `NEEDS_HUMAN` presents only remaining schema or authority ambiguities with anomalies prevented, recommendation, exact contract change and test changes; it must not reopen recorded owner defaults.
