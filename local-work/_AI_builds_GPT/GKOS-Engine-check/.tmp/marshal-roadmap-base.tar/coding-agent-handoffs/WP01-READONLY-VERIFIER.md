# Coding-agent handoff: read-only verifier

**Candidate only. The verifier never writes authority.**

## Mission
Implement independent genesis-to-head verification for current CBOR chains and permanently retained historical JCS verification behind explicit profiles.

## Inputs
Read-only row/stream source, canonical profile registry, contract and genesis manifest, checkpoints, historical fixture corpus.

## Outputs
Streaming verifier, stable diagnostics with exact failing sequence/digest, checkpoint acceleration with full-verification fallback, CLI/API reports, 100,000-entry tests.

## Boundaries
Use read-only credentials/transactions. Recompute canonical acceptance, digest, sequence, predecessor linkage, count and head. Historical codecs are isolated and can never produce production writes.

## Required tests
Valid empty/nonempty chains; each mutation; wrong head/count; gap/fork/duplicate; checkpoint corruption; unknown profile; bounded memory over 100,000 entries; database snapshot during concurrent append; deterministic report.

## Forbidden
No UPDATE/DELETE/repair, no projection-derived identity, no accepting unknown version, no verifier result that grants authority, no importing JCS history into CBOR production chain.

## Exit report
`DONE` with independent oracle rationale and resource measurements; `BLOCKED`; or `NEEDS_HUMAN` for historical-format ambiguity.

## Repository scope

Own `crates/marshal-core-verify/**`, verifier CLI surfaces explicitly assigned under `crates/marshal-core-verify/src/bin/**`, read-only adapters, `tests/verifier/**`, and verifier-specific historical fixtures. Do not alter writer, migrations, evidence rows, historical artifacts, or canonical contracts.

## Prerequisites

Pinned current CBOR/EVD contracts and fixture digests, historical JCS profile/checkpoint v1 digests, PostgreSQL read schema, diagnostic registry, and genesis/checkpoint schemas. Missing historical source or ambiguous legacy behavior is `NEEDS_HUMAN`; never approximate it.

## Implementation sequence

1. Define a streaming `EntrySource` trait and verified report model.
2. Verify contract/profile support and genesis manifest before entries.
3. For each entry, strict-decode, recompute canonical identity, sequence and predecessor linkage.
4. Compare count/final digest to the declared head.
5. Add checkpoint-assisted mode that always permits full genesis fallback.
6. Isolate each historical codec/profile behind an explicit read-only selector.
7. Add bounded-memory 100,000-entry verification and deterministic failure reports.

## Required APIs/models

- `VerificationProfile` closed enum separating current CBOR and historical JCS.
- `EntrySource` streaming trait without write methods.
- `Verifier::verify(source, manifest, options) -> VerificationReport`.
- `VerificationReport` with status, first failing sequence/digest, stable diagnostic, verified count/head and input manifest digests.
- `CheckpointTrust::{UntrustedHint, SignatureValidated}`; neither bypasses entry verification rules.

## Commands/evidence

Localized verifier fmt/clippy/tests; read-only PostgreSQL integration test; bounded-memory 100,000-entry run; corrupted-chain fixture suite. Full workspace gates, license/advisory scan and explicit database privilege test. Emit resource measurements, profile/fixture matrix, deterministic reports, exact commands, dependency report and proof no write-capable API/credential is linked.

## Forbidden/non-goals

No write SQL, repair, truncation, head advance, unknown-version acceptance, projection-derived identity, production grant/appointment, JCS-to-CBOR import, hidden best-effort success, or sharing the writer's high-level verification implementation as the sole oracle.

## Interactions

Canonical lane provides low-level strict primitives but verifier independently orchestrates chain rules. PostgreSQL supplies read-only stream. Python/historical lane supplies pinned legacy vectors. Crash lane invokes verifier after every fault. Qualification lane packages its report.

## Acceptance checklist

- [ ] Read-only capability is enforced structurally and by database role.
- [ ] Every mutation reports the first deterministic failure.
- [ ] Current and historical profiles cannot be confused.
- [ ] 100,000 entries verify within recorded bounds.
- [ ] Checkpoints cannot hide corrupt history.
- [ ] Full workspace/security gates pass.

## Strict reporting

`DONE` names head/files/APIs, profiles, commands, resource bounds and report digests. `BLOCKED` identifies unavailable source/environment. `NEEDS_HUMAN` includes exact historical ambiguity, possible interpretations, impact, recommendation, proposed profile text and fixtures.
