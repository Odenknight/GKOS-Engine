# Coding-agent handoff: crash and concurrency qualification

**Candidate only. Test infrastructure has no production authority.**

## Mission
Build deterministic fault injection and model-based concurrency harnesses against the real Rust/PostgreSQL writer.

## Inputs
PostgreSQL contract, containerized PostgreSQL 15+ profiles, append API, verifier, fault-point registry, state-machine model.

## Outputs
Crash matrix, concurrency schedules, reproducible seeds, minimized failures, database snapshots/checksums, invariant reports and content-addressed run bundles.

## Required faults/schedules
Kill process/backend/database and reset/timeout/disk fault around every transaction boundary; same-chain distinct writers; identical/conflicting idempotency; stale heads; parallel genesis; append versus seal/revoke/kill; independent chains; restart under load; pool exhaustion; deadlock/serialization paths.

## Assertions
Zero-or-one append, no partial entry/head/receipt, no fork/gap, original receipt on retry, stable conflict refusal, no post-boundary commit, no duplicate side effect, complete verifier pass.

## Forbidden
No mocked database as qualification evidence, nondeterministic failure without seed, destructive access outside ephemeral test targets, altered production contract for test convenience, or suppression of flaky failures.

## Exit report
`DONE` with full matrix and bundle digests; `BLOCKED` with unavailable fault capability; `NEEDS_HUMAN` for risk/coverage exceptions.

## Repository scope

Own `tests/crash/**`, `tests/concurrency/**`, fault-control code compiled only under a non-production feature, ephemeral orchestration under `conformance/postgres-faults/**`, and matrix manifests. Do not modify production semantics, run against non-ephemeral databases, or embed fault endpoints in release builds.

## Prerequisites

Exact writer/verifier builds, PostgreSQL 15+ image digest/configuration, transaction contract, stable diagnostics, state model, enumerated fault points and approved isolation profiles. The normative isolation choice remains unresolved; test both supported candidates and report differences.

## Implementation sequence

1. Create disposable, uniquely named database/container targets with destructive-target guards.
2. Register deterministic pre/post fault hooks around every transaction boundary.
3. Implement single-case runner capturing prestate, schedule, fault, recovery and verification.
4. Populate crash fault × boundary matrix.
5. Implement concurrency reference model, generated schedules and minimization.
6. Add revoke/kill/precommit and acknowledgement-loss schedules.
7. Run full matrices, replay every failure and package snapshots/checksums/logs.

## Required harness APIs/models

- `FaultPoint`, `FaultKind`, `FaultSchedule`, `ConcurrencyOperation`, `ExpectedModelState`.
- A controller API that requires an ephemeral-target token and refuses broad/unresolved database targets.
- `run_case(seed, schedule) -> CaseEvidence` and `verify_case(case) -> InvariantReport`.
- Test-only hooks absent from default/release feature graphs.

## Commands

Localized commands start the pinned ephemeral PostgreSQL image, run crash matrix and concurrency matrix with explicit seed/output directory, replay a named case, and run the read-only verifier. Full verification adds workspace fmt/clippy/tests, release feature-tree inspection proving no fault hook, dependency/license/advisory scans, and complete matrix manifest verification.

## Evidence outputs

PostgreSQL/runtime/build/config digests, seeds and minimized schedules, exact fault timing, pre/post snapshots/checksums, WAL/restart logs, verifier reports, invariant totals, latency/lock metrics, full command transcript and content-addressed bundle manifest.

## Security/non-goals

No production target, unresolved environment variable, wildcard destructive command, mock-database qualification, flaky suppression, unseeded randomized result, modified invariant, hidden failed run, or risk exception without owner approval.

## Interactions

Writer exposes test-only fault points; lifecycle provides reference state; verifier is postcondition oracle; evidence lane packages bundles; security review validates destructive guards and race completeness.

## Acceptance checklist

- [ ] Every declared boundary/fault pair is executed or explicitly blocked.
- [ ] Zero-or-one atomicity holds after every recovery.
- [ ] No fork, gap, duplicate side effect or post-kill/revoke commit occurs.
- [ ] Failures are reproducible and minimized.
- [ ] Release builds contain no fault-control surface.
- [ ] Both candidate isolation modes are compared pending owner choice.

## Strict reporting

`DONE` names head, writer/verifier/database digests, matrix dimensions, pass totals, seeds and bundle digests. `BLOCKED` names the unavailable fault primitive/environment and uncovered cells. `NEEDS_HUMAN` presents any requested exclusion/risk acceptance with consequence, alternative and exact added/removed tests.
