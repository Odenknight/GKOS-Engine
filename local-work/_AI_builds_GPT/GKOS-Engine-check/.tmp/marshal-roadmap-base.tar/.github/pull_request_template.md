## Scope

- Work packet / requirement IDs:
- Exact behavior changed:
- Explicitly out of scope:

## Evidence

- Tests:
- Negative tests:
- Fixture changes:
- Contract changes:

## Authority

- [ ] This PR does not claim activation, deployment, cutover, or completion.
- [ ] No unresolved `SPEC_AMBIGUOUS` case was decided without owner adjudication.
- [ ] Third-party code and licenses are recorded.

