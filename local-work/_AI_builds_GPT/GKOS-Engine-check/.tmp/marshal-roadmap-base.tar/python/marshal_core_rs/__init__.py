"""Fail-closed facade for the non-authoritative Marshal Core Rust binding."""

from __future__ import annotations

CONTINUITY_CONTRACT_ID = "DURABLE-CONTINUITY-v1"
CONTINUITY_SCHEMA = "harness/durable-continuity-envelope/v1"
GENERATED_ARTIFACT_RECEIPT_SCHEMA = "harness/generated-artifact-receipt/v1"
EXPECTED_ABI = (
    "marshal-core-python/2",
    "MARSHAL-CBOR-1",
    "EVD-002",
    CONTINUITY_CONTRACT_ID,
    False,
    False,
)


class BindingUnavailable(RuntimeError):
    """The exact approved native binding is absent or incompatible."""


try:
    from . import _marshal_core_rs as _native
except ImportError as exc:  # No semantic fallback is permitted.
    raise BindingUnavailable("MARSHAL_CORE_RUST_BINDING_UNAVAILABLE") from exc

if _native.abi_info() != EXPECTED_ABI:
    raise BindingUnavailable("MARSHAL_CORE_RUST_ABI_MISMATCH")

abi_info = _native.abi_info
verify_canonical = _native.verify_canonical
evd_entry_digest = _native.evd_entry_digest
component_edge_allowed = _native.component_edge_allowed
evaluate_runtime = _native.evaluate_runtime
validate_evd = _native.validate_evd
verify_chain = _native.verify_chain
continuity_decide_v1 = _native.continuity_decide_v1
validate_generated_artifact_receipt_v1 = (
    _native.validate_generated_artifact_receipt_v1
)
verify_continuity_v1 = _native.verify_continuity_v1

__all__ = [
    "BindingUnavailable",
    "CONTINUITY_CONTRACT_ID",
    "CONTINUITY_SCHEMA",
    "EXPECTED_ABI",
    "GENERATED_ARTIFACT_RECEIPT_SCHEMA",
    "abi_info",
    "component_edge_allowed",
    "continuity_decide_v1",
    "evaluate_runtime",
    "evd_entry_digest",
    "validate_evd",
    "validate_generated_artifact_receipt_v1",
    "verify_canonical",
    "verify_chain",
    "verify_continuity_v1",
]
