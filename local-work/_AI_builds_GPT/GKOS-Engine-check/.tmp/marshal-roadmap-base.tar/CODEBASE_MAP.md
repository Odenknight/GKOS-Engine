# Codebase Map

## Data flow

`product command -> contracts -> policy/authority -> runtime admission -> SQL
transaction -> EVD-002 evidence/outbox -> asynchronous GKX checkpoint`

## Hard boundaries

- `marshal-core-canonical` must not depend on database, network, UI, or model SDKs.
- `marshal-core-evidence` must not allocate sequences outside the authority transaction.
- `marshal-core-verify` is read-only and must never acquire write credentials.
- External checkpoint publication never occurs inside the authority transaction.
- Product/UI code belongs in TheMarshal-008, not this workspace.
- GKOS-Engine is a downstream knowledge service, not a substitute authority path.
- Product consumers pin exact qualified upstream revisions and adapt at their
  boundary; they do not fork shared Core semantics.

## First implementation lane

EVD-002 cross-language equivalence is first. Other crates expose bounded
interfaces and must not claim implementation completion without their own work
packets, fixtures, negative tests, and activation records.

## Governing registration

The non-authoritative migration goals and parity milestones were registered by
TheMarshal-008 PR #55 at exact authorized head
`0898ee476fc857df60aae70d5f03f7fda8bc57ef`, merged and reachable as
`416b4e637339c344bc5522a65cb1223cd1f8caa0`. This permits candidate migration
and parity work only. It does not ratify a contract, appoint a writer, activate
Rust, deploy, cut over, or permit a dual-writer interval.

## WP-01 candidate artifacts

- `specifications/EVD-002-LOGICAL-RECORD-CANDIDATE.md` — typed logical record presented to canonical CBOR.
- `specifications/MARSHAL-STATE-MACHINE-CANDIDATE.md` — runtime, authority, kill and append domains.
- `specifications/DIAGNOSTIC-REGISTRY-CANDIDATE.md` — stable numeric diagnostics and precedence.
- `specifications/POSTGRESQL-AUTHORITY-CANDIDATE.md` — sole-writer persistence and recovery contract.
- `conformance/WP01-ACCEPTANCE-MATRIX.md` — eligibility evidence and reset rules.
- `coding-agent-handoffs/WP01-*.md` — bounded standalone implementation/review assignments.

These are candidate planning artifacts. Presence in the repository does not
ratify a contract, qualify an implementation, appoint a writer, or activate a
production chain.
